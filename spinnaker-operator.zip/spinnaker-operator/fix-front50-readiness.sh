#!/bin/bash

# Fix Front50 Readiness Probe Connection Refused Error
# This script addresses common causes of front50 readiness probe failures

set -e

SPINNAKER_NAMESPACE="spinnaker"
BUCKET_NAME="exotel-spinnaker-qa"
REGION="us-west-2"

echo "=========================================="
echo "Fix Front50 Readiness Probe Error"
echo "=========================================="
echo ""

# Step 1: Check if S3 bucket exists
echo "Step 1: Verifying S3 bucket exists..."
if aws s3 ls "s3://${BUCKET_NAME}" --region "${REGION}" &>/dev/null; then
    echo "✓ S3 bucket '${BUCKET_NAME}' exists"
else
    echo "✗ ERROR: S3 bucket '${BUCKET_NAME}' does not exist or is not accessible"
    echo ""
    echo "Creating bucket..."
    if aws s3 mb "s3://${BUCKET_NAME}" --region "${REGION}" 2>&1; then
        echo "✓ Bucket created successfully"
    else
        echo "✗ Failed to create bucket. Please create it manually:"
        echo "  aws s3 mb s3://${BUCKET_NAME} --region ${REGION}"
        exit 1
    fi
fi
echo ""

# Step 2: Check Front50 pod status
echo "Step 2: Checking Front50 pod status..."
FRONT50_PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods | grep front50 | awk '{print $1}' || echo "")
if [ -z "$FRONT50_PODS" ]; then
    echo "✗ No Front50 pods found"
    exit 1
fi

for POD in $FRONT50_PODS; do
    echo "  Pod: $POD"
    STATUS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pod $POD -o jsonpath='{.status.phase}' 2>/dev/null || echo "Unknown")
    READY=$(kubectl -n ${SPINNAKER_NAMESPACE} get pod $POD -o jsonpath='{.status.containerStatuses[0].ready}' 2>/dev/null || echo "false")
    echo "    Status: $STATUS, Ready: $READY"
done
echo ""

# Step 3: Check Front50 logs for errors
echo "Step 3: Checking Front50 logs for errors..."
for POD in $FRONT50_PODS; do
    echo "  Checking logs for $POD..."
    ERRORS=$(kubectl -n ${SPINNAKER_NAMESPACE} logs $POD --tail=100 2>&1 | grep -i "error\|exception\|failed\|s3\|bucket" | tail -10 || echo "")
    if [ -n "$ERRORS" ]; then
        echo "    Found errors:"
        echo "$ERRORS" | sed 's/^/      /'
    else
        echo "    No errors found in recent logs"
    fi
done
echo ""

# Step 4: Check if service is starting (Spring Boot takes time)
echo "Step 4: Checking if Front50 service is starting..."
for POD in $FRONT50_PODS; do
    echo "  Testing health endpoint for $POD..."
    if kubectl -n ${SPINNAKER_NAMESPACE} exec $POD -- wget -q -O- http://localhost:8080/health 2>&1 | grep -q "UP\|status"; then
        echo "    ✓ Health endpoint is responding"
    else
        echo "    ⚠ Health endpoint not responding yet (service may still be starting)"
        echo "    Checking if Java process is running..."
        if kubectl -n ${SPINNAKER_NAMESPACE} exec $POD -- ps aux | grep -q "[j]ava"; then
            echo "    ✓ Java process is running (service is starting, wait a bit longer)"
        else
            echo "    ✗ Java process not found (service may have crashed)"
        fi
    fi
done
echo ""

# Step 5: Check readiness probe configuration
echo "Step 5: Checking readiness probe configuration..."
for POD in $FRONT50_PODS; do
    echo "  Readiness probe for $POD:"
    PROBE=$(kubectl -n ${SPINNAKER_NAMESPACE} get pod $POD -o jsonpath='{.spec.containers[0].readinessProbe}' 2>/dev/null || echo "")
    if [ -n "$PROBE" ]; then
        echo "$PROBE" | jq '.' 2>/dev/null || echo "$PROBE"
    else
        echo "    No readiness probe configured"
    fi
done
echo ""

# Step 6: Recommendations
echo "=========================================="
echo "Recommendations"
echo "=========================================="
echo ""

# Check if service is just slow to start
SLOW_START=false
for POD in $FRONT50_PODS; do
    AGE=$(kubectl -n ${SPINNAKER_NAMESPACE} get pod $POD -o jsonpath='{.metadata.creationTimestamp}' 2>/dev/null || echo "")
    if [ -n "$AGE" ]; then
        # Calculate age (simplified - just check if recent)
        echo "  Pod $POD was created recently"
        SLOW_START=true
    fi
done

if [ "$SLOW_START" = true ]; then
    echo ""
    echo "Front50 may be slow to start (Spring Boot initialization can take 3-5 minutes)."
    echo "If the pod is Running but not Ready, wait a few more minutes."
    echo ""
    echo "Monitor progress:"
    echo "  kubectl -n ${SPINNAKER_NAMESPACE} get pods -l app=spin-front50 -w"
    echo "  kubectl -n ${SPINNAKER_NAMESPACE} logs -l app=spin-front50 -f"
    echo ""
fi

# Check for S3 connection issues
echo "If Front50 is still failing after 5+ minutes, check:"
echo ""
echo "1. S3 bucket access:"
echo "   aws s3 ls s3://${BUCKET_NAME} --region ${REGION}"
echo ""
echo "2. S3 credentials in SpinnakerService:"
echo "   kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.persistentStorage.s3}'"
echo ""
echo "3. Front50 logs for S3 errors:"
echo "   kubectl -n ${SPINNAKER_NAMESPACE} logs -l app=spin-front50 --tail=100 | grep -i s3"
echo ""
echo "4. Restart Front50 if needed:"
echo "   kubectl -n ${SPINNAKER_NAMESPACE} delete pod -l app=spin-front50"
echo ""

echo "=========================================="
echo "Done!"
echo "=========================================="





