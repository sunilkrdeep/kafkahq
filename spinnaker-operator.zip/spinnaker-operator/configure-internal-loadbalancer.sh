#!/bin/bash

# Configure Spinnaker LoadBalancer to be Internal/Private Only
# This makes the load balancer accessible only from within the VPC/internal network

set -e

NAMESPACE="spinnaker"
SERVICE_NAME="spin-deck"

echo "=========================================="
echo "Configuring Internal LoadBalancer"
echo "=========================================="
echo ""

echo "Step 1: Adding internal annotation to SpinnakerService..."
kubectl -n $NAMESPACE patch spinnakerservice spinnaker --type='json' -p='[{"op": "add", "path": "/spec/expose/service/annotations/service.beta.kubernetes.io~1aws-load-balancer-internal", "value": "true"}]'

echo ""
echo "Step 2: Verifying annotation..."
kubectl -n $NAMESPACE get spinnakerservice spinnaker -o jsonpath='{.spec.expose.service.annotations}' | jq .

echo ""
echo "Step 3: Note - The service needs to be recreated for this change to take effect."
echo "The current LoadBalancer is still public. To apply the change:"
echo ""
echo "  Option A: Delete and let operator recreate (recommended)"
echo "    kubectl -n $NAMESPACE delete svc $SERVICE_NAME"
echo "    # Wait 2-5 minutes for new internal LoadBalancer"
echo ""
echo "  Option B: Delete both deck and gate services"
echo "    kubectl -n $NAMESPACE delete svc spin-deck spin-gate"
echo "    # Wait for operator to recreate with internal configuration"
echo ""

echo "Step 4: After recreation, verify the LoadBalancer is internal..."
echo "  kubectl -n $NAMESPACE get svc $SERVICE_NAME"
echo "  # The hostname should be in internal DNS format"
echo ""
echo "  aws elbv2 describe-load-balancers --query \"LoadBalancers[?contains(DNSName, 'your-prefix')].{Scheme:Scheme,Type:Type}\" --output table"
echo "  # Scheme should show 'internal'"
echo ""

echo "=========================================="
echo "Configuration complete!"
echo "=========================================="
echo ""
echo "IMPORTANT: The LoadBalancer will only be accessible from:"
echo "  - Within the same VPC"
echo "  - Connected VPN networks"
echo "  - Connected Direct Connect/VPC Peering"
echo ""
echo "External internet access will be blocked."


