#!/bin/bash

# Quick script to force delete a stuck namespace
# Usage: ./force-delete-namespace.sh <namespace>

set -e

NAMESPACE=${1:-"spinnaker"}

echo "Force deleting namespace: ${NAMESPACE}"

# Check if namespace exists
if ! kubectl get namespace ${NAMESPACE} &>/dev/null; then
    echo "Namespace ${NAMESPACE} does not exist."
    exit 0
fi

# Get namespace JSON and remove finalizers
echo "Removing finalizers from namespace ${NAMESPACE}..."
kubectl get namespace ${NAMESPACE} -o json | \
    jq '.spec.finalizers = []' | \
    kubectl replace --raw /api/v1/namespaces/${NAMESPACE}/finalize -f - 2>/dev/null || {
    echo "Trying alternative method..."
    kubectl patch namespace ${NAMESPACE} -p '{"metadata":{"finalizers":[]}}' --type=merge
}

echo "Namespace ${NAMESPACE} should be deleted now."
echo "Verify with: kubectl get namespace ${NAMESPACE}"





