#!/bin/bash

# Fix SpinnakerService Failure Status
# Investigates and attempts to fix the "Failure" status

set -e

SPINNAKER_NAMESPACE="spinnaker"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "=========================================="
echo "Fix SpinnakerService Failure Status"
echo "=========================================="
echo ""

# Step 1: Check current status
print_info "Step 1: Checking SpinnakerService status..."
STATUS=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.status.status}' 2>/dev/null || echo "Unknown")
echo "  Current status: $STATUS"
echo ""

# Step 2: Check all pods are actually running
print_info "Step 2: Verifying all pods are running..."
ALL_RUNNING=true

EXPECTED_SERVICES=("clouddriver" "deck" "echo" "fiat" "front50" "gate" "igor" "kayenta" "orca" "rosco" "redis")

for service in "${EXPECTED_SERVICES[@]}"; do
    RUNNING=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods -l app.kubernetes.io/name=${service} -o json 2>/dev/null | jq -r '.items[] | select(.status.phase == "Running" and (.status.containerStatuses[]? | .ready == true)) | .metadata.name' | wc -l | tr -d ' ')
    if [ "$RUNNING" -ge 1 ]; then
        print_info "  ✓ $service: Running"
    else
        print_error "  ✗ $service: Not running"
        ALL_RUNNING=false
    fi
done
echo ""

# Step 3: Check SpinnakerService events for errors
print_info "Step 3: Checking SpinnakerService events..."
echo ""

EVENTS=$(kubectl -n ${SPINNAKER_NAMESPACE} describe spinsvc spinnaker 2>/dev/null | grep -A 50 "Events:" | grep -E "Warning|Error" | tail -10 || echo "")

if [ -n "$EVENTS" ]; then
    print_warn "Found recent warnings/errors:"
    echo "$EVENTS" | sed 's/^/  /'
    echo ""
    
    # Check for specific issues
    if echo "$EVENTS" | grep -q "ephemeral-storage\|resource"; then
        print_warn "⚠ Resource constraint detected (ephemeral-storage)"
        echo "  This may cause pods to fail even if they're running"
        echo "  Check node resources: kubectl top nodes"
    fi
    
    if echo "$EVENTS" | grep -q "time limit\|exceeds"; then
        print_warn "⚠ Pod deployment time limit exceeded"
        echo "  Pods may be taking too long to start"
        echo "  This is often a transient issue if pods are now running"
    fi
else
    print_info "  No recent warnings/errors found"
fi
echo ""

# Step 4: Check if status is stale
print_info "Step 4: Checking if status is stale..."
LAST_DEPLOYED=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.status.lastDeployed.config.lastUpdatedAt}' 2>/dev/null || echo "")
CURRENT_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [ -n "$LAST_DEPLOYED" ]; then
    echo "  Last deployed: $LAST_DEPLOYED"
    echo "  Current time: $CURRENT_TIME"
    
    # If all pods are running but status is Failure, it might be stale
    if [ "$ALL_RUNNING" = true ] && [ "$STATUS" = "Failure" ]; then
        print_warn "⚠ Status may be stale - all pods are running but status shows Failure"
        echo "  This can happen if:"
        echo "    - Previous deployment failed but current pods are healthy"
        echo "    - Operator hasn't updated status yet"
        echo "    - Resource constraints were resolved"
    fi
fi
echo ""

# Step 5: Attempt to trigger status update
print_info "Step 5: Attempting to trigger status update..."
echo ""

if [ "$ALL_RUNNING" = true ] && [ "$STATUS" = "Failure" ]; then
    print_info "All pods are running. Attempting to trigger operator reconciliation..."
    
    # Add an annotation to trigger reconciliation
    kubectl -n ${SPINNAKER_NAMESPACE} annotate spinsvc spinnaker \
        spinnaker.io/reconcile-trigger="$(date +%s)" \
        --overwrite 2>/dev/null || true
    
    print_info "  ✓ Added reconciliation trigger annotation"
    echo "  Waiting 30 seconds for operator to reconcile..."
    sleep 30
    
    NEW_STATUS=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.status.status}' 2>/dev/null || echo "Unknown")
    echo "  New status: $NEW_STATUS"
    
    if [ "$NEW_STATUS" != "Failure" ]; then
        print_info "✓ Status updated successfully!"
    else
        print_warn "⚠ Status still shows Failure"
        echo "  This may be expected if there are ongoing issues"
    fi
else
    print_info "Skipping - status update not needed or pods not all running"
fi
echo ""

# Step 6: Recommendations
echo "=========================================="
echo "Recommendations"
echo "=========================================="
echo ""

if [ "$ALL_RUNNING" = true ]; then
    print_info "✓ All pods are running - deployment is functional"
    echo ""
    if [ "$STATUS" = "Failure" ]; then
        print_warn "Status shows 'Failure' but all pods are running."
        echo "This is often a false negative. The deployment is likely working."
        echo ""
        echo "To verify functionality:"
        echo "  1. Access Spinnaker UI: kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.status.uiUrl}'"
        echo "  2. Check service health: kubectl -n ${SPINNAKER_NAMESPACE} get pods"
        echo "  3. Monitor operator logs: kubectl -n spinnaker-operator logs -l app=spinnaker-operator -c spinnaker-operator --tail=50"
    fi
else
    print_error "Some pods are not running. Fix pod issues first."
    echo ""
    echo "Check pod status:"
    echo "  kubectl -n ${SPINNAKER_NAMESPACE} get pods"
    echo ""
    echo "Check pod logs:"
    echo "  kubectl -n ${SPINNAKER_NAMESPACE} logs <pod-name>"
fi

echo ""
print_info "=========================================="
print_info "Done!"
print_info "=========================================="





