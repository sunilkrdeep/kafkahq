#!/bin/bash

# Fix spin-deck LoadBalancer - Switch from Classic LB to NLB
# This script deletes the existing service to force recreation with NLB

set -e

NAMESPACE="spinnaker"
SERVICE_NAME="spin-deck"

echo "=========================================="
echo "Fixing spin-deck LoadBalancer"
echo "=========================================="
echo ""
echo "Current LoadBalancer status:"
kubectl -n $NAMESPACE get svc $SERVICE_NAME

echo ""
echo "Step 1: Backing up current service..."
kubectl -n $NAMESPACE get svc $SERVICE_NAME -o yaml > /tmp/spin-deck-svc-backup-$(date +%Y%m%d-%H%M%S).yaml
echo "Backup saved to /tmp/spin-deck-svc-backup-*.yaml"

echo ""
echo "Step 2: Deleting existing service (this will temporarily remove the LoadBalancer)..."
kubectl -n $NAMESPACE delete svc $SERVICE_NAME

echo ""
echo "Step 3: Waiting for Spinnaker operator to recreate the service with NLB..."
echo "This may take 2-5 minutes..."

for i in {1..60}; do
    sleep 5
    LB_HOSTNAME=$(kubectl -n $NAMESPACE get svc $SERVICE_NAME -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    if [ -n "$LB_HOSTNAME" ]; then
        echo ""
        echo "✓ New LoadBalancer created!"
        echo "LoadBalancer URL: http://$LB_HOSTNAME"
        break
    fi
    echo -n "."
done

echo ""
echo ""
echo "Step 4: Verifying service..."
kubectl -n $NAMESPACE get svc $SERVICE_NAME

echo ""
echo "Step 5: Checking LoadBalancer type..."
LB_HOSTNAME=$(kubectl -n $NAMESPACE get svc $SERVICE_NAME -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -n "$LB_HOSTNAME" ]; then
    echo "LoadBalancer hostname: $LB_HOSTNAME"
    echo ""
    echo "Checking if it's an NLB..."
    aws elbv2 describe-load-balancers --query "LoadBalancers[?contains(DNSName, '${LB_HOSTNAME%%-*}')].{Name:LoadBalancerName,Type:Type,DNS:DNSName}" --output table 2>&1 || echo "Note: If this shows empty, it might still be a Classic LB. Wait a few more minutes."
fi

echo ""
echo "=========================================="
echo "Fix complete!"
echo "=========================================="
echo ""
echo "Test the LoadBalancer:"
echo "  curl -I http://$LB_HOSTNAME"
echo ""
echo "If you still see issues, wait 2-3 minutes for health checks to pass."



