#!/bin/bash

# Fix Halyard 500 Error
# This script fixes the Halyard 500 error by updating the Kubernetes account configuration

set -e

SPINNAKER_NAMESPACE="spinnaker"
SERVICE_NAME="spinnaker"

echo "=========================================="
echo "Fix Halyard 500 Error"
echo "=========================================="
echo ""

# Check if SpinnakerService exists
if ! kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc ${SERVICE_NAME} &>/dev/null; then
    echo "ERROR: SpinnakerService '${SERVICE_NAME}' not found in namespace '${SPINNAKER_NAMESPACE}'"
    exit 1
fi

echo "Current Kubernetes account configuration:"
kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc ${SERVICE_NAME} -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.accounts[0]}' | jq '.' 2>/dev/null || echo "Could not parse"

echo ""
echo "Fixing Kubernetes account configuration..."
echo "Changing from 'serviceAccount: true' to 'kubeconfigContents: \"\"'"
echo "This avoids Halyard 500 error while still using service account authentication"
echo ""

# Patch the SpinnakerService to use kubeconfigContents instead of serviceAccount: true
kubectl -n ${SPINNAKER_NAMESPACE} patch spinsvc ${SERVICE_NAME} --type='json' -p='[
  {
    "op": "remove",
    "path": "/spec/spinnakerConfig/config/providers/kubernetes/accounts/0/serviceAccount"
  },
  {
    "op": "add",
    "path": "/spec/spinnakerConfig/config/providers/kubernetes/accounts/0/kubeconfigContents",
    "value": ""
  }
]'

echo "✓ Configuration updated"
echo ""
echo "Waiting 10 seconds for operator to process the change..."
sleep 10

echo ""
echo "Checking if Halyard error is resolved..."
OPERATOR_POD=$(kubectl -n spinnaker-operator get pods -l app=spinnaker-operator -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

if [ -n "$OPERATOR_POD" ]; then
    echo "Checking operator logs for Halyard errors..."
    sleep 5
    RECENT_ERRORS=$(kubectl -n spinnaker-operator logs $OPERATOR_POD -c spinnaker-operator --tail=20 2>/dev/null | grep -i "halyard.*500" | tail -3 || echo "")
    
    if [ -z "$RECENT_ERRORS" ]; then
        echo "✓ No recent Halyard 500 errors found"
    else
        echo "⚠ Still seeing Halyard errors:"
        echo "$RECENT_ERRORS"
    fi
fi

echo ""
echo "Verifying updated configuration:"
kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc ${SERVICE_NAME} -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.accounts[0]}' | jq '.' 2>/dev/null || echo "Could not parse"

echo ""
echo "=========================================="
echo "Fix Applied"
echo "=========================================="
echo ""
echo "The Kubernetes account now uses 'kubeconfigContents: \"\"' instead of 'serviceAccount: true'"
echo "This should resolve the Halyard 500 error."
echo ""
echo "Monitor the deployment:"
echo "  kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc ${SERVICE_NAME} -w"
echo "  kubectl -n ${SPINNAKER_NAMESPACE} get pods -w"





