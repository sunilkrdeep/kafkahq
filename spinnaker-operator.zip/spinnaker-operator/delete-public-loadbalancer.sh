#!/bin/bash

# Delete Public Spinnaker LoadBalancers
# This will delete the existing public LoadBalancers and let the operator recreate them as internal

set -e

NAMESPACE="spinnaker"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

echo "=========================================="
echo "Deleting Public Spinnaker LoadBalancers"
echo "=========================================="
echo ""

echo "Step 1: Verifying SpinnakerService is configured for internal LoadBalancers..."
INTERNAL_ANNOTATION=$(kubectl -n $NAMESPACE get spinnakerservice spinnaker -o jsonpath='{.spec.expose.service.annotations.service\.beta\.kubernetes\.io/aws-load-balancer-internal}' 2>/dev/null || echo "")

if [ "$INTERNAL_ANNOTATION" != "true" ]; then
    echo "WARNING: Internal annotation not found in SpinnakerService!"
    echo "The LoadBalancers will be recreated as PUBLIC."
    echo ""
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Aborted. Please configure internal LoadBalancer first."
        exit 1
    fi
else
    echo "✓ Internal annotation confirmed - LoadBalancers will be recreated as INTERNAL"
fi

echo ""
echo "Step 2: Getting current LoadBalancer information..."
DECK_LB=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "N/A")
GATE_LB=$(kubectl -n $NAMESPACE get svc spin-gate -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "N/A")

echo "Current Deck LoadBalancer: $DECK_LB"
echo "Current Gate LoadBalancer: $GATE_LB"
echo ""

echo "Step 3: Backing up current services..."
mkdir -p /tmp/spinnaker-backups
kubectl -n $NAMESPACE get svc spin-deck -o yaml > /tmp/spinnaker-backups/spin-deck-backup-$TIMESTAMP.yaml 2>/dev/null && echo "✓ Backed up spin-deck" || echo "⚠ spin-deck service may not exist"
kubectl -n $NAMESPACE get svc spin-gate -o yaml > /tmp/spinnaker-backups/spin-gate-backup-$TIMESTAMP.yaml 2>/dev/null && echo "✓ Backed up spin-gate" || echo "⚠ spin-gate service may not exist"
echo "Backups saved to /tmp/spinnaker-backups/"
echo ""

echo "Step 4: Deleting public LoadBalancer services..."
echo "⚠ WARNING: This will cause temporary downtime (2-5 minutes)"
echo "⚠ The Spinnaker operator will automatically recreate them"
echo ""
read -p "Delete public LoadBalancers? (y/N): " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

echo ""
echo "Deleting spin-deck service..."
kubectl -n $NAMESPACE delete svc spin-deck 2>/dev/null && echo "✓ Deleted spin-deck" || echo "⚠ spin-deck may not exist"

echo "Deleting spin-gate service..."
kubectl -n $NAMESPACE delete svc spin-gate 2>/dev/null && echo "✓ Deleted spin-gate" || echo "⚠ spin-gate may not exist"

echo ""
echo "Step 5: Waiting for Spinnaker operator to recreate services..."
echo "This may take 2-5 minutes..."
echo ""

SUCCESS=false
for i in {1..60}; do
    sleep 5
    DECK_NEW=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    GATE_NEW=$(kubectl -n $NAMESPACE get svc spin-gate -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    
    if [ -n "$DECK_NEW" ] && [ "$DECK_NEW" != "N/A" ]; then
        if [ -n "$GATE_NEW" ] && [ "$GATE_NEW" != "N/A" ]; then
            echo ""
            echo "✓ New LoadBalancers created!"
            echo "Deck LoadBalancer: $DECK_NEW"
            echo "Gate LoadBalancer: $GATE_NEW"
            SUCCESS=true
            break
        fi
    fi
    echo -n "."
done

if [ "$SUCCESS" = false ]; then
    echo ""
    echo "⚠ Timeout waiting for LoadBalancers. They may still be provisioning."
    echo "Check status with: kubectl -n $NAMESPACE get svc spin-deck spin-gate"
fi

echo ""
echo "Step 6: Verifying services..."
kubectl -n $NAMESPACE get svc spin-deck spin-gate

echo ""
echo "Step 7: Verifying LoadBalancer scheme..."
DECK_LB_NEW=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
if [ -n "$DECK_LB_NEW" ] && [ "$DECK_LB_NEW" != "N/A" ]; then
    LB_PREFIX=$(echo $DECK_LB_NEW | cut -d'-' -f1)
    echo "Checking LoadBalancer scheme for: $LB_PREFIX"
    echo ""
    aws elbv2 describe-load-balancers --query "LoadBalancers[?contains(LoadBalancerName, '${LB_PREFIX}')].{Name:LoadBalancerName,Scheme:Scheme,Type:Type}" --output table 2>&1 || echo "Note: If using Classic LB, check in EC2 console"
fi

echo ""
echo "=========================================="
echo "Deletion complete!"
echo "=========================================="
echo ""
if [ "$INTERNAL_ANNOTATION" = "true" ]; then
    echo "✓ LoadBalancers are now INTERNAL (private)"
    echo "  - Accessible only from within VPC/internal network"
    echo "  - External internet access is BLOCKED"
    echo ""
    echo "To access Spinnaker:"
    echo "  - From within VPC: http://$DECK_LB_NEW"
    echo "  - Via VPN: Connect to VPC VPN first"
    echo "  - Via bastion: SSH tunnel or port forward"
else
    echo "⚠ LoadBalancers are PUBLIC (internet-facing)"
    echo "  - Accessible from internet"
    echo "  - Consider configuring as internal for security"
fi
echo ""
echo "Backups saved to: /tmp/spinnaker-backups/"


