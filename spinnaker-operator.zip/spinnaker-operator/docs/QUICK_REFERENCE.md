# Spinnaker Operator - Quick Reference

## Deployment Commands

### Automated Deployment
```bash
./deploy-spinnaker.sh
```

### Manual Step-by-Step

#### 1. Download Manifests
```bash
mkdir -p manifests && cd manifests
curl -L https://github.com/armory/spinnaker-operator/releases/download/v1.3.1/manifests.tgz -o manifests.tgz
tar -xzf manifests.tgz
```

#### 2. Install CRDs
```bash
kubectl apply -f deploy/crds/
```

#### 3. Install Operator
```bash
kubectl create namespace spinnaker-operator
kubectl -n spinnaker-operator apply -f deploy/operator/cluster/
```

#### 4. Deploy Spinnaker
```bash
kubectl create namespace spinnaker
cd deploy/spinnaker/kustomize
kustomize build . | kubectl -n spinnaker apply -f -
```

## Monitoring Commands

```bash
# Watch SpinnakerService
kubectl -n spinnaker get spinsvc spinnaker -w

# Check all pods
kubectl -n spinnaker get pods

# Check operator
kubectl -n spinnaker-operator get pods

# Get detailed status
kubectl -n spinnaker get spinsvc spinnaker -o yaml

# Check services
kubectl -n spinnaker get svc
```

## Access Spinnaker

```bash
# Get LoadBalancer URL
kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'

# Or for AWS
kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
```

Default ports:
- **Deck (UI)**: 9000
- **Gate (API)**: 8084

## Troubleshooting

```bash
# Operator logs
kubectl -n spinnaker-operator logs -l app=spinnaker-operator

# SpinnakerService events
kubectl -n spinnaker describe spinsvc spinnaker

# Pod logs
kubectl -n spinnaker logs <pod-name>

# Check CRDs
kubectl get crd | grep spinnaker
```

## Update Configuration

```bash
# Edit files in deploy/spinnaker/kustomize/
# Then rebuild and apply
cd deploy/spinnaker/kustomize
kustomize build . | kubectl -n spinnaker apply -f -
```

## Uninstall

```bash
# Remove Spinnaker
kubectl -n spinnaker delete spinsvc spinnaker

# Remove Operator
kubectl -n spinnaker-operator delete -f deploy/operator/cluster/

# Remove CRDs (optional)
kubectl delete crd spinnakerservices.spinnaker.io spinnakeraccounts.spinnaker.io
```

## Configuration Files

- `deploy/spinnaker/kustomize/spinnakerservice.yml` - Main configuration
- `deploy/spinnaker/kustomize/kustomization.yml` - Kustomize config
- `deploy/spinnaker/kustomize/*-patch.yml` - Patch files

## Key Configuration Values

- **Spinnaker Version**: 1.29.0
- **Operator Version**: v1.3.1
- **S3 Bucket**: exotel-spinnaker-qa
- **AWS Region**: us-west-2
- **AWS Account**: Exotel-prefix-staging-2
- **Kubernetes Account**: exotel-refresh (appears in pipeline account field)
- **Primary Kubernetes Account**: exotel-refresh
- **Namespace**: spinnaker
- **Operator Namespace**: spinnaker-operator

## Verify Account Configuration

```bash
# Check Kubernetes account (for pipeline account field)
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.primaryAccount}'

# Should output: exotel-refresh
```

