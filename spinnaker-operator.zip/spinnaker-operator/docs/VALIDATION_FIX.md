# Validation Error Fix

## Errors Fixed

### 1. Service Account Configuration Error

**Error**: 
```
no service account name configured in SpinnakerService for clouddriver
```

**Root Cause**: The `serviceAccount` field was commented out in `service-settings-patch.yml`, but it's required when using `serviceAccount: true` in the Kubernetes provider configuration.

**Solution**: 
- Uncommented and set `serviceAccount: spinnaker` in `service-settings-patch.yml` for both `clouddriver` and `front50`
- Added service account creation step in deployment script
- Added validation to ensure service account is configured before deployment

**File Updated**: `deploy/spinnaker/kustomize/service-settings-patch.yml`

```yaml
clouddriver:
  replicas: 1
  serviceAccount: spinnaker  # Required for Kubernetes account authentication
front50:
  replicas: 1
  serviceAccount: spinnaker  # Required for S3 access
```

### 2. AccessKeyId Missing Error

**Error**:
```
AccessKeyId is missing
```

**Root Cause**: The validation webhook checks the final merged configuration. Even though `accessKeyId` was present in the base configuration, the validator might be checking before patches are merged, or there might be a formatting issue.

**Solution**:
- Verified `accessKeyId` is present in both S3 and AWS provider configurations
- Added validation in deployment script to check merged output before applying
- Ensured proper quoting and formatting of access keys

**Files Verified**:
- `deploy/spinnaker/kustomize/spinnakerservice.yml` - Contains accessKeyId for both S3 and AWS provider

## Changes Made

### 1. `service-settings-patch.yml`
- Uncommented `serviceAccount: spinnaker` for clouddriver
- Uncommented `serviceAccount: spinnaker` for front50
- Added comments explaining why it's required

### 2. `deploy-spinnaker.sh`
- Added service account creation step before deploying SpinnakerService
- Added validation to check service account configuration in patch files
- Added validation to check S3 and AWS accessKeyId in base configuration
- Added validation to verify merged output contains all required fields
- Enhanced error messages with specific troubleshooting steps

## Deployment Process

The deployment script now:

1. **Creates Service Account**: Creates the `spinnaker` service account in the namespace
2. **Validates Configuration**: Checks all required fields before building
3. **Validates Merged Output**: Verifies the final merged YAML has all required fields
4. **Applies with Validation**: Only applies if all validations pass

## Verification

After deployment, verify the configuration:

```bash
# Check service account exists
kubectl -n spinnaker get serviceaccount spinnaker

# Check service account is configured in SpinnakerService
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.service-settings.clouddriver.serviceAccount}'
# Should output: spinnaker

# Check S3 accessKeyId is configured
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.persistentStorage.s3.accessKeyId}'
# Should output: AKIA5JUUWRSGISBSILE7

# Check AWS provider accessKeyId is configured
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.aws.accounts[0].accessKeyId}'
# Should output: AKIA5JUUWRSGISBSILE7
```

## Troubleshooting

If you still encounter validation errors:

1. **Check Service Account Exists**:
   ```bash
   kubectl -n spinnaker get serviceaccount spinnaker
   ```
   If it doesn't exist, create it:
   ```bash
   kubectl -n spinnaker create serviceaccount spinnaker
   ```

2. **Verify Merged Configuration**:
   ```bash
   cd deploy/spinnaker/kustomize
   kustomize build . | grep -A 10 "clouddriver:" | grep serviceAccount
   kustomize build . | grep -A 10 "persistentStorage:" | grep accessKeyId
   ```

3. **Check Validation Webhook Logs**:
   ```bash
   kubectl -n spinnaker-operator logs -l app=spinnaker-operator | grep -i validation
   ```

4. **Apply Base Configuration First** (if patches fail):
   ```bash
   kubectl -n spinnaker apply -f deploy/spinnaker/kustomize/spinnakerservice.yml
   ```

## Key Points

- **Service Account is Required**: When using `serviceAccount: true` in Kubernetes provider, you must specify the service account name in `service-settings.clouddriver.serviceAccount`
- **Access Keys Must Be Present**: Both S3 and AWS provider configurations must have `accessKeyId` and `secretAccessKey`
- **Validation Happens on Merged Config**: The validation webhook checks the final merged configuration, not individual files
- **Pre-validation Helps**: The deployment script now validates before applying to catch errors early





