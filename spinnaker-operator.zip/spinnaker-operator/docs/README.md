# Spinnaker Operator - Kustomize Deployment

This directory contains the configuration and scripts to deploy Spinnaker using the Spinnaker Operator with Kustomize in cluster mode.

## Quick Start

```bash
# Run the automated deployment script
./deploy-spinnaker.sh
```

## Manual Deployment

### 1. Download Operator Manifests

```bash
mkdir -p manifests && cd manifests
curl -L https://github.com/armory/spinnaker-operator/releases/download/v1.3.1/manifests.tgz -o manifests.tgz
tar -xzf manifests.tgz
```

### 2. Install CRDs

```bash
kubectl apply -f deploy/crds/
```

### 3. Install Operator (Cluster Mode)

```bash
kubectl create namespace spinnaker-operator
kubectl -n spinnaker-operator apply -f deploy/operator/cluster/
```

### 4. Deploy Spinnaker

```bash
kubectl create namespace spinnaker
cd deploy/spinnaker/kustomize
kustomize build . | kubectl -n spinnaker apply -f -
```

## Configuration

All configuration is in `deploy/spinnaker/kustomize/`:

- `spinnakerservice.yml` - Base configuration with AWS S3 and AWS provider
- `kustomization.yml` - Kustomize configuration
- `*-patch.yml` - Patch files for customization

## Current Configuration

- **Spinnaker Version**: 1.29.0
- **Operator Version**: v1.3.1
- **Storage**: AWS S3 (exotel-spinnaker-qa)
- **Region**: us-west-2
- **Kubernetes Account**: exotel-refresh (appears in pipeline account field)
- **AWS Account**: Exotel-prefix-staging-2
- **Exposure**: LoadBalancer

**Note**: The Kubernetes account `exotel-refresh` is configured as the primary account and will be available in the account dropdown when creating pipelines.

## Monitoring

```bash
# Watch SpinnakerService status
kubectl -n spinnaker get spinsvc spinnaker -w

# Check pods
kubectl -n spinnaker get pods -w

# Get LoadBalancer URL
kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
```

## Documentation

- [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) - Complete deployment guide
- [Spinnaker Operator GitHub](https://github.com/armory/spinnaker-operator)

