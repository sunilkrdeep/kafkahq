# Spinnaker Operator Deployment Guide

This guide provides step-by-step instructions for deploying Spinnaker using the Spinnaker Operator with Kustomize in cluster mode.

## Prerequisites

- Kubernetes cluster (v1.13+)
- `kubectl` configured and connected to your cluster
- `kustomize` installed (or use `kubectl kustomize` which is included in kubectl v1.14+)
- ValidatingAdmissionWebhook enabled in kube-apiserver (default in most clusters)
- AWS S3 bucket created and accessible
- AWS credentials with appropriate permissions

## Configuration

The following configuration values are used in this deployment:

```bash
OPERATOR_NAMESPACE="spinnaker-operator"
SPINNAKER_NAMESPACE="spinnaker"
OPERATOR_VERSION="v1.3.1"  # Latest stable version
SPINNAKER_VERSION="1.29.0"  # Spinnaker version
S3_BUCKET="exotel-spinnaker-qa"
AWS_REGION="us-west-2"
AWS_ACCOUNT_ID="914066148492"
AWS_ACCOUNT_NAME="Exotel-prefix-staging-2"
K8S_ACCOUNT_NAME="exotel-refresh"  # Kubernetes account for pipeline account field
EC2_KEY_PAIR="exotel"
IAM_ROLE_NAME="SpinnakerS3Role"
SERVICE_ACCOUNT_NAME="spinnaker"
```

### Account Configuration

- **Kubernetes Account**: `exotel-refresh` - This is the account that appears in the pipeline account field in Spinnaker UI
- **AWS Account**: `Exotel-prefix-staging-2` - For EC2 VM deployments
- **Primary Kubernetes Account**: `exotel-refresh` (required for pipeline deployments)

## Quick Start (Automated)

Run the deployment script:

```bash
cd spinnaker-operator
./deploy-spinnaker.sh
```

## Manual Deployment Steps

### Step 1: Download Operator Manifests

Download the Spinnaker Operator manifests from GitHub releases:

```bash
mkdir -p spinnaker-operator/manifests && cd spinnaker-operator/manifests
curl -L https://github.com/armory/spinnaker-operator/releases/download/v1.3.1/manifests.tgz -o manifests.tgz
tar -xzf manifests.tgz
```

### Step 2: Install CRDs

Install the Custom Resource Definitions (CRDs) cluster-wide:

```bash
kubectl apply -f deploy/crds/
```

Verify CRDs are installed:

```bash
kubectl get crd | grep spinnaker
```

You should see:
- `spinnakerservices.spinnaker.io`
- `spinnakeraccounts.spinnaker.io` (optional)

### Step 3: Create Operator Namespace

Create the namespace for the Spinnaker Operator:

```bash
kubectl create namespace spinnaker-operator
```

### Step 4: Install Operator (Cluster Mode)

Install the operator in cluster mode (supports validation webhooks and cross-namespace operations):

```bash
kubectl -n spinnaker-operator apply -f deploy/operator/cluster/
```

**Note:** If you're using a different namespace than `spinnaker-operator`, you need to update the namespace in `deploy/operator/cluster/role_binding.yml` before applying.

Verify the operator is running:

```bash
kubectl -n spinnaker-operator get pods
```

You should see the `spinnaker-operator` pod running.

### Step 5: Create Spinnaker Namespace

Create the namespace where Spinnaker will be deployed:

```bash
kubectl create namespace spinnaker
```

### Step 6: Deploy Spinnaker using Kustomize

Navigate to the kustomize directory and build/apply the manifests:

```bash
cd spinnaker-operator/deploy/spinnaker/kustomize
kustomize build . | kubectl -n spinnaker apply -f -
```

Or using kubectl kustomize (if kustomize is not installed):

```bash
kubectl kustomize . | kubectl -n spinnaker apply -f -
```

### Step 7: Monitor Deployment

Watch the SpinnakerService status:

```bash
kubectl -n spinnaker get spinsvc spinnaker -w
```

Check pod status:

```bash
kubectl -n spinnaker get pods -w
```

Get detailed status:

```bash
kubectl -n spinnaker get spinsvc spinnaker -o yaml
```

## Configuration Files

### Directory Structure

```
spinnaker-operator/
├── deploy-spinnaker.sh          # Automated deployment script
├── DEPLOYMENT_GUIDE.md          # This guide
└── deploy/
    └── spinnaker/
        └── kustomize/
            ├── kustomization.yml        # Kustomize configuration
            ├── spinnakerservice.yml     # Base SpinnakerService
            ├── config-patch.yml         # Configuration patches
            ├── profiles-patch.yml       # Service profile patches
            ├── files-patch.yml          # Custom file patches
            └── service-settings-patch.yml # Service settings patches
```

### Key Configuration Files

#### `spinnakerservice.yml`
Base SpinnakerService configuration with:
- Spinnaker version (1.29.0)
- AWS S3 persistent storage configuration
- AWS provider configuration
- Service profiles
- Service settings
- LoadBalancer exposure configuration

#### `kustomization.yml`
Kustomize configuration that:
- References the base SpinnakerService
- Applies patches in order

#### Patch Files
- `config-patch.yml`: Additional configuration (security, CI, canary)
- `profiles-patch.yml`: Service-specific profile customizations
- `files-patch.yml`: Custom files to include
- `service-settings-patch.yml`: Service-specific settings (replicas, service accounts)

## Customization

### Update Spinnaker Version

Edit `deploy/spinnaker/kustomize/spinnakerservice.yml`:

```yaml
config:
  version: 1.29.0  # Change to desired version
```

### Update AWS Configuration

Edit `deploy/spinnaker/kustomize/spinnakerservice.yml`:

```yaml
config:
  persistentStorage:
    s3:
      bucket: exotel-spinnaker-qa
      region: us-west-2
      accessKeyId: "YOUR_ACCESS_KEY"
      secretAccessKey: "YOUR_SECRET_KEY"
```

### Update Kubernetes Provider Account

Edit `deploy/spinnaker/kustomize/spinnakerservice.yml`:

```yaml
providers:
  kubernetes:
    enabled: true
    accounts:
      - name: exotel-refresh  # This appears in pipeline account field
        providerVersion: V2
        context: default
        serviceAccount: true
        namespaces: []
    primaryAccount: exotel-refresh  # REQUIRED: Set primary account
```

**Important**: The `primaryAccount` must be set to `exotel-refresh` for it to appear in the pipeline account dropdown in Spinnaker UI.

### Update AWS Provider Account

Edit `deploy/spinnaker/kustomize/spinnakerservice.yml`:

```yaml
providers:
  aws:
    accounts:
      - name: Exotel-prefix-staging-2
        accountId: "914066148492"
        defaultKeyPair: "exotel"
        regions:
          - name: us-west-2
```

### Scale Services

Edit `deploy/spinnaker/kustomize/service-settings-patch.yml`:

```yaml
service-settings:
  clouddriver:
    replicas: 2  # Increase replicas
```

### Use IAM Role Instead of Access Keys

If you're using IAM roles (recommended for EKS), remove `accessKeyId` and `secretAccessKey` from the configuration and ensure your service account has the appropriate IAM role attached.

## Verification

### Check SpinnakerService Status

```bash
kubectl -n spinnaker get spinsvc spinnaker
```

Status should show `OK` when deployment is complete.

### Verify Kubernetes Account Configuration

Verify that the Kubernetes account `exotel-refresh` is configured correctly:

```bash
# Check Kubernetes account name
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.accounts[0].name}'
echo ""

# Check primary Kubernetes account (this appears in pipeline account field)
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.primaryAccount}'
echo ""

# Should output: exotel-refresh
```

**Important**: The `primaryAccount` value (`exotel-refresh`) is what appears in the account dropdown when creating pipelines in Spinnaker UI.

### Verify AWS Account Configuration

```bash
# Check AWS account name
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.aws.accounts[0].name}'
echo ""

# Check primary AWS account
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.aws.primaryAccount}'
echo ""
```

### Check Pods

```bash
kubectl -n spinnaker get pods
```

All pods should be in `Running` state.

### Check Services

```bash
kubectl -n spinnaker get svc
```

You should see services for:
- `spin-deck` (UI)
- `spin-gate` (API)
- Other Spinnaker microservices

### Access Spinnaker UI

Get the LoadBalancer URL:

```bash
kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
```

Or for AWS:

```bash
kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
```

Open the URL in your browser. The default port is 9000.

### Verify Account Field in Pipeline Creation

When creating a pipeline in Spinnaker UI:

1. Navigate to Applications → Create Application
2. Create a new pipeline
3. In the pipeline configuration, check the **Account** field
4. The account dropdown should show **`exotel-refresh`** as an option
5. Select `exotel-refresh` for Kubernetes deployments

If `exotel-refresh` is not showing:
- Verify the Kubernetes account is configured: `kubectl -n spinnaker get spinsvc spinnaker -o yaml | grep -A 10 kubernetes`
- Check that `primaryAccount` is set to `exotel-refresh`
- Restart Clouddriver: `kubectl -n spinnaker rollout restart deployment/spin-clouddriver`
- Wait 2-3 minutes for Clouddriver to reinitialize accounts

## Troubleshooting

### Operator Not Starting

Check operator logs:

```bash
kubectl -n spinnaker-operator logs -l app=spinnaker-operator
```

### SpinnakerService Not Creating Pods

Check SpinnakerService status:

```bash
kubectl -n spinnaker describe spinsvc spinnaker
```

Check operator logs for errors:

```bash
kubectl -n spinnaker-operator logs -l app=spinnaker-operator --tail=100
```

### S3 Access Issues

Verify S3 bucket exists and credentials are correct:

```bash
aws s3 ls s3://exotel-spinnaker-qa --region us-west-2
```

### Pods in CrashLoopBackOff

Check pod logs:

```bash
kubectl -n spinnaker logs <pod-name>
```

### Validation Webhook Issues

If validation webhook is causing issues, you can disable it by editing the operator deployment:

```bash
kubectl -n spinnaker-operator edit deployment spinnaker-operator
```

Add `--disable-admission-controller` flag to the container args.

## Updating Spinnaker

To update Spinnaker configuration:

1. Edit the appropriate files in `deploy/spinnaker/kustomize/`
2. Rebuild and apply:

```bash
cd deploy/spinnaker/kustomize
kustomize build . | kubectl -n spinnaker apply -f -
```

The operator will detect changes and update the deployment.

## Uninstalling

### Remove Spinnaker

```bash
kubectl -n spinnaker delete spinsvc spinnaker
kubectl delete namespace spinnaker
```

### Remove Operator

```bash
kubectl -n spinnaker-operator delete -f deploy/operator/cluster/
kubectl delete namespace spinnaker-operator
```

### Remove CRDs

```bash
kubectl delete crd spinnakerservices.spinnaker.io
kubectl delete crd spinnakeraccounts.spinnaker.io
```

## Additional Resources

- [Spinnaker Operator GitHub](https://github.com/armory/spinnaker-operator)
- [Spinnaker Documentation](https://spinnaker.io/docs/)
- [SpinnakerService Options](https://github.com/armory/spinnaker-operator/blob/master/doc/spinnakerservice_options.md)

## Support

For issues and questions:
- Check the [Spinnaker Operator Issues](https://github.com/armory/spinnaker-operator/issues)
- Review Spinnaker logs: `kubectl -n spinnaker logs <service-name>`
- Check operator logs: `kubectl -n spinnaker-operator logs -l app=spinnaker-operator`

