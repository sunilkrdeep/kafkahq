# Front50 Readiness Probe Fix

## Issue

Front50 pods are failing readiness probes with "Connection refused" error:
```
Readiness probe failed: wget: can't connect to remote host: Connection refused
```

## Root Causes

### 1. Slow Spring Boot Startup (Most Common)
Front50 is a Spring Boot application that can take **3-5 minutes** to fully start, especially on first startup. The readiness probe checks `http://localhost:8080/health` every 10 seconds, but the service may not be ready yet.

**Symptoms:**
- Pod status: `Running` but `Ready: false`
- Logs show Spring Boot initialization messages
- No actual errors in logs
- Java process is running

**Solution:** Wait for the service to finish starting. Monitor with:
```bash
kubectl -n spinnaker get pods -l app=spin-front50 -w
kubectl -n spinnaker logs -l app=spin-front50 -f
```

### 2. S3 Connection Errors
Front50 cannot connect to S3 bucket, causing the service to fail during startup.

**Symptoms:**
- Logs show S3 connection errors
- `AmazonS3Client` exceptions
- `headBucket` failures
- Service crashes or fails to start

**Common Causes:**
- S3 bucket doesn't exist
- Invalid S3 credentials
- Missing IAM permissions
- Wrong region configuration

**Solution:** See S3 Configuration section below.

### 3. Readiness Probe Timeout Too Short
The readiness probe may be checking too frequently before the service is ready.

**Current Configuration:**
```yaml
readinessProbe:
  exec:
    command:
    - wget
    - --no-check-certificate
    - --spider
    - -q
    - http://localhost:8080/health
  periodSeconds: 10
  timeoutSeconds: 1
  failureThreshold: 3
```

**Solution:** The probe configuration is reasonable. The issue is usually slow startup or S3 errors.

## Solutions

### Solution 1: Wait for Service to Start (If No Errors)

If logs show Spring Boot initialization but no errors:

```bash
# Monitor pod status
kubectl -n spinnaker get pods -l app=spin-front50 -w

# Watch logs for completion
kubectl -n spinnaker logs -l app=spin-front50 -f

# Look for this message indicating startup complete:
# "Started Main in X.XXX seconds"
```

**Expected startup time:** 3-5 minutes for first startup, 1-2 minutes for subsequent starts.

### Solution 2: Fix S3 Configuration

#### Step 1: Verify S3 Bucket Exists

```bash
aws s3 ls s3://exotel-spinnaker-qa --region us-west-2
```

If bucket doesn't exist, create it:
```bash
aws s3 mb s3://exotel-spinnaker-qa --region us-west-2
```

#### Step 2: Verify S3 Credentials in SpinnakerService

```bash
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.persistentStorage.s3}' | jq '.'
```

Should show:
```json
{
  "accessKeyId": "AKIA5JUUWRSGISBSILE7",
  "bucket": "exotel-spinnaker-qa",
  "region": "us-west-2",
  "rootFolder": "front50",
  "secretAccessKey": "gK07nTs2E42s1hddS3yfGQwCmKwdjoFytPjOLri7"
}
```

#### Step 3: Verify IAM Permissions (If Using IAM Roles)

If using IAM roles instead of access keys:

```bash
# Check service account annotations
kubectl -n spinnaker get serviceaccount spinnaker -o yaml | grep -A 5 annotations

# Should have IAM role annotation:
# eks.amazonaws.com/role-arn: arn:aws:iam::ACCOUNT_ID:role/ROLE_NAME
```

The IAM role needs these S3 permissions:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket",
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": [
        "arn:aws:s3:::exotel-spinnaker-qa",
        "arn:aws:s3:::exotel-spinnaker-qa/*"
      ]
    }
  ]
}
```

#### Step 4: Restart Front50 After Fixing S3

```bash
# Delete Front50 pods to restart
kubectl -n spinnaker delete pod -l app=spin-front50

# Wait for new pods
kubectl -n spinnaker get pods -l app=spin-front50 -w
```

### Solution 3: Increase Readiness Probe Initial Delay (If Needed)

If Front50 consistently takes longer than 5 minutes to start, you can increase the initial delay:

```bash
# This would require updating the SpinnakerService or operator configuration
# Not recommended unless absolutely necessary
```

## Verification

### Check Pod Status

```bash
kubectl -n spinnaker get pods -l app=spin-front50
```

Expected: `1/1 Ready` after startup completes.

### Check Health Endpoint

```bash
FRONT50_POD=$(kubectl -n spinnaker get pods -l app=spin-front50 -o jsonpath='{.items[0].metadata.name}')
kubectl -n spinnaker exec $FRONT50_POD -- wget -q -O- http://localhost:8080/health
```

Expected: `{"status":"UP"}` or similar.

### Check Logs for Errors

```bash
kubectl -n spinnaker logs -l app=spin-front50 --tail=100 | grep -i "error\|exception\|failed"
```

Should not see S3 connection errors or startup failures.

## Current Status

Based on diagnostic script output:

1. ✅ **S3 bucket exists**: `exotel-spinnaker-qa` is accessible
2. ⚠️ **Pod 1 (spin-front50-7846545849-nff2d)**: Still starting (Spring Boot initialization)
3. ❌ **Pod 2 (spin-front50-857d568bfc-q5ch5)**: Has S3 connection errors

## Next Steps

1. **Wait for Pod 1**: Give it 2-3 more minutes to finish starting
2. **Fix Pod 2 S3 errors**: Check S3 credentials and permissions
3. **Delete failing pod**: `kubectl -n spinnaker delete pod spin-front50-857d568bfc-q5ch5`

## Quick Fix Script

Run the diagnostic script:
```bash
cd spinnaker-operator
./fix-front50-readiness.sh
```

This will:
- Verify S3 bucket exists
- Check pod status
- Check logs for errors
- Provide recommendations

## Prevention

1. **Ensure S3 bucket exists** before deploying Spinnaker
2. **Verify S3 credentials** are correct in SpinnakerService
3. **Set up IAM roles** for service accounts (recommended over access keys)
4. **Monitor Front50 logs** during first startup





