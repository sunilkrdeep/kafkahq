# CRD Validation Error Fix

## Issue

When installing CRDs, kubectl was failing with:
```
error validating "deploy/crds/spinnaker.io_spinnakeraccounts.yaml": 
error validating data: failed to download openapi: 
the server has asked for the client to provide credentials
```

## Root Cause

Kubectl tries to validate YAML files against the Kubernetes API server's OpenAPI schema before applying them. This validation requires:
1. Access to download the OpenAPI schema from the API server
2. Proper authentication/credentials
3. Network connectivity to the API server

When any of these fail, kubectl validation fails even though the CRDs themselves are valid.

## Solution

The deployment script now:
1. **First attempts** to apply CRDs with validation (normal case)
2. **Detects validation errors** related to OpenAPI schema download
3. **Automatically retries** with `--validate=false` flag if validation fails
4. **Verifies CRDs are installed** after applying

## Why `--validate=false` is Safe for CRDs

- **CRDs define their own schema**: Custom Resource Definitions are self-validating - they define the schema that will be used to validate resources later
- **No dependency on OpenAPI**: CRDs don't need the cluster's OpenAPI schema to be valid
- **Standard practice**: Many deployment tools skip validation for CRDs due to this common issue

## Changes Made

### `deploy-spinnaker.sh`

Updated Step 2 to:
- Try normal apply first
- Detect OpenAPI validation errors
- Automatically retry with `--validate=false`
- Provide clear error messages
- Verify CRDs are installed after applying

## Verification

After CRD installation, the script verifies:

```bash
# Check if CRDs are installed
kubectl get crd spinnakerservices.spinnaker.io
kubectl get crd spinnakeraccounts.spinnaker.io
```

## Manual Fix (if needed)

If the script still fails, you can manually install CRDs:

```bash
cd spinnaker-operator/manifests
kubectl apply --validate=false -f deploy/crds/
```

## Troubleshooting

If CRD installation continues to fail:

1. **Check kubectl access**:
   ```bash
   kubectl cluster-info
   kubectl get nodes
   ```

2. **Check authentication**:
   ```bash
   kubectl auth can-i create crd
   ```

3. **Try applying individual CRD files**:
   ```bash
   kubectl apply --validate=false -f deploy/crds/spinnaker.io_spinnakerservices.yaml
   kubectl apply --validate=false -f deploy/crds/spinnaker.io_spinnakeraccounts.yaml
   ```

4. **Check if CRDs already exist**:
   ```bash
   kubectl get crd | grep spinnaker
   ```
   If they exist, you can skip this step.

## Key Points

- **Validation errors are common**: OpenAPI schema download issues are a known kubectl limitation
- **Safe to skip validation for CRDs**: CRDs are self-validating
- **Automatic fallback**: The script handles this automatically
- **Verification included**: Script verifies CRDs are installed after applying





