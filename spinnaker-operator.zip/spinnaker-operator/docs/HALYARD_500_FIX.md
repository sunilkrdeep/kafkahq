# Halyard 500 Error Fix

## Root Cause

The Halyard 500 error is caused by **invalid AWS provider configuration**. Halyard does NOT accept `accessKeyId` and `secretAccessKey` directly in the AWS account configuration.

### Error from Halyard Logs

```
Unrecognized field "accessKeyId" (class com.netflix.spinnaker.halyard.config.model.v1.providers.aws.AwsAccount), 
not marked as ignorable (13 known properties: "sessionName", "assumeRole", "permissions", "externalId", 
"accountId", "name", "discovery", "environment", "requiredGroupMembership", "defaultKeyPair", "edda", 
"regions", "lifecycleHooks"])
```

**Key Point**: `accessKeyId` and `secretAccessKey` are NOT valid fields in the AWS provider account configuration in Halyard.

## Solution

### 1. Remove accessKeyId and secretAccessKey from AWS Provider

The AWS provider account configuration should NOT include `accessKeyId` and `secretAccessKey`:

```yaml
# ❌ WRONG - Causes Halyard 500 error
aws:
  enabled: true
  accounts:
    - name: Exotel-prefix-staging-2
      accountId: "914066148492"
      accessKeyId: "AKIA5JUUWRSGISBSILE7"  # ❌ NOT ALLOWED
      secretAccessKey: "gK07nTs2E42s1hddS3yfGQwCmKwdjoFytPjOLri7"  # ❌ NOT ALLOWED

# ✅ CORRECT - No access keys in account config
aws:
  enabled: true
  accounts:
    - name: Exotel-prefix-staging-2
      accountId: "914066148492"
      defaultKeyPair: "exotel"
      regions:
        - name: us-west-2
      permissions: {}
  primaryAccount: Exotel-prefix-staging-2
```

### 2. AWS Credentials Configuration

AWS credentials should be configured via:

#### Option A: IAM Roles (Recommended for AWS/EKS)
- Use IAM roles attached to the Kubernetes service account
- No need to specify credentials in SpinnakerService

#### Option B: Environment Variables
- Set `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` as environment variables in the Spinnaker pods
- Configure via `service-settings` or profiles

#### Option C: AWS Credentials File
- Mount AWS credentials file to Spinnaker pods
- Configure path via profiles

### 3. S3 Storage Configuration

For S3 persistent storage, credentials can be specified in the `persistentStorage.s3` section:

```yaml
persistentStorage:
  persistentStoreType: s3
  s3:
    bucket: exotel-spinnaker-qa
    rootFolder: front50
    region: us-west-2
    accessKeyId: "AKIA5JUUWRSGISBSILE7"  # ✅ OK for S3 storage
    secretAccessKey: "gK07nTs2E42s1hddS3yfGQwCmKwdjoFytPjOLri7"  # ✅ OK for S3 storage
```

**Note**: S3 storage configuration CAN have access keys, but AWS provider accounts CANNOT.

## Fixed Configuration

### Updated `spinnakerservice.yml`

1. **Removed `accessKeyId` and `secretAccessKey` from AWS provider account**
2. **Kept `accessKeyId` and `secretAccessKey` in S3 storage configuration** (this is correct)
3. **Changed Kubernetes account from `serviceAccount: true` to `kubeconfigContents: ""`** (avoids another potential Halyard issue)

## Apply the Fix

### Option 1: Update via Kustomize (Recommended)

```bash
cd spinnaker-operator/deploy/spinnaker/kustomize
kubectl delete validatingwebhookconfiguration spinnakervalidatingwebhook
kubectl -n spinnaker apply -f <(kustomize build .)
```

### Option 2: Patch Existing SpinnakerService

```bash
kubectl -n spinnaker patch spinsvc spinnaker --type='json' -p='[
  {
    "op": "remove",
    "path": "/spec/spinnakerConfig/config/providers/aws/accounts/0/accessKeyId"
  },
  {
    "op": "remove",
    "path": "/spec/spinnakerConfig/config/providers/aws/accounts/0/secretAccessKey"
  }
]'
```

## Verification

After applying the fix:

1. **Check Halyard logs** - should no longer see "Unrecognized field 'accessKeyId'" errors:
   ```bash
   kubectl -n spinnaker-operator logs -l app=spinnaker-operator -c halyard --tail=50 | grep -i "accessKeyId\|500"
   ```

2. **Check operator logs** - should no longer see Halyard 500 errors:
   ```bash
   kubectl -n spinnaker-operator logs -l app=spinnaker-operator -c spinnaker-operator --tail=50 | grep -i "halyard.*500"
   ```

3. **Check SpinnakerService status**:
   ```bash
   kubectl -n spinnaker get spinsvc spinnaker
   ```

## Why This Happens

Halyard uses a strict schema for AWS provider accounts. The schema only allows these fields:
- `sessionName`
- `assumeRole`
- `permissions`
- `externalId`
- `accountId`
- `name`
- `discovery`
- `environment`
- `requiredGroupMembership`
- `defaultKeyPair`
- `edda`
- `regions`
- `lifecycleHooks`

**`accessKeyId` and `secretAccessKey` are NOT in this list**, so Halyard rejects them with a 500 error.

## AWS Credentials Best Practices

1. **Use IAM Roles**: Attach IAM roles to Kubernetes service accounts (best practice)
2. **Environment Variables**: Set credentials as environment variables if IAM roles aren't available
3. **Separate S3 Config**: S3 storage can have its own credentials (different from AWS provider)

## Summary

- ✅ **S3 storage**: Can have `accessKeyId` and `secretAccessKey`
- ❌ **AWS provider accounts**: Cannot have `accessKeyId` and `secretAccessKey`
- ✅ **Solution**: Remove access keys from AWS provider, use IAM roles or environment variables instead





