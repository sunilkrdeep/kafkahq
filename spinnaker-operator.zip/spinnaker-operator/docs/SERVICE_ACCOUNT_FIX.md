# Service Account and AccessKeyId Fix

## Issue

The validation webhook was failing with:
1. "no service account name configured in SpinnakerService for clouddriver"
2. "AccessKeyId is missing"

## Root Cause

The service account was only in the patch file (`service-settings-patch.yml`), but the validation webhook checks the base resource before patches are fully processed. The validator needs the service account to be in the base `spinnakerservice.yml` file.

## Solution

### 1. Added Service Account to Base File

Updated `spinnakerservice.yml` to include the service account directly in the base configuration:

```yaml
service-settings:
  clouddriver:
    serviceAccount: spinnaker  # Required for Kubernetes account authentication
  front50:
    serviceAccount: spinnaker  # Required for S3 access
```

This ensures the service account is present in the base resource, not just in patches.

### 2. Enhanced Validation

The deployment script now:
- Validates service account is in the base file (not just patches)
- Validates merged output contains service account
- Saves merged output for debugging if validation fails
- Shows preview of critical configuration before applying
- Provides detailed error messages with debugging steps

### 3. Improved Error Handling

- Saves merged YAML to `/tmp/spinnaker-merged-output.yaml` for inspection
- Saves kubectl apply output to `/tmp/kubectl-apply.log`
- Provides fallback to apply base configuration only if patches fail
- Shows preview of service account and accessKeyId before applying

## Files Updated

1. **spinnakerservice.yml**: Added `serviceAccount: spinnaker` to `clouddriver` and `front50` in `service-settings`
2. **deploy-spinnaker.sh**: Enhanced validation and error handling

## Verification

After deployment, verify:

```bash
# Check service account is configured
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.service-settings.clouddriver.serviceAccount}'
# Should output: spinnaker

# Check S3 accessKeyId
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.persistentStorage.s3.accessKeyId}'
# Should output: AKIA5JUUWRSGISBSILE7
```

## Debugging

If validation still fails:

1. **Check merged output**:
   ```bash
   cat /tmp/spinnaker-merged-output.yaml | grep -A 10 "service-settings:"
   ```

2. **Check kubectl apply logs**:
   ```bash
   cat /tmp/kubectl-apply.log
   ```

3. **Verify service account exists**:
   ```bash
   kubectl -n spinnaker get serviceaccount spinnaker
   ```

4. **Apply base configuration manually**:
   ```bash
   kubectl -n spinnaker apply -f deploy/spinnaker/kustomize/spinnakerservice.yml
   ```

## Key Points

- **Service Account Must Be in Base File**: The validation webhook checks the base resource, so the service account must be in `spinnakerservice.yml`, not just in patches
- **AccessKeyId Must Be Present**: Both S3 and AWS provider must have `accessKeyId` configured
- **Validation Happens Before Apply**: The webhook validates the resource before it's created, so all required fields must be in the base configuration
- **Patches Are Applied After**: Patches are merged by kustomize, but the webhook may validate before patches are fully processed





