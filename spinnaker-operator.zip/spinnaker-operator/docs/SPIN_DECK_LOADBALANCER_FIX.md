# Fix spin-deck LoadBalancer Access Issue

## Problem

The spin-deck LoadBalancer URL was accessible before but is now returning "Empty reply from server" errors.

## Root Cause

The service is using a **Classic Load Balancer** which has issues with HTTP traffic routing. The SpinnakerService has been updated to use **Network Load Balancer (NLB)** with proper annotations, but Kubernetes doesn't automatically recreate LoadBalancer services when annotations change.

## Solution

### Option 1: Delete and Recreate Service (Recommended)

The service needs to be deleted to force recreation with the new NLB configuration:

```bash
cd spinnaker-operator
./fix-spin-deck-loadbalancer.sh
```

Or manually:

```bash
# 1. Backup current service
kubectl -n spinnaker get svc spin-deck -o yaml > spin-deck-backup.yaml

# 2. Delete the service (Spinnaker operator will recreate it)
kubectl -n spinnaker delete svc spin-deck

# 3. Wait 2-5 minutes for new NLB to be created
kubectl -n spinnaker get svc spin-deck -w

# 4. Get new LoadBalancer URL
kubectl -n spinnaker get svc spin-deck
```

### Option 2: Fix Classic Load Balancer Health Check (Temporary)

If you can't delete the service right now, the health check has been updated to use HTTP instead of TCP:

```bash
# Health check already updated to: HTTP:32346/
# Wait 2-3 minutes for health checks to stabilize
```

However, Classic Load Balancers may still have issues with HTTP traffic, so Option 1 is recommended.

## Verification

After the fix:

1. **Check service status:**
   ```bash
   kubectl -n spinnaker get svc spin-deck
   ```

2. **Test LoadBalancer URL:**
   ```bash
   LB_HOSTNAME=$(kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
   curl -I http://$LB_HOSTNAME
   ```

3. **Verify it's an NLB:**
   ```bash
   aws elbv2 describe-load-balancers --query "LoadBalancers[?contains(DNSName, 'your-lb-prefix')].Type" --output text
   ```

## Current Configuration

The SpinnakerService has been updated with:

```yaml
expose:
  service:
    annotations:
      service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
      service.beta.kubernetes.io/aws-load-balancer-backend-protocol: "http"
      service.beta.kubernetes.io/aws-load-balancer-connection-idle-timeout: "3600"
      service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
    type: LoadBalancer
```

## Notes

- **Downtime**: Deleting the service will cause temporary downtime (2-5 minutes) while the new NLB is provisioned
- **URL Change**: The LoadBalancer URL will change when switching from Classic LB to NLB
- **Health Checks**: NLB uses target group health checks which are more reliable for HTTP traffic

## Troubleshooting

If the new NLB still doesn't work:

1. **Check pod status:**
   ```bash
   kubectl -n spinnaker get pods -l app=spin,cluster=spin-deck
   ```

2. **Check service endpoints:**
   ```bash
   kubectl -n spinnaker get endpoints spin-deck
   ```

3. **Check pod logs:**
   ```bash
   kubectl -n spinnaker logs -l app=spin,cluster=spin-deck --tail=50
   ```

4. **Check security groups:**
   - Ensure security groups allow inbound traffic on port 80 from 0.0.0.0/0
   - Ensure node security groups allow traffic from the load balancer



