# Configure Spinnaker LoadBalancer as Internal/Private

This guide explains how to configure Spinnaker LoadBalancers to be accessible only from the internal network (VPC), not from the public internet.

## Overview

By default, AWS LoadBalancers are created as **internet-facing** (public). To make them **internal** (private), you need to:

1. Add the `internal: "true"` annotation to the SpinnakerService
2. Delete and recreate the LoadBalancer services

## Quick Start

### Option 1: Automated Script (Recommended)

```bash
cd spinnaker-operator

# Step 1: Configure the annotation
./configure-internal-loadbalancer.sh

# Step 2: Apply the configuration (deletes and recreates services)
./apply-internal-loadbalancer.sh
```

### Option 2: Manual Configuration

#### Step 1: Add Internal Annotation

```bash
kubectl -n spinnaker patch spinnakerservice spinnaker --type='json' \
  -p='[{"op": "add", "path": "/spec/expose/service/annotations/service.beta.kubernetes.io~1aws-load-balancer-internal", "value": "true"}]'
```

Verify:
```bash
kubectl -n spinnaker get spinnakerservice spinnaker -o jsonpath='{.spec.expose.service.annotations}' | jq .
```

#### Step 2: Delete and Recreate Services

```bash
# Delete existing services (operator will recreate with internal config)
kubectl -n spinnaker delete svc spin-deck spin-gate

# Wait 2-5 minutes for new internal LoadBalancers
kubectl -n spinnaker get svc spin-deck spin-gate -w
```

## Configuration Details

### Current Configuration

The SpinnakerService is configured with:

```yaml
expose:
  service:
    annotations:
      service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
      service.beta.kubernetes.io/aws-load-balancer-backend-protocol: "http"
      service.beta.kubernetes.io/aws-load-balancer-connection-idle-timeout: "3600"
      service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
      service.beta.kubernetes.io/aws-load-balancer-internal: "true"  # <-- Internal annotation
    type: LoadBalancer
```

### What Changes

**Before (Public LoadBalancer):**
- Accessible from internet
- Public DNS name (e.g., `xxx-xxx.us-west-2.elb.amazonaws.com`)
- Scheme: `internet-facing`

**After (Internal LoadBalancer):**
- Accessible only from VPC/internal network
- Internal DNS name (same format, but resolves to private IP)
- Scheme: `internal`
- **Not accessible from public internet**

## Access Methods

Once configured as internal, you can access Spinnaker via:

### 1. From Within VPC

```bash
# Get internal LoadBalancer URL
LB_HOSTNAME=$(kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Access from EC2 instance in same VPC
curl http://$LB_HOSTNAME
```

### 2. Via VPN

1. Connect to your VPC VPN
2. Access using the internal LoadBalancer URL

### 3. Via Bastion/Jump Host

```bash
# SSH tunnel through bastion
ssh -L 9000:$LB_HOSTNAME:80 user@bastion-host

# Then access: http://localhost:9000
```

### 4. Via kubectl Port-Forward (Temporary)

```bash
# Port forward Deck service
kubectl -n spinnaker port-forward svc/spin-deck 9000:80

# Access: http://localhost:9000
```

## Verification

### Check LoadBalancer Scheme

```bash
# Get LoadBalancer hostname
LB_HOSTNAME=$(kubectl -n spinnaker get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Extract prefix
LB_PREFIX=$(echo $LB_HOSTNAME | cut -d'-' -f1)

# Check scheme (should be "internal")
aws elbv2 describe-load-balancers \
  --query "LoadBalancers[?contains(LoadBalancerName, '${LB_PREFIX}')].{Name:LoadBalancerName,Scheme:Scheme,Type:Type}" \
  --output table
```

Expected output:
```
Name                    Scheme     Type
----------------------  ---------  -----
xxx-xxx                  internal   network
```

### Test Access

```bash
# From within VPC (should work)
curl -I http://$LB_HOSTNAME

# From outside VPC (should fail/timeout)
# This confirms it's internal-only
```

## Security Groups

Ensure security groups allow traffic from your internal network:

**LoadBalancer Security Group:**
- Inbound: Port 80 from VPC CIDR (e.g., `10.0.0.0/16`)
- Inbound: Port 8084 from VPC CIDR (for Gate API)

**Node Security Groups:**
- Allow traffic from LoadBalancer security group

## Troubleshooting

### LoadBalancer Still Public

**Issue:** After applying configuration, LoadBalancer is still accessible from internet.

**Solution:**
1. Verify annotation is set:
   ```bash
   kubectl -n spinnaker get spinnakerservice spinnaker -o jsonpath='{.spec.expose.service.annotations.service\.beta\.kubernetes\.io/aws-load-balancer-internal}'
   ```
   Should return: `true`

2. Delete and recreate services:
   ```bash
   kubectl -n spinnaker delete svc spin-deck spin-gate
   # Wait for recreation
   ```

### Cannot Access from VPC

**Issue:** Cannot access LoadBalancer even from within VPC.

**Check:**
1. Security groups allow traffic from your IP/CIDR
2. LoadBalancer is in correct subnets (private subnets for internal LB)
3. DNS resolution:
   ```bash
   nslookup $LB_HOSTNAME
   # Should resolve to private IP (10.x.x.x)
   ```

### Subnet Configuration

For internal LoadBalancers, ensure:
- Subnets are tagged: `kubernetes.io/role/internal-elb=1`
- Subnets are in private availability zones
- Route tables don't route to internet gateway

## Reverting to Public LoadBalancer

To make LoadBalancers public again:

```bash
# Remove internal annotation
kubectl -n spinnaker patch spinnakerservice spinnaker --type='json' \
  -p='[{"op": "remove", "path": "/spec/expose/service/annotations/service.beta.kubernetes.io~1aws-load-balancer-internal"}]'

# Delete and recreate services
kubectl -n spinnaker delete svc spin-deck spin-gate
```

## Notes

- **Downtime:** Deleting services causes 2-5 minutes of downtime
- **URL Change:** LoadBalancer URL will change when recreated
- **Cost:** Internal LoadBalancers have the same cost as public ones
- **Performance:** No performance difference, only access restriction

## Related Files

- `configure-internal-loadbalancer.sh` - Adds internal annotation
- `apply-internal-loadbalancer.sh` - Applies configuration (deletes/recreates)
- `SPIN_DECK_LOADBALANCER_FIX.md` - General LoadBalancer troubleshooting


