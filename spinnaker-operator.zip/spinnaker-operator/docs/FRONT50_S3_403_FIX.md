# Front50 S3 403 Forbidden Error Fix

## Root Cause

Front50 is failing with **S3 403 Forbidden** error:

```
AmazonS3Exception: Forbidden (Service: Amazon S3; Status Code: 403; Error Code: 403 Forbidden
```

**This means:**
- ✅ S3 credentials are configured correctly
- ✅ S3 bucket exists (`exotel-spinnaker-qa`)
- ❌ **IAM user doesn't have permissions** to access the bucket

## The Problem

The IAM user associated with access key `AKIA5JUUWRSGISBSILE7` doesn't have the necessary S3 permissions for bucket `exotel-spinnaker-qa`.

## Solution

### Step 1: Verify IAM User Permissions

Check the IAM user policy for the access key:

```bash
# Find the IAM user associated with the access key
# (You'll need AWS Console access or AWS CLI with admin permissions)

aws iam list-users
aws iam list-access-keys --user-name <USER_NAME>
```

### Step 2: Add Required S3 Permissions

The IAM user needs these S3 permissions for the bucket:

**Option A: Full S3 Access to the Bucket (Recommended for Spinnaker)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket",
        "s3:GetBucketLocation",
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:ListBucketMultipartUploads",
        "s3:AbortMultipartUpload",
        "s3:ListMultipartUploadParts"
      ],
      "Resource": [
        "arn:aws:s3:::exotel-spinnaker-qa",
        "arn:aws:s3:::exotel-spinnaker-qa/*"
      ]
    }
  ]
}
```

**Option B: Minimal Required Permissions**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket",
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": [
        "arn:aws:s3:::exotel-spinnaker-qa",
        "arn:aws:s3:::exotel-spinnaker-qa/*"
      ]
    }
  ]
}
```

### Step 3: Apply IAM Policy

**Via AWS Console:**

1. Go to IAM → Users
2. Find the user associated with access key `AKIA5JUUWRSGISBSILE7`
3. Go to Permissions tab
4. Click "Add permissions" → "Attach policies directly"
5. Create a new policy with the JSON above, or attach an existing S3 policy
6. Save changes

**Via AWS CLI:**

```bash
# Create policy document
cat > /tmp/spinnaker-s3-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket",
        "s3:GetBucketLocation",
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:ListBucketMultipartUploads",
        "s3:AbortMultipartUpload",
        "s3:ListMultipartUploadParts"
      ],
      "Resource": [
        "arn:aws:s3:::exotel-spinnaker-qa",
        "arn:aws:s3:::exotel-spinnaker-qa/*"
      ]
    }
  ]
}
EOF

# Create the policy
aws iam create-policy \
  --policy-name SpinnakerS3Access \
  --policy-document file:///tmp/spinnaker-s3-policy.json

# Attach policy to user (replace USER_NAME with actual IAM user name)
aws iam attach-user-policy \
  --user-name <USER_NAME> \
  --policy-arn arn:aws:iam::<ACCOUNT_ID>:policy/SpinnakerS3Access
```

### Step 4: Verify Permissions

Test S3 access with the credentials:

```bash
# Test bucket access
aws s3 ls s3://exotel-spinnaker-qa --region us-west-2

# Test write access (create a test file)
echo "test" | aws s3 cp - s3://exotel-spinnaker-qa/test.txt --region us-west-2

# Test read access
aws s3 cp s3://exotel-spinnaker-qa/test.txt - --region us-west-2

# Clean up test file
aws s3 rm s3://exotel-spinnaker-qa/test.txt --region us-west-2
```

### Step 5: Restart Front50

After fixing IAM permissions, restart Front50:

```bash
# Delete Front50 pods to restart
kubectl -n spinnaker delete pod -l app=spin-front50

# Wait for pods to restart
kubectl -n spinnaker get pods -l app=spin-front50 -w

# Check logs for successful S3 connection
kubectl -n spinnaker logs -l app=spin-front50 --tail=50 | grep -i s3
```

## Verification

After applying the fix:

1. **Check Front50 logs** - should NOT see 403 Forbidden errors:
   ```bash
   kubectl -n spinnaker logs -l app=spin-front50 --tail=100 | grep -i "403\|forbidden\|error"
   ```

2. **Check pod status** - should be `1/1 Ready`:
   ```bash
   kubectl -n spinnaker get pods -l app=spin-front50
   ```

3. **Check health endpoint**:
   ```bash
   FRONT50_POD=$(kubectl -n spinnaker get pods -l app=spin-front50 -o jsonpath='{.items[0].metadata.name}')
   kubectl -n spinnaker exec $FRONT50_POD -- wget -q -O- http://localhost:8080/health
   ```

Expected: `{"status":"UP"}` or similar.

## Alternative: Use IAM Role Instead of Access Keys

For better security, use IAM roles with service accounts instead of access keys:

1. **Create IAM role** with S3 permissions
2. **Annotate service account** with IAM role ARN:
   ```bash
   kubectl -n spinnaker annotate serviceaccount spinnaker \
     eks.amazonaws.com/role-arn=arn:aws:iam::<ACCOUNT_ID>:role/SpinnakerS3Role
   ```
3. **Remove access keys** from SpinnakerService S3 configuration
4. **Restart Front50**

## Summary

- **Error**: S3 403 Forbidden
- **Cause**: IAM user lacks S3 bucket permissions
- **Fix**: Add S3 permissions to IAM user/role
- **Verify**: Test S3 access and restart Front50

## Current Status

- ✅ S3 bucket exists: `exotel-spinnaker-qa`
- ✅ S3 credentials configured in SpinnakerService
- ❌ IAM permissions missing for bucket access
- ⏳ Waiting for IAM permissions to be added





