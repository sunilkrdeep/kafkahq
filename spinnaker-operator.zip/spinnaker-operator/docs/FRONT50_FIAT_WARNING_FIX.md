# Front50 Fiat Authentication Warning Fix

## Warning Message

```
WARN: Request GET:http://spin-fiat.spinnaker:7003/authorize/anonymous is missing [X-SPINNAKER-ACCOUNTS] authentication headers and will be treated as anonymous.
```

## Understanding the Warning

### What It Means
- **Fiat (authorization)** is enabled in your Spinnaker configuration
- **Front50** is making requests to Fiat without authentication headers
- Requests are being **treated as anonymous** (which works, but generates warnings)
- **HTTP 200** responses indicate it's working correctly

### Is This a Problem?
**No, this is a WARNING, not an ERROR.** Spinnaker is functioning correctly:
- ✅ Requests are succeeding (HTTP 200)
- ✅ Services are communicating
- ✅ Anonymous access is working
- ⚠️ Just missing authentication headers (expected for anonymous access)

## Root Cause

Your SpinnakerService has authorization enabled:
```yaml
security:
  authz:
    enabled: true
```

But you're not using authentication (OAuth, SAML, LDAP, etc.), so services make anonymous requests without the `X-SPINNAKER-ACCOUNTS` header.

## Solutions

### Option 1: Disable Fiat (Recommended if you don't need RBAC)

If you don't need user/role-based permissions, disable Fiat:

```bash
kubectl -n spinnaker patch spinsvc spinnaker --type='json' -p='[
  {
    "op": "replace",
    "path": "/spec/spinnakerConfig/config/security/authz/enabled",
    "value": false
  }
]'
```

**Or update your `spinnakerservice.yml`:**

```yaml
config:
  security:
    authz:
      enabled: false  # Disable if you don't need RBAC
```

**Benefits:**
- ✅ Removes the warning
- ✅ Simplifies configuration
- ✅ No impact if you don't need user permissions

**When to use:** If you don't need to restrict access based on users/roles.

### Option 2: Configure Fiat for Anonymous Access

Keep Fiat enabled but configure it to allow anonymous access without warnings:

**Add to `profiles/fiat.yml`:**

```yaml
profiles:
  fiat:
    defaultToUnrestrictedUser: true
    writeEnabled: true
```

**Update your `spinnakerservice.yml`:**

```yaml
profiles:
  fiat:
    defaultToUnrestrictedUser: true
    writeEnabled: true
```

**Benefits:**
- ✅ Keeps Fiat enabled (for future use)
- ✅ Reduces warnings
- ✅ Allows anonymous access

### Option 3: Set Up Proper Authentication (Advanced)

If you need RBAC, set up authentication:

1. **Configure OAuth/SAML/LDAP** in `config.security.authn`
2. **Configure Fiat** to use the authentication provider
3. **Services will automatically pass authentication headers**

**Example OAuth configuration:**

```yaml
config:
  security:
    authn:
      oauth2:
        enabled: true
        client:
          clientId: "your-client-id"
          clientSecret: "your-client-secret"
          # ... other OAuth config
    authz:
      enabled: true
      groupMembership:
        service: EXTERNAL
        google:
          enabled: true
          # ... group membership config
```

## Quick Fix Script

Use the automated fix script:

```bash
cd spinnaker-operator
./fix-front50-fiat-warning.sh
```

This script will:
1. Check current Fiat configuration
2. Ask if you need RBAC
3. Disable Fiat if not needed
4. Verify the fix

## Manual Fix (Disable Fiat)

If you don't need RBAC, disable Fiat:

```bash
# Method 1: Patch the SpinnakerService
kubectl -n spinnaker patch spinsvc spinnaker --type='json' -p='[
  {
    "op": "replace",
    "path": "/spec/spinnakerConfig/config/security/authz/enabled",
    "value": false
  }
]'

# Wait for operator to process
sleep 30

# Verify
kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.security.authz.enabled}'
# Should output: false

# Check logs (warnings should stop appearing)
kubectl -n spinnaker logs -l app.kubernetes.io/name=front50 --tail=50 | grep -i "X-SPINNAKER-ACCOUNTS"
```

## Verification

After applying the fix:

1. **Check Fiat is disabled:**
   ```bash
   kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.security.authz.enabled}'
   ```

2. **Check logs for warnings:**
   ```bash
   kubectl -n spinnaker logs -l app.kubernetes.io/name=front50 --tail=100 | grep -i "X-SPINNAKER-ACCOUNTS"
   ```
   Should see no new warnings (old log entries may still show).

3. **Verify Spinnaker still works:**
   - Access Spinnaker UI
   - Create an application
   - Verify functionality

## Current Configuration

Your current configuration has:
```yaml
security:
  authz:
    enabled: true  # ← This causes the warning
```

## Recommendation

**If you don't need user/role-based permissions:**
- ✅ **Disable Fiat** (Option 1) - Simplest and cleanest solution

**If you might need RBAC in the future:**
- ✅ **Keep Fiat enabled** but configure for anonymous access (Option 2)
- ⚠️ Warnings will still appear but won't affect functionality

**If you need RBAC now:**
- ✅ **Set up authentication** (Option 3) - Requires authentication provider

## Summary

- **Warning is harmless** - Spinnaker works correctly
- **Easiest fix**: Disable Fiat if you don't need RBAC
- **No impact**: Disabling Fiat doesn't affect core Spinnaker functionality
- **Future-proof**: You can re-enable Fiat later if needed

The warning is cosmetic and doesn't indicate a functional problem. You can safely ignore it or disable Fiat if you don't need authorization features.





