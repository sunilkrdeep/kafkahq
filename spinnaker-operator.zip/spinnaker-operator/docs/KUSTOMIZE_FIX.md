# Kustomize Configuration Fix

## Issues Fixed

### 1. Deprecated `patchesStrategicMerge` Warning

**Problem**: Kustomize was showing a deprecation warning:
```
Warning: 'patchesStrategicMerge' is deprecated. Please use 'patches' instead.
```

**Solution**: Updated `kustomization.yml` to use the new `patches` format with explicit target selectors:

```yaml
patches:
- path: config-patch.yml
  target:
    kind: SpinnakerService
    name: spinnaker
- path: profiles-patch.yml
  target:
    kind: SpinnakerService
    name: spinnaker
# ... etc
```

### 2. Patch Matching Error

**Problem**: Kustomize was failing with:
```
error: no matches for Id SpinnakerService.v1alpha2.spinnaker.io/spinnaker.[noNs]
failed to find unique target for patch
```

**Solution**: 
1. Added `namespace: spinnaker` to all patch files' metadata
2. Updated kustomization.yml to use explicit target selectors
3. Enhanced deployment script with better error handling and validation

## Files Updated

### 1. `kustomization.yml`
- Changed from `patchesStrategicMerge` to `patches` format
- Added explicit `target` selectors for each patch
- Added comments explaining the change

### 2. All Patch Files
- `config-patch.yml`
- `profiles-patch.yml`
- `files-patch.yml`
- `service-settings-patch.yml`

All now include `namespace: spinnaker` in their metadata section.

### 3. `deploy-spinnaker.sh`
Enhanced with:
- Pre-deployment validation of kustomization files
- Better error handling for kustomize build failures
- Validation of patch files
- Fallback to apply base resource only if patches fail
- Clearer error messages and troubleshooting steps

## Verification

To verify the fix works:

```bash
cd spinnaker-operator/deploy/spinnaker/kustomize

# Test kustomize build (should not show warnings)
kustomize build . > /dev/null && echo "✓ Build successful"

# Or with kubectl kustomize
kubectl kustomize . > /dev/null && echo "✓ Build successful"
```

## Deployment

The deployment script now:
1. Validates all required files exist
2. Checks for deprecated syntax
3. Validates patch files have namespace
4. Builds kustomize manifests with error handling
5. Validates output before applying
6. Falls back to base resource if patches fail

Run deployment:
```bash
./deploy-spinnaker.sh
```

## Troubleshooting

If you still encounter errors:

1. **Check kustomize version**:
   ```bash
   kustomize version
   ```
   Should be v4.0.0 or later for full `patches` support.

2. **Verify patch files have namespace**:
   ```bash
   grep -l "namespace: spinnaker" config-patch.yml profiles-patch.yml files-patch.yml service-settings-patch.yml
   ```
   All four files should be listed.

3. **Test kustomize build manually**:
   ```bash
   cd deploy/spinnaker/kustomize
   kustomize build . | head -50
   ```
   Should show valid YAML without errors.

4. **Check base resource exists**:
   ```bash
   ls -la deploy/spinnaker/kustomize/spinnakerservice.yml
   ```

## Additional Notes

- The new `patches` format is more explicit and allows better targeting
- Namespace in patch files ensures proper resource matching
- The deployment script now has fallback mechanisms if patches fail
- All validation happens before attempting to apply resources





