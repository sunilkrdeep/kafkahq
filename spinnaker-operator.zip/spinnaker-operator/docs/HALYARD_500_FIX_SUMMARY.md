# Halyard 500 Error - Root Cause and Fix

## Root Cause Identified ✅

The Halyard 500 error was caused by **invalid AWS provider configuration**:

```
Unrecognized field "accessKeyId" (class com.netflix.spinnaker.halyard.config.model.v1.providers.aws.AwsAccount)
```

**Halyard does NOT accept `accessKeyId` and `secretAccessKey` in AWS provider account configuration.**

## What Was Fixed

### 1. Removed accessKeyId/secretAccessKey from AWS Provider

**Before (❌ Causes Halyard 500):**
```yaml
aws:
  enabled: true
  accounts:
    - name: Exotel-prefix-staging-2
      accountId: "914066148492"
      accessKeyId: "AKIA5JUUWRSGISBSILE7"  # ❌ NOT ALLOWED
      secretAccessKey: "gK07nTs2E42s1hddS3yfGQwCmKwdjoFytPjOLri7"  # ❌ NOT ALLOWED
```

**After (✅ Correct):**
```yaml
aws:
  enabled: true
  accounts:
    - name: Exotel-prefix-staging-2
      accountId: "914066148492"
      defaultKeyPair: "exotel"
      regions:
        - name: us-west-2
      permissions: {}
```

### 2. Updated Kubernetes Account Configuration

Changed from `serviceAccount: true` to `kubeconfigContents: ""` to avoid potential Halyard issues:

```yaml
kubernetes:
  enabled: true
  accounts:
    - name: exotel-refresh
      providerVersion: V2
      context: default
      kubeconfigContents: ""  # Changed from serviceAccount: true
      namespaces: []
```

### 3. S3 Storage Configuration (Unchanged - This is Correct)

S3 storage CAN have access keys (this is different from AWS provider):

```yaml
persistentStorage:
  persistentStoreType: s3
  s3:
    bucket: exotel-spinnaker-qa
    accessKeyId: "AKIA5JUUWRSGISBSILE7"  # ✅ OK for S3 storage
    secretAccessKey: "gK07nTs2E42s1hddS3yfGQwCmKwdjoFytPjOLri7"  # ✅ OK for S3 storage
```

## Files Updated

1. **`spinnakerservice.yml`**: 
   - Removed `accessKeyId` and `secretAccessKey` from AWS provider account
   - Changed Kubernetes account to use `kubeconfigContents: ""`

2. **`deploy-spinnaker.sh`**: 
   - Added validation to detect and prevent `accessKeyId` in AWS provider accounts
   - Provides clear error message if invalid configuration is detected

3. **`HALYARD_500_FIX.md`**: 
   - Comprehensive documentation of the issue and solutions

## How to Configure AWS Credentials

Since AWS provider accounts cannot have access keys, use one of these methods:

### Option 1: IAM Roles (Recommended)
- Attach IAM roles to Kubernetes service accounts
- Spinnaker will use the service account's IAM role

### Option 2: Environment Variables
- Set `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` as environment variables
- Configure via `service-settings` or profiles

### Option 3: AWS Credentials File
- Mount AWS credentials file to Spinnaker pods
- Configure path via profiles

## Verification

After the fix:

1. **Check AWS provider config** (should NOT have accessKeyId):
   ```bash
   kubectl -n spinnaker get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.aws.accounts[0]}' | jq '.'
   ```

2. **Check operator logs** (should NOT see Halyard 500 errors):
   ```bash
   kubectl -n spinnaker-operator logs -l app=spinnaker-operator -c spinnaker-operator --tail=50 | grep -i "halyard.*500"
   ```

3. **Check SpinnakerService status**:
   ```bash
   kubectl -n spinnaker get spinsvc spinnaker
   ```

## Key Takeaways

- ✅ **S3 storage**: Can have `accessKeyId` and `secretAccessKey`
- ❌ **AWS provider accounts**: Cannot have `accessKeyId` and `secretAccessKey`
- ✅ **Solution**: Remove access keys from AWS provider, use IAM roles or environment variables
- ✅ **Validation**: Script now checks for this issue before applying

## Status

- ✅ Root cause identified
- ✅ Configuration fixed
- ✅ Script updated with validation
- ✅ Documentation created
- ⏳ Waiting for operator to process and verify Halyard 500 is resolved





