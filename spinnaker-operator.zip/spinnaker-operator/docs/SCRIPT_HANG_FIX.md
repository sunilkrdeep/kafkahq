# Script Hang Fix - Step 2 CRD Installation

## Issue

The deployment script was hanging at Step 2 during CRD installation. The script appeared to stop responding after showing:
```
[INFO] Step 2: Installing CRDs cluster-wide...
[INFO] Attempting to install CRDs with validation...
```

## Root Cause

The `kubectl apply` command was hanging because:
1. **OpenAPI Schema Validation**: kubectl tries to download the OpenAPI schema from the API server for validation
2. **Authentication Issues**: The cluster requires authentication that may not be properly configured
3. **Network Timeout**: The validation request was waiting indefinitely for a response
4. **No Timeout Set**: The script had no timeout, so it would wait forever

## Solution

### 1. Skip Validation by Default
- Use `--validate=false` flag by default for CRD installation
- Validation is not necessary for CRDs (they define their own schema)
- This avoids the OpenAPI schema download issue entirely

### 2. Add Timeout Protection
- Added `timeout 30` to the kubectl command
- Prevents the script from hanging indefinitely
- Provides clear error message if timeout occurs

### 3. Check for Existing CRDs
- Check if CRDs already exist before attempting installation
- Skip installation if CRDs are already present
- Saves time and avoids unnecessary operations

### 4. Cluster Connectivity Check
- Verify cluster connectivity before attempting CRD installation
- Provides early error detection
- Clear error messages if cluster is not accessible

### 5. Better Progress Indicators
- Added status messages so users know the script is working
- Shows what step is being executed
- Provides troubleshooting information on errors

## Changes Made

### `deploy-spinnaker.sh`

**Step 2 Updates:**
1. Added cluster connectivity check before CRD installation
2. Check if CRDs already exist (skip if present)
3. Use `--validate=false` by default (avoids hanging)
4. Added 30-second timeout to prevent indefinite waiting
5. Better error messages with troubleshooting steps
6. Verify CRDs after installation

## Deployment Status Check

To check if deployment completed:

```bash
# Check if CRDs are installed
kubectl get crd | grep spinnaker

# Check if operator is running
kubectl -n spinnaker-operator get pods

# Check if Spinnaker is deployed
kubectl -n spinnaker get spinsvc spinnaker
```

## Manual Recovery

If the script stopped, you can:

1. **Check current status**:
   ```bash
   kubectl get crd | grep spinnaker
   kubectl -n spinnaker-operator get pods
   ```

2. **Manually install CRDs** (if needed):
   ```bash
   cd spinnaker-operator/manifests
   kubectl apply --validate=false -f deploy/crds/
   ```

3. **Continue deployment**:
   ```bash
   # If CRDs are installed, continue from Step 3
   cd spinnaker-operator
   ./deploy-spinnaker.sh
   # The script will detect existing CRDs and skip installation
   ```

## Prevention

The updated script now:
- ✅ Checks cluster connectivity first
- ✅ Skips validation (avoids hanging)
- ✅ Has timeout protection (30 seconds)
- ✅ Checks for existing CRDs (avoids re-installation)
- ✅ Provides clear progress indicators
- ✅ Shows helpful error messages

## Key Points

- **Validation is optional**: CRDs don't need OpenAPI validation
- **Timeouts prevent hanging**: Script won't wait indefinitely
- **Idempotent**: Script can be run multiple times safely
- **Better UX**: Clear progress and error messages





