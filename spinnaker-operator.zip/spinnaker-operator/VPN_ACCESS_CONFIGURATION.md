# Configure VPN Access for Spinnaker Internal LoadBalancer

## Overview

The Spinnaker LoadBalancer is configured as **internal** (private), which means it's only accessible from within the VPC. To access it from your laptop via Cisco VPN, you need to:

1. Configure security groups to allow traffic from VPN CIDR
2. Ensure VPN routes are configured correctly
3. Verify DNS resolution

## Current Configuration

**LoadBalancers:**
- Deck (UI): `a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com`
- Gate (API): `a10df93ef349f4269b2bcc0478b207dc-31dbb1380cac5a41.elb.us-west-2.amazonaws.com`

**Security Groups:**
- Node Security Group: `sg-03ebbd6ad682c97c8`
- Additional Security Group: `sg-0044dfcfa0630e144`

**VPC:** `vpc-0fd3d6261a6100ba1` (10.3.0.0/16)

## Configuration Steps

### Step 1: Add Security Group Rules for VPN Access

Security group rules have been added to allow traffic from Exotel VPN CIDR (10.10.0.0/16):

```bash
# Port 80 (Deck UI)
aws ec2 authorize-security-group-ingress \
    --group-id sg-03ebbd6ad682c97c8 \
    --protocol tcp \
    --port 80 \
    --cidr 10.10.0.0/16 \
    --description "Allow Exotel VPN access to Spinnaker Deck"

# Port 8084 (Gate API)
aws ec2 authorize-security-group-ingress \
    --group-id sg-03ebbd6ad682c97c8 \
    --protocol tcp \
    --port 8084 \
    --cidr 10.10.0.0/16 \
    --description "Allow Exotel VPN access to Spinnaker Gate"
```

### Step 2: Verify VPN Route Configuration

Ensure your VPN connection routes traffic to the VPC CIDR (10.3.0.0/16):

1. **Check VPN Connection Routes:**
   ```bash
   aws ec2 describe-vpn-connections --vpn-connection-ids vpn-04bba399b54050136
   ```

2. **Verify Route Tables:**
   The route tables should have routes pointing to the VPN gateway for the VPC CIDR.

### Step 3: Test Access

1. **Connect to Cisco VPN**
2. **Test DNS Resolution:**
   ```bash
   nslookup a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com
   ```
   Should resolve to a private IP (10.x.x.x)

3. **Test HTTP Access:**
   ```bash
   curl -I http://a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com
   ```

## Troubleshooting

### Cannot Access from VPN

**Check 1: Security Group Rules**
```bash
aws ec2 describe-security-groups --group-ids sg-03ebbd6ad682c97c8 \
    --query "SecurityGroups[0].IpPermissions[?FromPort==\`80\` || FromPort==\`8084\`]"
```

**Check 2: VPN Connection Status**
```bash
aws ec2 describe-vpn-connections --query "VpnConnections[*].{State:State,VpnConnectionId:VpnConnectionId}"
```

**Check 3: Route Tables**
```bash
aws ec2 describe-route-tables --filters "Name=vpc-id,Values=vpc-0fd3d6261a6100ba1" \
    --query "RouteTables[*].Routes[?GatewayId==\`vgw-*\`]"
```

**Check 4: Network ACLs**
Ensure Network ACLs on the LoadBalancer subnets allow traffic from VPN CIDR.

### DNS Resolution Issues

If DNS doesn't resolve:
1. Check if you're connected to VPN
2. Verify VPN routes include the VPC CIDR
3. Try using the private IP directly (get from AWS Console)

### Connection Timeout

1. **Verify Security Groups:**
   - Check if rules are correctly added
   - Verify the VPN CIDR range (10.10.0.0/16)

2. **Check LoadBalancer Target Health:**
   ```bash
   aws elbv2 describe-target-health --target-group-arn <target-group-arn>
   ```

3. **Test from within VPC:**
   - SSH to an EC2 instance in the VPC
   - Test: `curl http://a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com`

## Alternative: Use kubectl Port-Forward

If VPN access still doesn't work, you can use kubectl port-forward as a temporary solution:

```bash
# Port forward Deck service
kubectl -n spinnaker port-forward svc/spin-deck 9000:80

# Access: http://localhost:9000
```

## Security Considerations

- The security group rules allow access from the entire VPN CIDR (10.10.0.0/16)
- For more restrictive access, you can:
  - Use specific IP ranges instead of the entire CIDR
  - Add additional security group rules for specific IPs
  - Use AWS WAF for additional protection

## Files

- `configure-vpn-access.sh` - Interactive script to configure VPN access
- `create-internal-loadbalancer-services.yaml` - Service definitions with internal LoadBalancer

## Notes

- Network Load Balancers (NLB) don't use security groups directly
- Security groups are applied to the target instances (nodes)
- Ensure both security groups (sg-03ebbd6ad682c97c8 and sg-0044dfcfa0630e144) have the rules if needed

