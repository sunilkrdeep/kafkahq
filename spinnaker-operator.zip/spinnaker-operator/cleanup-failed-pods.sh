#!/bin/bash

# Safe Cleanup Script for Failed Spinnaker Pods
# This script only deletes failed/error pods without impacting running pods

set -e

SPINNAKER_NAMESPACE="spinnaker"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "=========================================="
echo "Spinnaker Failed Pods Cleanup"
echo "=========================================="
echo ""

# Step 1: List all pods and their status
print_info "Step 1: Analyzing pod status..."
echo ""

# Get all pods
ALL_PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods -o json)

# Count pods by status
RUNNING_COUNT=$(echo "$ALL_PODS" | jq -r '.items[] | select(.status.phase == "Running" and (.status.containerStatuses[]? | .ready == true)) | .metadata.name' | wc -l | tr -d ' ')
FAILED_COUNT=$(echo "$ALL_PODS" | jq -r '.items[] | select(.status.phase == "Failed" or .status.phase == "Error" or (.status.containerStatuses[]? | .state.waiting.reason == "Error" or .state.terminated.reason == "Error")) | .metadata.name' | wc -l | tr -d ' ')
UNKNOWN_COUNT=$(echo "$ALL_PODS" | jq -r '.items[] | select(.status.phase == "Unknown" or .status.containerStatuses[]? | .state.waiting.reason == "ContainerStatusUnknown") | .metadata.name' | wc -l | tr -d ' ')

print_info "Current pod status:"
echo "  Running: $RUNNING_COUNT"
echo "  Failed/Error: $FAILED_COUNT"
echo "  Unknown: $UNKNOWN_COUNT"
echo ""

# Step 2: Identify failed pods
print_info "Step 2: Identifying failed pods to clean up..."
echo ""

FAILED_PODS=$(echo "$ALL_PODS" | jq -r '.items[] | select(.status.phase == "Failed" or .status.phase == "Error" or (.status.containerStatuses[]? | .state.waiting.reason == "Error" or .state.terminated.reason == "Error")) | .metadata.name' | sort)

UNKNOWN_PODS=$(echo "$ALL_PODS" | jq -r '.items[] | select(.status.phase == "Unknown" or (.status.containerStatuses[]? | .state.waiting.reason == "ContainerStatusUnknown")) | .metadata.name' | sort)

# Also check for pods in Error state (not just phase)
ERROR_PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods -o json | jq -r '.items[] | select(.status.containerStatuses[]? | .state.waiting.reason == "Error" or .state.terminated.reason == "Error") | .metadata.name' | sort)

# Combine all failed pods (remove duplicates)
ALL_FAILED_PODS=$(echo -e "$FAILED_PODS\n$UNKNOWN_PODS\n$ERROR_PODS" | sort -u)

if [ -z "$ALL_FAILED_PODS" ]; then
    print_info "No failed pods found. All pods are healthy!"
    exit 0
fi

print_warn "Found failed pods to clean up:"
echo "$ALL_FAILED_PODS" | while read pod; do
    if [ -n "$pod" ]; then
        STATUS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pod $pod -o jsonpath='{.status.phase}' 2>/dev/null || echo "Unknown")
        AGE=$(kubectl -n ${SPINNAKER_NAMESPACE} get pod $pod -o jsonpath='{.metadata.creationTimestamp}' 2>/dev/null || echo "Unknown")
        echo "  - $pod (Status: $STATUS, Age: $AGE)"
    fi
done
echo ""

# Step 3: Verify running pods won't be affected
print_info "Step 3: Verifying running pods are safe..."
echo ""

RUNNING_PODS=$(echo "$ALL_PODS" | jq -r '.items[] | select(.status.phase == "Running" and (.status.containerStatuses[]? | .ready == true)) | .metadata.name' | sort)

print_info "Running pods (will NOT be deleted):"
echo "$RUNNING_PODS" | while read pod; do
    if [ -n "$pod" ]; then
        SERVICE=$(echo $pod | sed 's/-[0-9].*//' | sed 's/spin-//')
        echo "  ✓ $pod ($SERVICE)"
    fi
done
echo ""

# Step 4: Check for duplicate services (multiple pods for same service)
print_info "Step 4: Checking for service duplicates..."
echo ""

SERVICE_DUPLICATES=false
for service in $(echo "$RUNNING_PODS" | sed 's/-[0-9].*//' | sort -u); do
    COUNT=$(echo "$RUNNING_PODS" | grep "^${service}-" | wc -l | tr -d ' ')
    if [ "$COUNT" -gt 1 ]; then
        print_warn "Multiple running pods for service: $service"
        SERVICE_DUPLICATES=true
    fi
done

if [ "$SERVICE_DUPLICATES" = false ]; then
    print_info "No duplicate services found. Safe to proceed."
fi
echo ""

# Step 5: Confirm deletion
print_warn "Ready to delete failed pods. This will:"
echo "  - Delete $(echo "$ALL_FAILED_PODS" | wc -l | tr -d ' ') failed/error pods"
echo "  - NOT affect $RUNNING_COUNT running pods"
echo "  - Clean up stale pod resources"
echo ""

read -p "Do you want to proceed? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    print_info "Cleanup cancelled."
    exit 0
fi

# Step 6: Delete failed pods
print_info "Step 6: Deleting failed pods..."
echo ""

DELETED_COUNT=0
FAILED_DELETE_COUNT=0

echo "$ALL_FAILED_PODS" | while read pod; do
    if [ -n "$pod" ]; then
        print_info "Deleting pod: $pod"
        if kubectl -n ${SPINNAKER_NAMESPACE} delete pod $pod --grace-period=0 --force 2>&1 | grep -q "deleted\|not found"; then
            print_info "  ✓ Deleted: $pod"
            DELETED_COUNT=$((DELETED_COUNT + 1))
        else
            print_warn "  ⚠ Could not delete: $pod (may already be deleted)"
            FAILED_DELETE_COUNT=$((FAILED_DELETE_COUNT + 1))
        fi
        sleep 1
    fi
done

echo ""
print_info "Cleanup completed!"
echo "  Deleted: $DELETED_COUNT pods"
if [ $FAILED_DELETE_COUNT -gt 0 ]; then
    echo "  Failed to delete: $FAILED_DELETE_COUNT pods (may already be deleted)"
fi
echo ""

# Step 7: Verify cleanup
print_info "Step 7: Verifying cleanup..."
echo ""

sleep 3

REMAINING_FAILED=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods -o json | jq -r '.items[] | select(.status.phase == "Failed" or .status.phase == "Error") | .metadata.name' | wc -l | tr -d ' ')

if [ "$REMAINING_FAILED" -eq 0 ]; then
    print_info "✓ All failed pods cleaned up successfully!"
else
    print_warn "⚠ $REMAINING_FAILED failed pods still remain (may be in terminating state)"
fi

# Step 8: Show final status
print_info "Step 8: Final pod status..."
echo ""

kubectl -n ${SPINNAKER_NAMESPACE} get pods | head -1
kubectl -n ${SPINNAKER_NAMESPACE} get pods | grep -E "Running|Pending|Error|Failed" | head -20

echo ""
print_info "=========================================="
print_info "Cleanup Summary"
print_info "=========================================="
echo ""
print_info "Current status:"
echo "  Running pods: $(kubectl -n ${SPINNAKER_NAMESPACE} get pods -o json | jq -r '.items[] | select(.status.phase == "Running" and (.status.containerStatuses[]? | .ready == true)) | .metadata.name' | wc -l | tr -d ' ')"
echo "  Failed pods: $(kubectl -n ${SPINNAKER_NAMESPACE} get pods -o json | jq -r '.items[] | select(.status.phase == "Failed" or .status.phase == "Error") | .metadata.name' | wc -l | tr -d ' ')"
echo ""

# Step 9: Check SpinnakerService status
print_info "Step 9: Checking SpinnakerService status..."
echo ""

SPINNAKER_STATUS=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.status.status}' 2>/dev/null || echo "Unknown")
SPINNAKER_SERVICES=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.status.services}' 2>/dev/null || echo "Unknown")

echo "  Status: $SPINNAKER_STATUS"
echo "  Services: $SPINNAKER_SERVICES"
echo ""

if [ "$SPINNAKER_STATUS" = "Success" ] || [ "$SPINNAKER_STATUS" = "Running" ]; then
    print_info "✓ SpinnakerService is healthy!"
else
    print_warn "⚠ SpinnakerService status: $SPINNAKER_STATUS"
    print_info "Monitor with: kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -w"
fi

echo ""
print_info "=========================================="
print_info "Done!"
print_info "=========================================="





