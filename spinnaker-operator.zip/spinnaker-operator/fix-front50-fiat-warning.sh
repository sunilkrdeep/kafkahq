#!/bin/bash

# Fix Front50 Fiat Authentication Warning
# Options: Disable Fiat or Configure Proper Authentication

set -e

SPINNAKER_NAMESPACE="spinnaker"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "=========================================="
echo "Fix Front50 Fiat Authentication Warning"
echo "=========================================="
echo ""

# Step 1: Check current Fiat configuration
print_info "Step 1: Checking current Fiat/Authorization configuration..."
echo ""

AUTHZ_ENABLED=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.security.authz.enabled}' 2>/dev/null || echo "false")

if [ "$AUTHZ_ENABLED" = "true" ]; then
    print_info "  Authorization (Fiat) is currently ENABLED"
else
    print_info "  Authorization (Fiat) is currently DISABLED"
fi
echo ""

# Step 2: Explain the warning
print_info "Step 2: Understanding the warning..."
echo ""
print_warn "The warning occurs because:"
echo "  - Fiat (authorization) is enabled"
echo "  - Services are making requests without X-SPINNAKER-ACCOUNTS headers"
echo "  - Requests are being treated as anonymous (which is working, just not optimal)"
echo ""
print_info "This is a WARNING, not an ERROR. Spinnaker is functioning correctly."
echo ""

# Step 3: Provide options
echo "=========================================="
echo "Fix Options"
echo "=========================================="
echo ""

echo "Option 1: Disable Fiat (Recommended if you don't need RBAC)"
echo "  - Simplest solution"
echo "  - Removes the warning"
echo "  - Use if you don't need user/role-based permissions"
echo ""

echo "Option 2: Keep Fiat enabled but suppress warnings"
echo "  - Configure Fiat to allow anonymous access"
echo "  - Warnings will still appear but won't affect functionality"
echo ""

echo "Option 3: Configure proper authentication (Advanced)"
echo "  - Set up authentication (OAuth, SAML, etc.)"
echo "  - Configure services to pass authentication headers"
echo "  - Requires authentication provider setup"
echo ""

# Step 4: Ask user preference
read -p "Do you need RBAC/user permissions? (yes/no): " NEED_RBAC

if [ "$NEED_RBAC" != "yes" ]; then
    print_info "Disabling Fiat (authorization)..."
    echo ""
    
    # Disable authz
    kubectl -n ${SPINNAKER_NAMESPACE} patch spinsvc spinnaker --type='json' -p='[
      {
        "op": "replace",
        "path": "/spec/spinnakerConfig/config/security/authz/enabled",
        "value": false
      }
    ]'
    
    print_info "✓ Authorization disabled"
    echo ""
    print_info "Waiting 30 seconds for changes to take effect..."
    sleep 30
    
    print_info "Checking if warning is resolved..."
    sleep 10
    
    WARNINGS=$(kubectl -n ${SPINNAKER_NAMESPACE} logs -l app.kubernetes.io/name=front50 --tail=50 2>&1 | grep -i "X-SPINNAKER-ACCOUNTS" | wc -l | tr -d ' ')
    
    if [ "$WARNINGS" -eq 0 ]; then
        print_info "✓ Warning resolved! No more X-SPINNAKER-ACCOUNTS warnings in recent logs."
    else
        print_warn "⚠ Warning may still appear in old log entries. Check new logs after a few minutes."
    fi
    
else
    print_info "Keeping Fiat enabled. To suppress warnings, you can:"
    echo ""
    echo "1. Configure Fiat to allow anonymous access (in profiles/fiat.yml):"
    echo "   fiat:"
    echo "     defaultToUnrestrictedUser: true"
    echo ""
    echo "2. Or set up proper authentication (OAuth, SAML, LDAP, etc.)"
    echo ""
    print_warn "Note: The warning is harmless if you're using anonymous access."
    echo "Spinnaker will continue to work correctly."
fi

echo ""
print_info "=========================================="
print_info "Done!"
print_info "=========================================="





