# VPN Access Configuration Summary

## ✅ Configuration Complete

Security group rules have been successfully added to allow access to Spinnaker LoadBalancer from Exotel Cisco VPN.

## Configuration Details

### LoadBalancer URLs

**Deck (UI):**
```
http://a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com
```

**Gate (API):**
```
http://a10df93ef349f4269b2bcc0478b207dc-31dbb1380cac5a41.elb.us-west-2.amazonaws.com
```

### Security Group Rules Added

**Security Group:** `sg-03ebbd6ad682c97c8`

✅ **Port 80 (Deck UI):**
- CIDR: `10.10.0.0/16` (Exotel VPN)`
- Description: "Allow Exotel VPN access to Spinnaker Deck"
- Rule ID: `sgr-02e4947db3647d2c4`

✅ **Port 8084 (Gate API):**
- CIDR: `10.10.0.0/16` (Exotel VPN)`
- Description: "Allow Exotel VPN access to Spinnaker Gate"
- Rule ID: `sgr-0e0ef1e57bae5034b`

**Note:** Port 80 also has a rule allowing `0.0.0.0/0` (all traffic), but the specific VPN rule ensures explicit access.

## Access Instructions

### Step 1: Connect to Cisco VPN

Connect to the Exotel Cisco VPN using your credentials.

### Step 2: Access Spinnaker UI

Open your browser and navigate to:
```
http://a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com
```

### Step 3: Verify Access

You should see the Spinnaker UI login page. If you encounter issues, see the Troubleshooting section below.

## Network Configuration

**VPC:** `vpc-0fd3d6261a6100ba1` (10.3.0.0/16)
**VPN CIDR:** `10.10.0.0/16` (Exotel VPN)
**LoadBalancer Type:** Internal Network Load Balancer (NLB)
**LoadBalancer Scheme:** Internal (private)

## Troubleshooting

### Issue: Cannot Access from VPN

**Check 1: VPN Connection**
```bash
# Verify you're connected to VPN
# Check your IP address - should be in 10.10.x.x range
ipconfig  # Windows
ifconfig  # Mac/Linux
```

**Check 2: DNS Resolution**
```bash
# Test DNS resolution
nslookup a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com

# Should resolve to a private IP (10.3.x.x)
```

**Check 3: Security Group Rules**
```bash
# Verify rules are present
aws ec2 describe-security-groups --group-ids sg-03ebbd6ad682c97c8 \
    --query "SecurityGroups[0].IpPermissions[?FromPort==\`80\` || FromPort==\`8084\`]"
```

**Check 4: Test Connectivity**
```bash
# Test HTTP connection
curl -I http://a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com

# Should return HTTP 200 or 302 (redirect)
```

### Issue: Connection Timeout

1. **Verify VPN Routes:**
   - Ensure VPN routes include VPC CIDR (10.3.0.0/16)
   - Check VPN connection status in AWS Console

2. **Check LoadBalancer Health:**
   ```bash
   # Get target group ARN
   aws elbv2 describe-target-groups --load-balancer-arn <lb-arn>
   
   # Check target health
   aws elbv2 describe-target-health --target-group-arn <tg-arn>
   ```

3. **Verify Subnet Routes:**
   - Ensure LoadBalancer subnets have routes to VPN gateway
   - Check route tables for the LoadBalancer subnets

### Issue: DNS Not Resolving

If DNS doesn't resolve from VPN:
1. Check if VPN is properly connected
2. Verify VPN DNS settings
3. Try accessing via private IP (get from AWS Console)
4. Use `/etc/hosts` file as temporary workaround:
   ```
   <private-ip> a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com
   ```

## Alternative Access Methods

### Option 1: kubectl Port-Forward

If VPN access still doesn't work:
```bash
# Port forward Deck service
kubectl -n spinnaker port-forward svc/spin-deck 9000:80

# Access: http://localhost:9000
```

### Option 2: SSH Tunnel via Bastion

```bash
# SSH tunnel through bastion host
ssh -L 9000:a89975196e5d1429788a063ab215d41d-a44fae3998f1e07e.elb.us-west-2.amazonaws.com:80 user@bastion-host

# Access: http://localhost:9000
```

## Security Notes

- ✅ Access is restricted to Exotel VPN CIDR (10.10.0.0/16)
- ✅ LoadBalancer is internal (not accessible from public internet)
- ✅ Security group rules are specific to required ports (80, 8084)

## Files Created

- `configure-vpn-access.sh` - Interactive script for VPN configuration
- `VPN_ACCESS_CONFIGURATION.md` - Detailed configuration guide
- `VPN_ACCESS_SUMMARY.md` - This summary document

## Next Steps

1. **Test Access:** Connect to VPN and try accessing the LoadBalancer URL
2. **Verify:** Confirm you can see the Spinnaker UI
3. **Report Issues:** If access doesn't work, check the troubleshooting section

## Support

If you continue to experience issues:
1. Check VPN connection status
2. Verify your IP is in the 10.10.0.0/16 range when connected
3. Test DNS resolution
4. Check AWS Console for LoadBalancer and security group status

