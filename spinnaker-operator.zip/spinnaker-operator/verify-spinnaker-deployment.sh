#!/bin/bash

# Verify Spinnaker Deployment Status
# Checks all components and provides health status

set -e

SPINNAKER_NAMESPACE="spinnaker"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "=========================================="
echo "Spinnaker Deployment Verification"
echo "=========================================="
echo ""

# Step 1: Check SpinnakerService
print_info "Step 1: Checking SpinnakerService..."
SPINNAKER_SVC=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o json 2>/dev/null || echo "")
if [ -z "$SPINNAKER_SVC" ]; then
    print_error "SpinnakerService not found!"
    exit 1
fi

VERSION=$(echo "$SPINNAKER_SVC" | jq -r '.spec.spinnakerConfig.config.version // "unknown"')
STATUS=$(echo "$SPINNAKER_SVC" | jq -r '.status.status // "unknown"')
SERVICES=$(echo "$SPINNAKER_SVC" | jq -r '.status.services // "unknown"')
URL=$(echo "$SPINNAKER_SVC" | jq -r '.status.url // "N/A"')

echo "  Version: $VERSION"
echo "  Status: $STATUS"
echo "  Services: $SERVICES"
echo "  URL: $URL"
echo ""

# Step 2: Check all Spinnaker services
print_info "Step 2: Checking Spinnaker service pods..."
echo ""

EXPECTED_SERVICES=("clouddriver" "deck" "echo" "fiat" "front50" "gate" "igor" "kayenta" "orca" "rosco")
ALL_HEALTHY=true

for service in "${EXPECTED_SERVICES[@]}"; do
    # Use correct label selector: app.kubernetes.io/name=${service}
    PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods -l app.kubernetes.io/name=${service} -o json 2>/dev/null || echo "[]")
    
    RUNNING_PODS=$(echo "$PODS" | jq -r '.items[] | select(.status.phase == "Running" and (.status.containerStatuses[]? | .ready == true)) | .metadata.name' | wc -l | tr -d ' ')
    FAILED_PODS=$(echo "$PODS" | jq -r '.items[] | select(.status.phase == "Failed" or .status.phase == "Error") | .metadata.name' | wc -l | tr -d ' ')
    TOTAL_PODS=$(echo "$PODS" | jq -r '.items | length')
    
    if [ "$RUNNING_PODS" -ge 1 ]; then
        print_info "  ✓ $service: $RUNNING_PODS/$TOTAL_PODS running"
        if [ "$FAILED_PODS" -gt 0 ]; then
            print_warn "    ($FAILED_PODS failed pods need cleanup)"
            ALL_HEALTHY=false
        fi
    else
        print_error "  ✗ $service: No running pods ($TOTAL_PODS total, $FAILED_PODS failed)"
        ALL_HEALTHY=false
    fi
done
echo ""

# Step 3: Check supporting services
print_info "Step 3: Checking supporting services..."
echo ""

# Redis
REDIS_PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods -l app.kubernetes.io/name=redis -o json 2>/dev/null || echo "[]")
REDIS_RUNNING=$(echo "$REDIS_PODS" | jq -r '.items[] | select(.status.phase == "Running" and (.status.containerStatuses[]? | .ready == true)) | .metadata.name' | wc -l | tr -d ' ')

if [ "$REDIS_RUNNING" -ge 1 ]; then
    print_info "  ✓ Redis: Running"
else
    print_error "  ✗ Redis: Not running"
    ALL_HEALTHY=false
fi
echo ""

# Step 4: Check LoadBalancer services
print_info "Step 4: Checking LoadBalancer services..."
echo ""

LB_SERVICES=$(kubectl -n ${SPINNAKER_NAMESPACE} get svc -o json | jq -r '.items[] | select(.spec.type == "LoadBalancer") | "\(.metadata.name)\t\(.status.loadBalancer.ingress[0].hostname // .status.loadBalancer.ingress[0].ip // "Pending")"' | column -t)

if [ -n "$LB_SERVICES" ]; then
    echo "$LB_SERVICES"
else
    print_warn "  No LoadBalancer services found"
fi
echo ""

# Step 5: Summary
echo "=========================================="
echo "Verification Summary"
echo "=========================================="
echo ""

if [ "$ALL_HEALTHY" = true ] && [ "$STATUS" = "Success" ]; then
    print_info "✓ Spinnaker deployment is healthy!"
    echo ""
    print_info "Access Spinnaker UI:"
    if [ "$URL" != "N/A" ] && [ "$URL" != "null" ]; then
        echo "  $URL"
    else
        DECK_LB=$(kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
        if [ -n "$DECK_LB" ]; then
            echo "  http://$DECK_LB"
        else
            echo "  (LoadBalancer pending - check with: kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-deck)"
        fi
    fi
else
    print_warn "⚠ Spinnaker deployment has issues:"
    if [ "$ALL_HEALTHY" != true ]; then
        echo "  - Some services are not running properly"
    fi
    if [ "$STATUS" != "Success" ]; then
        echo "  - SpinnakerService status: $STATUS"
    fi
    echo ""
    print_info "Next steps:"
    echo "  1. Check pod logs: kubectl -n ${SPINNAKER_NAMESPACE} logs <pod-name>"
    echo "  2. Clean up failed pods: ./cleanup-failed-pods.sh"
    echo "  3. Check SpinnakerService: kubectl -n ${SPINNAKER_NAMESPACE} describe spinsvc spinnaker"
fi

echo ""

