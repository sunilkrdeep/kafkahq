#!/bin/bash

# Spinnaker Cleanup Script
# This script completely removes Spinnaker and the Spinnaker Operator

set -e

# Configuration Variables
OPERATOR_NAMESPACE="spinnaker-operator"
SPINNAKER_NAMESPACE="spinnaker"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    print_error "kubectl is not installed. Please install kubectl first."
    exit 1
fi

print_info "=========================================="
print_info "Spinnaker Cleanup Script"
print_info "=========================================="
print_info ""
print_info "This will delete:"
print_info "  - SpinnakerService and all Spinnaker resources"
print_info "  - Spinnaker Operator"
print_info "  - Namespaces: ${SPINNAKER_NAMESPACE} and ${OPERATOR_NAMESPACE}"
print_info ""
read -p "Are you sure you want to proceed? (yes/no) " -r
echo ""
if [[ ! $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
    print_warn "Cleanup cancelled"
    exit 1
fi
echo ""

# Function to remove finalizers from resources
remove_finalizers() {
    local namespace=$1
    local resource_type=$2
    
    print_info "Removing finalizers from ${resource_type} in namespace ${namespace}..."
    kubectl get ${resource_type} -n ${namespace} --no-headers 2>/dev/null | awk '{print $1}' | while read name; do
        if [ -n "$name" ]; then
            print_info "  Removing finalizers from ${resource_type}/${name}"
            kubectl patch ${resource_type} ${name} -n ${namespace} -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null || true
        fi
    done
}

# Function to force delete namespace
force_delete_namespace() {
    local namespace=$1
    
    print_info "Attempting to force delete namespace: ${namespace}"
    
    # Check if namespace exists
    if ! kubectl get namespace ${namespace} &>/dev/null; then
        print_info "Namespace ${namespace} does not exist. Skipping."
        return
    fi
    
    # Get namespace status
    NS_STATUS=$(kubectl get namespace ${namespace} -o jsonpath='{.status.phase}' 2>/dev/null || echo "NotFound")
    print_info "Namespace status: ${NS_STATUS}"
    
    if [ "$NS_STATUS" == "Terminating" ]; then
        print_warn "Namespace is stuck in Terminating state. Removing finalizers..."
        
        # Remove finalizers from all resources in the namespace
        print_info "Removing finalizers from all resources..."
        
        # Get all API resources that are namespaced
        for resource in $(kubectl api-resources --verbs=list --namespaced -o name 2>/dev/null); do
            # Skip events as they can't have finalizers
            if [[ "$resource" == "events" ]] || [[ "$resource" == "events.events.k8s.io" ]]; then
                continue
            fi
            
            # Get resources and remove finalizers
            kubectl get ${resource} -n ${namespace} --no-headers 2>/dev/null | awk '{print $1}' | while read name; do
                if [ -n "$name" ]; then
                    print_info "  Removing finalizers from ${resource}/${name}"
                    kubectl patch ${resource} ${name} -n ${namespace} -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null || true
                fi
            done
        done
        
        # Remove finalizers from namespace itself
        print_info "Removing finalizers from namespace ${namespace}..."
        kubectl get namespace ${namespace} -o json | \
            jq '.spec.finalizers = []' | \
            kubectl replace --raw /api/v1/namespaces/${namespace}/finalize -f - 2>/dev/null || {
                # Alternative method if jq is not available
                print_warn "jq not available, trying alternative method..."
                kubectl patch namespace ${namespace} -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null || true
            }
    fi
    
    # Delete namespace
    print_info "Deleting namespace ${namespace}..."
    kubectl delete namespace ${namespace} --ignore-not-found=true --timeout=30s || true
    
    # Wait and check if still exists
    sleep 5
    if kubectl get namespace ${namespace} &>/dev/null; then
        print_warn "Namespace still exists, forcing deletion..."
        # Force delete by removing finalizers again
        kubectl get namespace ${namespace} -o json | \
            jq 'del(.spec.finalizers)' | \
            kubectl replace --raw /api/v1/namespaces/${namespace}/finalize -f - 2>/dev/null || {
                kubectl patch namespace ${namespace} -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null || true
            }
    fi
}

# Step 1: Delete SpinnakerService
print_info "Step 1: Deleting SpinnakerService..."
if kubectl get namespace ${SPINNAKER_NAMESPACE} &>/dev/null; then
    kubectl -n ${SPINNAKER_NAMESPACE} delete spinnakerservice spinnaker --ignore-not-found=true --timeout=30s || true
    print_info "Waiting for operator to process deletion..."
    sleep 10
    print_info "✓ SpinnakerService deletion initiated"
else
    print_warn "Namespace ${SPINNAKER_NAMESPACE} does not exist. Skipping SpinnakerService deletion."
fi
echo ""

# Step 2: Delete all resources in spinnaker namespace
print_info "Step 2: Deleting all resources in ${SPINNAKER_NAMESPACE} namespace..."
if kubectl get namespace ${SPINNAKER_NAMESPACE} &>/dev/null; then
    # Delete deployments
    print_info "  Deleting deployments..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete deployment --all --ignore-not-found=true --timeout=30s || true
    
    # Delete statefulsets
    print_info "  Deleting statefulsets..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete statefulset --all --ignore-not-found=true --timeout=30s || true
    
    # Delete services
    print_info "  Deleting services..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete service --all --ignore-not-found=true --timeout=30s || true
    
    # Delete configmaps
    print_info "  Deleting configmaps..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete configmap --all --ignore-not-found=true --timeout=30s || true
    
    # Delete secrets (be careful with this)
    print_info "  Deleting secrets..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete secret --all --ignore-not-found=true --timeout=30s || true
    
    # Delete PVCs
    print_info "  Deleting PVCs..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete pvc --all --ignore-not-found=true --timeout=30s || true
    
    # Delete jobs
    print_info "  Deleting jobs..."
    kubectl -n ${SPINNAKER_NAMESPACE} delete job --all --ignore-not-found=true --timeout=30s || true
    
    # Delete any remaining resources
    print_info "  Deleting any remaining resources..."
    for resource in $(kubectl api-resources --verbs=delete --namespaced -o name 2>/dev/null); do
        if [[ "$resource" != "events" ]] && [[ "$resource" != "events.events.k8s.io" ]]; then
            kubectl -n ${SPINNAKER_NAMESPACE} delete ${resource} --all --ignore-not-found=true --timeout=10s 2>/dev/null || true
        fi
    done
    
    print_info "✓ Resources deletion initiated"
else
    print_warn "Namespace ${SPINNAKER_NAMESPACE} does not exist. Skipping."
fi
echo ""

# Step 3: Delete Operator
print_info "Step 3: Deleting Spinnaker Operator..."
if kubectl get namespace ${OPERATOR_NAMESPACE} &>/dev/null; then
    # Delete operator deployment
    print_info "  Deleting operator deployment..."
    kubectl -n ${OPERATOR_NAMESPACE} delete deployment spinnaker-operator --ignore-not-found=true --timeout=30s || true
    
    # Delete operator service account
    print_info "  Deleting operator service account..."
    kubectl -n ${OPERATOR_NAMESPACE} delete serviceaccount spinnaker-operator --ignore-not-found=true --timeout=30s || true
    
    # Delete cluster role binding
    print_info "  Deleting cluster role binding..."
    kubectl delete clusterrolebinding spinnaker-operator --ignore-not-found=true --timeout=30s || true
    
    # Delete cluster role
    print_info "  Deleting cluster role..."
    kubectl delete clusterrole spinnaker-operator --ignore-not-found=true --timeout=30s || true
    
    # Delete validating webhook configuration
    print_info "  Deleting validating webhook configuration..."
    kubectl delete validatingwebhookconfiguration spinnaker-operator-validating-webhook --ignore-not-found=true --timeout=30s || true
    
    # Delete any remaining resources in operator namespace
    print_info "  Deleting remaining resources in operator namespace..."
    kubectl -n ${OPERATOR_NAMESPACE} delete all --all --ignore-not-found=true --timeout=30s || true
    
    print_info "✓ Operator deletion initiated"
else
    print_warn "Namespace ${OPERATOR_NAMESPACE} does not exist. Skipping operator deletion."
fi
echo ""

# Step 4: Force delete spinnaker namespace
print_info "Step 4: Force deleting ${SPINNAKER_NAMESPACE} namespace..."
force_delete_namespace ${SPINNAKER_NAMESPACE}
echo ""

# Step 5: Force delete operator namespace
print_info "Step 5: Force deleting ${OPERATOR_NAMESPACE} namespace..."
force_delete_namespace ${OPERATOR_NAMESPACE}
echo ""

# Step 6: Wait and verify
print_info "Step 6: Waiting for namespaces to be deleted..."
sleep 10

# Check if namespaces still exist
if kubectl get namespace ${SPINNAKER_NAMESPACE} &>/dev/null; then
    print_warn "Namespace ${SPINNAKER_NAMESPACE} still exists. You may need to manually remove finalizers."
    print_info "To manually fix, run:"
    print_info "  kubectl get namespace ${SPINNAKER_NAMESPACE} -o json | jq '.spec.finalizers = []' | kubectl replace --raw /api/v1/namespaces/${SPINNAKER_NAMESPACE}/finalize -f -"
else
    print_info "✓ Namespace ${SPINNAKER_NAMESPACE} deleted"
fi

if kubectl get namespace ${OPERATOR_NAMESPACE} &>/dev/null; then
    print_warn "Namespace ${OPERATOR_NAMESPACE} still exists. You may need to manually remove finalizers."
else
    print_info "✓ Namespace ${OPERATOR_NAMESPACE} deleted"
fi
echo ""

# Step 7: Option to delete CRDs
print_info "Step 7: Delete CRDs?"
print_warn "WARNING: This will delete CRDs cluster-wide. Only do this if you're sure no other Spinnaker installations exist."
read -p "Delete Spinnaker CRDs? (yes/no) " -r
echo ""
if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
    print_info "Deleting CRDs..."
    kubectl delete crd spinnakerservices.spinnaker.io --ignore-not-found=true --timeout=30s || true
    kubectl delete crd spinnakeraccounts.spinnaker.io --ignore-not-found=true --timeout=30s || true
    print_info "✓ CRDs deleted"
else
    print_info "CRDs kept (can be deleted manually later)"
fi
echo ""

print_info "=========================================="
print_info "Cleanup completed!"
print_info "=========================================="
print_info ""
print_info "To verify, run:"
print_info "  kubectl get namespace ${SPINNAKER_NAMESPACE}"
print_info "  kubectl get namespace ${OPERATOR_NAMESPACE}"
print_info "  kubectl get crd | grep spinnaker"





