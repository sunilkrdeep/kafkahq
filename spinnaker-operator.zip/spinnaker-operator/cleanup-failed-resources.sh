#!/bin/bash

# Cleanup Failed and Non-Running Spinnaker Resources
# This script removes failed pods and old replicasets

set -e

NAMESPACE="spinnaker"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

echo "=========================================="
echo "Cleaning Up Failed Spinnaker Resources"
echo "=========================================="
echo ""

echo "Step 1: Analyzing current state..."
echo ""

# Count failed pods
FAILED_PODS=$(kubectl -n $NAMESPACE get pods --no-headers 2>/dev/null | grep -E "(Evicted|Error|ContainerStatusUnknown)" | wc -l | tr -d ' ')
echo "Failed pods (Evicted/Error/ContainerStatusUnknown): $FAILED_PODS"

# Count old replicasets
OLD_RS=$(kubectl -n $NAMESPACE get replicasets --no-headers 2>/dev/null | awk '$2==0 && $3==0 && $4==0 {print $1}' | wc -l | tr -d ' ')
echo "Old replicasets (0 replicas): $OLD_RS"

echo ""
echo "Step 2: Listing failed pods..."
FAILED_POD_LIST=$(kubectl -n $NAMESPACE get pods --no-headers 2>/dev/null | grep -E "(Evicted|Error|ContainerStatusUnknown)" | awk '{print $1}' || echo "")
if [ -n "$FAILED_POD_LIST" ]; then
    echo "$FAILED_POD_LIST" | head -10
    if [ "$FAILED_PODS" -gt 10 ]; then
        echo "... and $((FAILED_PODS - 10)) more"
    fi
else
    echo "No failed pods found"
fi

echo ""
echo "Step 3: Listing old replicasets..."
OLD_RS_LIST=$(kubectl -n $NAMESPACE get replicasets --no-headers 2>/dev/null | awk '$2==0 && $3==0 && $4==0 {print $1}' || echo "")
if [ -n "$OLD_RS_LIST" ]; then
    echo "$OLD_RS_LIST" | head -10
    if [ "$OLD_RS" -gt 10 ]; then
        echo "... and $((OLD_RS - 10)) more"
    fi
else
    echo "No old replicasets found"
fi

echo ""
if [ "$FAILED_PODS" -eq 0 ] && [ "$OLD_RS" -eq 0 ]; then
    echo "✓ No cleanup needed - all resources are clean!"
    exit 0
fi

echo "Step 4: Confirming cleanup..."
echo "⚠ This will delete:"
echo "  - $FAILED_PODS failed pods"
echo "  - $OLD_RS old replicasets"
echo ""
read -p "Proceed with cleanup? (y/N): " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

echo ""
echo "Step 5: Deleting failed pods..."
if [ "$FAILED_PODS" -gt 0 ]; then
    FAILED_POD_NAMES=$(kubectl -n $NAMESPACE get pods --no-headers 2>/dev/null | grep -E "(Evicted|Error|ContainerStatusUnknown)" | awk '{print $1}')
    DELETED=0
    for pod in $FAILED_POD_NAMES; do
        if kubectl -n $NAMESPACE delete pod "$pod" --ignore-not-found=true 2>/dev/null; then
            DELETED=$((DELETED + 1))
        fi
    done
    echo "✓ Deleted $DELETED failed pods"
else
    echo "✓ No failed pods to delete"
fi

echo ""
echo "Step 6: Deleting old replicasets..."
if [ "$OLD_RS" -gt 0 ]; then
    OLD_RS_NAMES=$(kubectl -n $NAMESPACE get replicasets --no-headers 2>/dev/null | awk '$2==0 && $3==0 && $4==0 {print $1}')
    DELETED=0
    for rs in $OLD_RS_NAMES; do
        if kubectl -n $NAMESPACE delete replicaset "$rs" --ignore-not-found=true 2>/dev/null; then
            DELETED=$((DELETED + 1))
        fi
    done
    echo "✓ Deleted $DELETED old replicasets"
else
    echo "✓ No old replicasets to delete"
fi

echo ""
echo "Step 7: Checking deployment status..."
echo ""
kubectl -n $NAMESPACE get deployments

echo ""
echo "Step 8: Final state..."
echo ""
REMAINING_FAILED=$(kubectl -n $NAMESPACE get pods --no-headers 2>/dev/null | grep -E "(Evicted|Error|ContainerStatusUnknown)" | wc -l | tr -d ' ')
REMAINING_OLD_RS=$(kubectl -n $NAMESPACE get replicasets --no-headers 2>/dev/null | awk '$2==0 && $3==0 && $4==0 {print $1}' | wc -l | tr -d ' ')

if [ "$REMAINING_FAILED" -eq 0 ] && [ "$REMAINING_OLD_RS" -eq 0 ]; then
    echo "✓ Cleanup complete! All failed resources removed."
else
    echo "⚠ Some resources may still remain:"
    echo "  - Failed pods: $REMAINING_FAILED"
    echo "  - Old replicasets: $REMAINING_OLD_RS"
    echo ""
    echo "These may be in a terminating state. Wait a few moments and run again."
fi

echo ""
echo "=========================================="
echo "Cleanup Summary"
echo "=========================================="
echo "Pods deleted: $DELETED (out of $FAILED_PODS)"
echo "Replicasets deleted: $DELETED (out of $OLD_RS)"
echo ""
echo "Current running pods:"
kubectl -n $NAMESPACE get pods --no-headers 2>/dev/null | grep -E "Running" | wc -l | xargs echo "  - Running:"
kubectl -n $NAMESPACE get pods --no-headers 2>/dev/null | grep -vE "Running|Completed" | wc -l | xargs echo "  - Other status:"


