#!/bin/bash

# Configure Spinnaker Internal LoadBalancer for VPN Access
# This script configures security groups to allow access from Cisco VPN

set -e

NAMESPACE="spinnaker"

echo "=========================================="
echo "Configuring VPN Access for Spinnaker LoadBalancer"
echo "=========================================="
echo ""

# Get LoadBalancer information
DECK_LB=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
if [ -z "$DECK_LB" ]; then
    echo "ERROR: spin-deck LoadBalancer not found!"
    exit 1
fi

echo "LoadBalancer: $DECK_LB"
echo ""

# Get node security groups
echo "Step 1: Finding node security groups..."
NODE_SG=$(kubectl -n $NAMESPACE get nodes -o jsonpath='{.items[0].spec.providerID}' | sed 's|.*/||' | xargs -I {} aws ec2 describe-instances --instance-ids {} --query "Reservations[0].Instances[0].SecurityGroups[0].GroupId" --output text 2>&1 || echo "")
if [ -z "$NODE_SG" ] || [ "$NODE_SG" = "None" ]; then
    echo "⚠ Could not automatically detect node security group"
    echo "Please provide the security group ID for your EKS nodes:"
    read -p "Security Group ID: " NODE_SG
fi

echo "Node Security Group: $NODE_SG"
echo ""

# Get VPN CIDR range
echo "Step 2: Configuring VPN CIDR range..."
echo "Enter the Cisco VPN CIDR range (e.g., 10.10.0.0/16, 172.16.0.0/16)"
echo "Common Exotel VPN ranges: 10.10.0.0/16, 10.0.0.0/8"
read -p "VPN CIDR Range: " VPN_CIDR

if [ -z "$VPN_CIDR" ]; then
    echo "ERROR: VPN CIDR range is required!"
    exit 1
fi

echo ""
echo "Step 3: Adding security group rules for VPN access..."
echo "This will allow traffic from $VPN_CIDR to ports 80 (Deck) and 8084 (Gate)"
echo ""

# Check if rules already exist
EXISTING_RULE=$(aws ec2 describe-security-groups --group-ids $NODE_SG --query "SecurityGroups[0].IpPermissions[?FromPort==\`80\` && IpRanges[?CidrIp==\`${VPN_CIDR}\`]]" --output json 2>&1 | jq -r '.[0].FromPort' || echo "")

if [ -n "$EXISTING_RULE" ]; then
    echo "⚠ Rule for port 80 from $VPN_CIDR already exists"
    read -p "Update anyway? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Skipping security group update."
    else
        # Add rules
        echo "Adding inbound rule for port 80 (Deck)..."
        aws ec2 authorize-security-group-ingress \
            --group-id $NODE_SG \
            --protocol tcp \
            --port 80 \
            --cidr $VPN_CIDR \
            --description "Allow VPN access to Spinnaker Deck" 2>&1 || echo "Rule may already exist"
        
        echo "Adding inbound rule for port 8084 (Gate)..."
        aws ec2 authorize-security-group-ingress \
            --group-id $NODE_SG \
            --protocol tcp \
            --port 8084 \
            --cidr $VPN_CIDR \
            --description "Allow VPN access to Spinnaker Gate" 2>&1 || echo "Rule may already exist"
    fi
else
    # Add rules
    echo "Adding inbound rule for port 80 (Deck)..."
    aws ec2 authorize-security-group-ingress \
        --group-id $NODE_SG \
        --protocol tcp \
        --port 80 \
        --cidr $VPN_CIDR \
        --description "Allow VPN access to Spinnaker Deck" 2>&1 || echo "Rule may already exist"
    
    echo "Adding inbound rule for port 8084 (Gate)..."
    aws ec2 authorize-security-group-ingress \
        --group-id $NODE_SG \
        --protocol tcp \
        --port 8084 \
        --cidr $VPN_CIDR \
        --description "Allow VPN access to Spinnaker Gate" 2>&1 || echo "Rule may already exist"
fi

echo ""
echo "Step 4: Verifying security group rules..."
echo ""
aws ec2 describe-security-groups --group-ids $NODE_SG \
    --query "SecurityGroups[0].IpPermissions[?FromPort==\`80\` || FromPort==\`8084\`].{Port:FromPort,Protocol:IpProtocol,CIDR:IpRanges[0].CidrIp,Description:IpRanges[0].Description}" \
    --output table 2>&1

echo ""
echo "Step 5: Checking LoadBalancer subnets and routes..."
LB_SUBNETS=$(aws elbv2 describe-load-balancers --query "LoadBalancers[?contains(LoadBalancerName, 'a89975196e5d1429788a063ab215d41d')].AvailabilityZones[*].SubnetId" --output text 2>&1 || echo "")
echo "LoadBalancer Subnets: $LB_SUBNETS"
echo ""

echo "=========================================="
echo "Configuration Summary"
echo "=========================================="
echo ""
echo "✓ Security group rules added for VPN access"
echo "  - Port 80 (Deck) from $VPN_CIDR"
echo "  - Port 8084 (Gate) from $VPN_CIDR"
echo ""
echo "IMPORTANT: Additional steps may be required:"
echo ""
echo "1. Verify VPN Route Configuration:"
echo "   - Ensure your VPN routes traffic to the VPC CIDR"
echo "   - Check VPN connection routes in AWS Console"
echo ""
echo "2. Verify DNS Resolution:"
echo "   - The LoadBalancer DNS should resolve to private IP"
echo "   - Test: nslookup $DECK_LB"
echo ""
echo "3. Test Access:"
echo "   - Connect to Cisco VPN"
echo "   - Access: http://$DECK_LB"
echo ""
echo "4. If still not accessible, check:"
echo "   - VPN route table configuration"
echo "   - LoadBalancer subnet route tables"
echo "   - Network ACLs (NACLs) on subnets"
echo ""
echo "Security Group: $NODE_SG"
echo "VPN CIDR: $VPN_CIDR"

