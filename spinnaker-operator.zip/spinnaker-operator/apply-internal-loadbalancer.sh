#!/bin/bash

# Apply Internal LoadBalancer Configuration
# This script deletes the existing services to force recreation with internal LoadBalancer

set -e

NAMESPACE="spinnaker"

echo "=========================================="
echo "Applying Internal LoadBalancer Configuration"
echo "=========================================="
echo ""

echo "Step 1: Verifying SpinnakerService configuration..."
INTERNAL_ANNOTATION=$(kubectl -n $NAMESPACE get spinnakerservice spinnaker -o jsonpath='{.spec.expose.service.annotations.service\.beta\.kubernetes\.io/aws-load-balancer-internal}' 2>/dev/null || echo "")

if [ "$INTERNAL_ANNOTATION" != "true" ]; then
    echo "ERROR: Internal annotation not found in SpinnakerService!"
    echo "Please run: ./configure-internal-loadbalancer.sh first"
    exit 1
fi

echo "✓ Internal annotation confirmed: $INTERNAL_ANNOTATION"
echo ""

echo "Step 2: Checking current service status..."
DECK_EXISTS=$(kubectl -n $NAMESPACE get svc spin-deck 2>/dev/null && echo "yes" || echo "no")
GATE_EXISTS=$(kubectl -n $NAMESPACE get svc spin-gate 2>/dev/null && echo "yes" || echo "no")

if [ "$DECK_EXISTS" = "yes" ] || [ "$GATE_EXISTS" = "yes" ]; then
    echo "Existing services found. Backing up..."
    kubectl -n $NAMESPACE get svc spin-deck -o yaml > /tmp/spin-deck-backup-$(date +%Y%m%d-%H%M%S).yaml 2>/dev/null || echo "Note: spin-deck service may not exist"
    kubectl -n $NAMESPACE get svc spin-gate -o yaml > /tmp/spin-gate-backup-$(date +%Y%m%d-%H%M%S).yaml 2>/dev/null || echo "Note: spin-gate service may not exist"
    echo "Backups saved to /tmp/spin-*-backup-*.yaml"
    echo ""
    
    echo "Step 3: Getting current LoadBalancer URLs (for reference)..."
    DECK_LB=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "N/A")
    GATE_LB=$(kubectl -n $NAMESPACE get svc spin-gate -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "N/A")
    echo "Current Deck LoadBalancer: $DECK_LB"
    echo "Current Gate LoadBalancer: $GATE_LB"
    echo ""
    
    echo "Step 4: Deleting existing LoadBalancer services..."
    echo "This will cause temporary downtime (2-5 minutes) while new internal LoadBalancers are created."
    echo ""
    read -p "Continue? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Aborted."
        exit 1
    fi
    
    kubectl -n $NAMESPACE delete svc spin-deck spin-gate 2>/dev/null || echo "Services may not exist or already deleted"
else
    echo "Services don't exist yet. They will be created with internal LoadBalancer configuration."
    echo ""
fi

echo ""
echo "Step 5: Ensuring SpinnakerService expose configuration is correct..."
# Verify and ensure expose.type is set
kubectl -n $NAMESPACE patch spinnakerservice spinnaker --type='merge' -p='{"spec":{"expose":{"type":"service","service":{"type":"LoadBalancer"}}}}' 2>/dev/null || true

# Trigger reconciliation by adding an annotation
kubectl -n $NAMESPACE annotate spinnakerservice spinnaker spinnaker.io/reconcile-$(date +%s)=triggered --overwrite 2>/dev/null || true

echo ""
echo "Step 6: Waiting for Spinnaker operator to create services with internal LoadBalancers..."
echo "This may take 2-5 minutes..."
echo ""

SUCCESS=false
for i in {1..60}; do
    sleep 5
    
    # Check if services exist
    DECK_SVC=$(kubectl -n $NAMESPACE get svc spin-deck 2>/dev/null && echo "exists" || echo "")
    GATE_SVC=$(kubectl -n $NAMESPACE get svc spin-gate 2>/dev/null && echo "exists" || echo "")
    
    if [ -n "$DECK_SVC" ] && [ -n "$GATE_SVC" ]; then
        # Services exist, check for LoadBalancer hostname
        DECK_NEW=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
        GATE_NEW=$(kubectl -n $NAMESPACE get svc spin-gate -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
        
        if [ -n "$DECK_NEW" ] && [ "$DECK_NEW" != "N/A" ] && [ -n "$GATE_NEW" ] && [ "$GATE_NEW" != "N/A" ]; then
            echo ""
            echo "✓ New internal LoadBalancers created!"
            echo "Deck LoadBalancer: $DECK_NEW"
            echo "Gate LoadBalancer: $GATE_NEW"
            SUCCESS=true
            break
        fi
    fi
    echo -n "."
done

if [ "$SUCCESS" = false ]; then
    echo ""
    echo "⚠ Timeout waiting for LoadBalancers. Checking current status..."
    kubectl -n $NAMESPACE get svc spin-deck spin-gate 2>&1
    echo ""
    echo "Note: Services may still be provisioning. Wait a few more minutes and check again."
fi

echo ""
echo ""
echo "Step 7: Verifying services..."
kubectl -n $NAMESPACE get svc spin-deck spin-gate 2>&1

echo ""
echo "Step 8: Verifying LoadBalancer scheme (should be 'internal')..."
DECK_LB_NEW=$(kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
if [ -n "$DECK_LB_NEW" ] && [ "$DECK_LB_NEW" != "N/A" ]; then
    LB_PREFIX=$(echo $DECK_LB_NEW | cut -d'-' -f1)
    echo "Checking LoadBalancer scheme for: $LB_PREFIX"
    echo ""
    aws elbv2 describe-load-balancers --query "LoadBalancers[?contains(LoadBalancerName, '${LB_PREFIX}')].{Name:LoadBalancerName,Scheme:Scheme,Type:Type}" --output table 2>&1 || echo "Note: If using Classic LB, check in EC2 console"
    
    # Also check annotations
    echo ""
    echo "Service annotations:"
    kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.metadata.annotations}' | jq . 2>/dev/null || kubectl -n $NAMESPACE get svc spin-deck -o jsonpath='{.metadata.annotations}'
else
    echo "LoadBalancer not yet provisioned. Wait a few more minutes."
fi

echo ""
echo "=========================================="
echo "Configuration complete!"
echo "=========================================="
echo ""
echo "IMPORTANT NOTES:"
echo "  - LoadBalancers are now INTERNAL only"
echo "  - Accessible only from within VPC/internal network"
echo "  - External internet access is BLOCKED"
echo ""
echo "To access Spinnaker:"
echo "  - From within the VPC: http://$DECK_LB_NEW"
echo "  - Via VPN: Connect to VPC VPN first"
echo "  - Via bastion/jump host: SSH tunnel or port forward"
echo ""
echo "Security Groups:"
echo "  - Ensure security groups allow inbound traffic from your internal network"
echo "  - Port 80 (Deck) and 8084 (Gate) should be open for internal IPs"


