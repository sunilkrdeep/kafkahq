#!/bin/bash

# Spinnaker Operator Deployment Script
# This script deploys Spinnaker using the Spinnaker Operator with Kustomize

set -e

# Configuration Variables
OPERATOR_NAMESPACE="spinnaker-operator"
SPINNAKER_NAMESPACE="spinnaker"
OPERATOR_VERSION="v1.3.1"
SPINNAKER_VERSION="1.29.0"
S3_BUCKET="exotel-spinnaker-qa"
AWS_REGION="us-west-2"
AWS_ACCOUNT_ID="914066148492"
AWS_ACCOUNT_NAME="Exotel-prefix-staging-2"
EC2_KEY_PAIR="exotel"
IAM_ROLE_NAME="SpinnakerS3Role"
SERVICE_ACCOUNT_NAME="spinnaker"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    print_error "kubectl is not installed. Please install kubectl first."
    exit 1
fi

# Check if kustomize is available
if ! command -v kustomize &> /dev/null; then
    print_warn "kustomize is not installed. Attempting to use kubectl kustomize..."
    if kubectl kustomize --help &>/dev/null; then
        KUSTOMIZE_CMD="kubectl kustomize"
    else
        print_error "Neither 'kustomize' nor 'kubectl kustomize' is available."
        print_error "Please install kustomize: https://kustomize.io/"
        exit 1
    fi
else
    KUSTOMIZE_CMD="kustomize build"
    # Check kustomize version for compatibility
    KUSTOMIZE_VERSION=$(kustomize version --short 2>/dev/null || echo "unknown")
    print_info "Using kustomize version: ${KUSTOMIZE_VERSION}"
fi

print_info "Starting Spinnaker Operator deployment..."
print_info "Operator Namespace: ${OPERATOR_NAMESPACE}"
print_info "Spinnaker Namespace: ${SPINNAKER_NAMESPACE}"
print_info "Operator Version: ${OPERATOR_VERSION}"
print_info "Spinnaker Version: ${SPINNAKER_VERSION}"

# Step 1: Download Operator Manifests
print_info "Step 1: Downloading Spinnaker Operator manifests..."
cd "$(dirname "$0")"
mkdir -p manifests
cd manifests

if [ ! -f "manifests.tgz" ]; then
    print_info "Downloading manifests from GitHub releases..."
    curl -L "https://github.com/armory/spinnaker-operator/releases/download/${OPERATOR_VERSION}/manifests.tgz" -o manifests.tgz
    tar -xzf manifests.tgz
    print_info "Manifests downloaded and extracted"
else
    print_info "Manifests already downloaded, skipping..."
fi

# Step 2: Install CRDs
print_info "Step 2: Installing CRDs cluster-wide..."

# First, verify kubectl can connect to the cluster
print_info "Verifying cluster connectivity..."
# Check if timeout command is available
if command -v timeout &> /dev/null; then
    TIMEOUT_CMD="timeout 10"
else
    # macOS doesn't have timeout by default, use perl or just skip timeout
    if command -v perl &> /dev/null; then
        TIMEOUT_CMD="perl -e 'alarm 10; exec @ARGV'"
    else
        TIMEOUT_CMD=""
        print_warn "timeout command not available, skipping timeout for connectivity check"
    fi
fi

if [ -n "$TIMEOUT_CMD" ]; then
    if ! eval "$TIMEOUT_CMD kubectl cluster-info" &>/dev/null; then
        print_error "Cannot connect to Kubernetes cluster (or connection timed out)"
        print_error "Please check your kubectl configuration:"
        print_error "  1. Verify kubectl context: kubectl config current-context"
        print_error "  2. Test connection: kubectl cluster-info"
        print_error "  3. Check authentication: kubectl get nodes"
        exit 1
    fi
else
    # Without timeout, just try the command
    if ! kubectl cluster-info &>/dev/null; then
        print_error "Cannot connect to Kubernetes cluster"
        print_error "Please check your kubectl configuration"
        exit 1
    fi
fi
print_info "✓ Cluster connectivity verified"

if [ -d "deploy/crds" ]; then
    # Check if CRDs already exist
    print_info "Checking if CRDs are already installed..."
    if kubectl get crd spinnakerservices.spinnaker.io &>/dev/null; then
        print_info "✓ spinnakerservices.spinnaker.io CRD already exists"
        CRD_EXISTS=true
    else
        CRD_EXISTS=false
    fi
    
    if kubectl get crd spinnakeraccounts.spinnaker.io &>/dev/null; then
        print_info "✓ spinnakeraccounts.spinnaker.io CRD already exists"
    fi
    
    # If CRDs don't exist, install them
    if [ "$CRD_EXISTS" = false ]; then
        print_info "Installing CRDs (skipping validation to avoid OpenAPI schema issues)..."
        print_info "This may take a few seconds..."
        
        # Use timeout to prevent hanging, and skip validation by default
        # Validation often fails due to OpenAPI schema download issues
        # Check if timeout command is available
        if command -v timeout &> /dev/null; then
            TIMEOUT_CMD="timeout 30"
        elif command -v perl &> /dev/null; then
            TIMEOUT_CMD="perl -e 'alarm 30; exec @ARGV'"
        else
            TIMEOUT_CMD=""
            print_warn "timeout command not available, proceeding without timeout"
        fi
        
        if [ -n "$TIMEOUT_CMD" ]; then
            if eval "$TIMEOUT_CMD kubectl apply --validate=false -f deploy/crds/" 2>&1 | tee /tmp/crd-install.log; then
                CRD_EXIT_CODE=0
            else
                CRD_EXIT_CODE=${PIPESTATUS[0]}
            fi
        else
            if kubectl apply --validate=false -f deploy/crds/ 2>&1 | tee /tmp/crd-install.log; then
                CRD_EXIT_CODE=0
            else
                CRD_EXIT_CODE=$?
            fi
        fi
        
        if [ $CRD_EXIT_CODE -eq 0 ]; then
            print_info "CRDs installed successfully"
        else
            if [ $CRD_EXIT_CODE -eq 124 ] || [ $CRD_EXIT_CODE -eq 142 ]; then
                print_error "CRD installation timed out after 30 seconds"
                print_error "This may indicate network or authentication issues"
            else
                print_error "Failed to install CRDs. Error details:"
                cat /tmp/crd-install.log
            fi
            print_error ""
            print_error "Troubleshooting:"
            print_error "  1. Check kubectl access: kubectl cluster-info"
            print_error "  2. Verify authentication: kubectl get nodes"
            print_error "  3. Try manual installation: kubectl apply --validate=false -f deploy/crds/"
            exit 1
        fi
    else
        print_info "CRDs already installed, skipping installation"
    fi
    
    # Verify CRDs are installed (wait a moment for them to appear)
    print_info "Verifying CRDs are installed..."
    sleep 2
    
    if kubectl get crd spinnakerservices.spinnaker.io &>/dev/null; then
        print_info "✓ spinnakerservices.spinnaker.io CRD verified"
    else
        print_warn "⚠ spinnakerservices.spinnaker.io CRD not found"
        print_warn "  This may indicate an installation issue. Continuing anyway..."
    fi
    
    if kubectl get crd spinnakeraccounts.spinnaker.io &>/dev/null; then
        print_info "✓ spinnakeraccounts.spinnaker.io CRD verified"
    else
        print_warn "⚠ spinnakeraccounts.spinnaker.io CRD not found (optional, may not be needed)"
    fi
else
    print_error "CRDs directory not found. Please check the manifests download."
    exit 1
fi

# Step 3: Create Operator Namespace
print_info "Step 3: Creating operator namespace..."
kubectl create namespace ${OPERATOR_NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -

# Step 4: Install Operator (Cluster Mode)
print_info "Step 4: Installing Spinnaker Operator in cluster mode..."
if [ -d "deploy/operator/cluster" ]; then
    # Update namespace in role_binding.yml if needed
    if [ "${OPERATOR_NAMESPACE}" != "spinnaker-operator" ]; then
        print_warn "Updating namespace in role_binding.yml..."
        sed -i.bak "s/namespace: spinnaker-operator/namespace: ${OPERATOR_NAMESPACE}/g" deploy/operator/cluster/role_binding.yml
    fi
    kubectl -n ${OPERATOR_NAMESPACE} apply -f deploy/operator/cluster/
    print_info "Operator installed successfully"
else
    print_error "Operator cluster directory not found. Please check the manifests download."
    exit 1
fi

# Step 5: Wait for Operator to be ready
print_info "Step 5: Waiting for operator to be ready..."
kubectl wait --for=condition=available --timeout=300s deployment/spinnaker-operator -n ${OPERATOR_NAMESPACE} || {
    print_warn "Operator deployment not ready yet. Continuing anyway..."
}

# Step 6: Create Spinnaker Namespace and Service Account
print_info "Step 6: Creating Spinnaker namespace and service account..."
kubectl create namespace ${SPINNAKER_NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -

# Create service account for Spinnaker services (required for Kubernetes account)
print_info "Creating service account for Spinnaker services..."
if kubectl -n ${SPINNAKER_NAMESPACE} create serviceaccount spinnaker --dry-run=client -o yaml | kubectl apply -f -; then
    print_info "✓ Service account 'spinnaker' created/verified"
else
    print_warn "Failed to create service account. It may already exist or there may be a permission issue."
    # Check if it exists
    if kubectl -n ${SPINNAKER_NAMESPACE} get serviceaccount spinnaker &>/dev/null; then
        print_info "✓ Service account 'spinnaker' already exists"
    else
        print_error "Service account 'spinnaker' does not exist and could not be created"
        print_error "Please create it manually: kubectl -n ${SPINNAKER_NAMESPACE} create serviceaccount spinnaker"
        exit 1
    fi
fi

# Step 7: Pre-validate Kustomize configuration
print_info "Step 7: Pre-validating Kustomize configuration..."
cd ../deploy/spinnaker/kustomize

if [ ! -f "kustomization.yml" ]; then
    print_error "kustomization.yml not found in deploy/spinnaker/kustomize/"
    exit 1
fi

# Check for deprecated patchesStrategicMerge
if grep -q "patchesStrategicMerge" kustomization.yml; then
    print_warn "Warning: kustomization.yml uses deprecated 'patchesStrategicMerge'"
    print_warn "This should be updated to use 'patches' format"
    print_info "Attempting to continue with current configuration..."
fi

# Validate required files exist
REQUIRED_FILES=("spinnakerservice.yml" "config-patch.yml" "profiles-patch.yml" "files-patch.yml" "service-settings-patch.yml")
MISSING_FILES=()

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        MISSING_FILES+=("$file")
    fi
done

if [ ${#MISSING_FILES[@]} -gt 0 ]; then
    print_error "Missing required files:"
    for file in "${MISSING_FILES[@]}"; do
        print_error "  - $file"
    done
    exit 1
fi

# Validate that patch files have namespace
print_info "Validating patch files have namespace..."
for patch_file in config-patch.yml profiles-patch.yml files-patch.yml service-settings-patch.yml; do
    if ! grep -q "namespace: spinnaker" "$patch_file" 2>/dev/null; then
        print_warn "Warning: $patch_file may be missing namespace. This could cause patch errors."
    fi
done

# Validate service account is configured in base file (required, not just in patch)
print_info "Validating service account configuration..."
if ! grep -A 5 "service-settings:" spinnakerservice.yml | grep -A 3 "clouddriver:" | grep -q "serviceAccount: spinnaker" 2>/dev/null; then
    print_error "Error: serviceAccount must be set in spinnakerservice.yml for clouddriver"
    print_error "This is required for Kubernetes account authentication"
    print_error "The service account should be in the base file, not just in patches"
    exit 1
fi

# Also check patch file for consistency
if ! grep -q "serviceAccount: spinnaker" service-settings-patch.yml 2>/dev/null; then
    print_warn "Warning: serviceAccount not found in service-settings-patch.yml"
    print_warn "This is okay if it's in the base file, but patches should be consistent"
fi

# Validate S3 accessKeyId is present
print_info "Validating S3 configuration..."
if ! grep -q "accessKeyId:" spinnakerservice.yml 2>/dev/null; then
    print_error "Error: accessKeyId must be configured in spinnakerservice.yml for S3"
    exit 1
fi

# Validate AWS provider accessKeyId is present
if ! grep -A 10 "aws:" spinnakerservice.yml | grep -q "accessKeyId:" 2>/dev/null; then
    print_error "Error: accessKeyId must be configured in AWS provider in spinnakerservice.yml"
    exit 1
fi

# Step 8: Deploy Spinnaker using Kustomize
print_info "Step 8: Deploying Spinnaker using Kustomize..."

# Validate kustomization file
print_info "Validating kustomization configuration..."
if ! ${KUSTOMIZE_CMD} . > /dev/null 2>&1; then
    print_warn "Kustomize build validation failed. Attempting to fix kustomization..."
    
    # Try to fix deprecated patchesStrategicMerge if present
    if grep -q "patchesStrategicMerge" kustomization.yml; then
        print_info "Fixing deprecated patchesStrategicMerge..."
        # This is a fallback - the file should already be fixed
        print_warn "Please ensure kustomization.yml uses 'patches' instead of 'patchesStrategicMerge'"
    fi
    
    # Try building again with verbose output
    print_info "Building kustomize manifests with verbose output..."
    if ! ${KUSTOMIZE_CMD} . 2>&1 | tee /tmp/kustomize-build.log; then
        print_error "Kustomize build failed. Error details:"
        cat /tmp/kustomize-build.log
        print_error ""
        print_error "Troubleshooting steps:"
        print_error "  1. Check that all patch files exist and have correct namespace"
        print_error "  2. Verify kustomization.yml uses 'patches' format (not 'patchesStrategicMerge')"
        print_error "  3. Ensure spinnakerservice.yml exists and is valid"
        print_error ""
        print_info "Attempting to apply base SpinnakerService without patches..."
        
        # Fallback: Apply base resource only
        if [ -f "spinnakerservice.yml" ]; then
            print_info "Applying base SpinnakerService..."
            kubectl -n ${SPINNAKER_NAMESPACE} apply -f spinnakerservice.yml
            print_warn "Applied base configuration only. Patches were skipped due to errors."
        else
            print_error "Base spinnakerservice.yml not found. Cannot proceed."
            exit 1
        fi
    else
        print_info "Kustomize build successful after fix attempt."
    fi
else
    print_info "Kustomize validation passed. Building and applying manifests..."
    
    # Build and validate output before applying
    KUSTOMIZE_OUTPUT=$(mktemp)
    if ${KUSTOMIZE_CMD} . > "${KUSTOMIZE_OUTPUT}" 2>&1; then
        # Check if output is not empty
        if [ ! -s "${KUSTOMIZE_OUTPUT}" ]; then
            print_error "Kustomize build produced empty output!"
            rm -f "${KUSTOMIZE_OUTPUT}"
            exit 1
        fi
        
        # Validate that SpinnakerService is in the output
        if ! grep -q "kind: SpinnakerService" "${KUSTOMIZE_OUTPUT}"; then
            print_error "SpinnakerService not found in kustomize output!"
            print_error "Output preview:"
            head -20 "${KUSTOMIZE_OUTPUT}"
            rm -f "${KUSTOMIZE_OUTPUT}"
            exit 1
        fi
        
        # Validate critical configuration in merged output
        print_info "Validating merged configuration..."
        
        # Check service account is set for clouddriver
        if ! grep -A 10 "service-settings:" "${KUSTOMIZE_OUTPUT}" | grep -A 5 "clouddriver:" | grep -q "serviceAccount: spinnaker"; then
            print_error "Error: serviceAccount not found for clouddriver in merged output!"
            print_error "This is required for Kubernetes account authentication"
            print_error "Debug: Checking merged output for service-settings..."
            grep -A 20 "service-settings:" "${KUSTOMIZE_OUTPUT}" | head -30
            print_error ""
            print_error "Saving merged output to /tmp/spinnaker-merged-output.yaml for inspection..."
            cp "${KUSTOMIZE_OUTPUT}" /tmp/spinnaker-merged-output.yaml
            print_error "You can inspect the file to see what's missing"
            rm -f "${KUSTOMIZE_OUTPUT}"
            exit 1
        fi
        
        # Check S3 accessKeyId is present
        S3_ACCESS_KEY=$(grep -A 10 "persistentStorage:" "${KUSTOMIZE_OUTPUT}" | grep -A 5 "s3:" | grep "accessKeyId:" | head -1 | sed 's/.*accessKeyId: *"\([^"]*\)".*/\1/' || echo "")
        if [ -z "$S3_ACCESS_KEY" ]; then
            print_error "Error: accessKeyId not found in S3 configuration in merged output!"
            print_error "Debug: S3 configuration section:"
            grep -A 10 "persistentStorage:" "${KUSTOMIZE_OUTPUT}" | grep -A 5 "s3:" | head -10
            print_error ""
            print_error "Saving merged output to /tmp/spinnaker-merged-output.yaml for inspection..."
            cp "${KUSTOMIZE_OUTPUT}" /tmp/spinnaker-merged-output.yaml
            rm -f "${KUSTOMIZE_OUTPUT}"
            exit 1
        else
            print_info "✓ S3 accessKeyId found: ${S3_ACCESS_KEY:0:10}..."
        fi
        
        # Check AWS provider accessKeyId is present
        AWS_ACCESS_KEY=$(grep -A 20 "providers:" "${KUSTOMIZE_OUTPUT}" | grep -A 15 "aws:" | grep -A 10 "accounts:" | grep "accessKeyId:" | head -1 | sed 's/.*accessKeyId: *"\([^"]*\)".*/\1/' || echo "")
        if [ -z "$AWS_ACCESS_KEY" ]; then
            print_error "Error: accessKeyId not found in AWS provider configuration in merged output!"
            print_error "Debug: AWS provider section:"
            grep -A 20 "providers:" "${KUSTOMIZE_OUTPUT}" | grep -A 15 "aws:" | head -20
            print_error ""
            print_error "Saving merged output to /tmp/spinnaker-merged-output.yaml for inspection..."
            cp "${KUSTOMIZE_OUTPUT}" /tmp/spinnaker-merged-output.yaml
            rm -f "${KUSTOMIZE_OUTPUT}"
            exit 1
        else
            print_info "✓ AWS provider accessKeyId found: ${AWS_ACCESS_KEY:0:10}..."
        fi
        
        print_info "✓ Configuration validation passed"
        
        # Save merged output for debugging
        cp "${KUSTOMIZE_OUTPUT}" /tmp/spinnaker-merged-output.yaml
        print_info "Merged output saved to /tmp/spinnaker-merged-output.yaml for reference"
        
        # Show preview of critical sections
        print_info "Preview of merged configuration:"
        print_info "Service Account for clouddriver:"
        grep -A 10 "service-settings:" "${KUSTOMIZE_OUTPUT}" | grep -A 5 "clouddriver:" | head -6
        print_info ""
        print_info "S3 accessKeyId:"
        grep -A 10 "persistentStorage:" "${KUSTOMIZE_OUTPUT}" | grep -A 5 "s3:" | grep "accessKeyId:" | head -1
        print_info ""
        
        # Final verification: Ensure service account exists before applying
        print_info "Final verification: Checking service account exists..."
        if ! kubectl -n ${SPINNAKER_NAMESPACE} get serviceaccount spinnaker &>/dev/null; then
            print_error "Service account 'spinnaker' does not exist!"
            print_error "Creating it now..."
            kubectl -n ${SPINNAKER_NAMESPACE} create serviceaccount spinnaker
            sleep 2
        fi
        
        # Check if SpinnakerService already exists - if so, we'll update it
        if kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker &>/dev/null; then
            print_info "SpinnakerService already exists. Will update it..."
            EXISTING_SVC=true
        else
            EXISTING_SVC=false
        fi
        
        # Apply the manifests
        print_info "Applying Kustomize manifests..."
        print_info "Note: If validation fails, check /tmp/spinnaker-merged-output.yaml and /tmp/kubectl-apply.log"
        
        # IMPORTANT: Validate configuration before applying
        # Halyard 500 errors are commonly caused by:
        # 1. accessKeyId/secretAccessKey in AWS provider accounts (NOT ALLOWED)
        # 2. Invalid Kubernetes account configuration
        print_info "Validating configuration for common Halyard issues..."
        
        # Check for accessKeyId in AWS provider (causes Halyard 500)
        if grep -q "accessKeyId" "${KUSTOMIZE_OUTPUT}" 2>/dev/null; then
            AWS_ACCOUNT_ACCESS_KEY=$(grep -A 10 "providers:" "${KUSTOMIZE_OUTPUT}" | grep -A 10 "aws:" | grep "accessKeyId" || echo "")
            if [ -n "$AWS_ACCOUNT_ACCESS_KEY" ]; then
                print_error "ERROR: accessKeyId found in AWS provider account configuration!"
                print_error "Halyard does NOT accept accessKeyId/secretAccessKey in AWS provider accounts."
                print_error "This will cause Halyard 500 errors."
                print_error ""
                print_error "Solution: Remove accessKeyId and secretAccessKey from AWS provider accounts."
                print_error "AWS credentials should be configured via IAM roles or environment variables."
                print_error ""
                print_error "S3 storage CAN have access keys, but AWS provider accounts CANNOT."
                rm -f "${KUSTOMIZE_OUTPUT}"
                exit 1
            fi
        fi
        
        # Check if validation webhook exists and temporarily disable it BEFORE applying
        # This is necessary because the webhook has a bug that rejects valid configurations
        WEBHOOK_NAME="spinnakervalidatingwebhook"
        WEBHOOK_DISABLED=false
        
        if kubectl get validatingwebhookconfiguration "$WEBHOOK_NAME" &>/dev/null; then
            print_warn "Validation webhook detected. Temporarily disabling to avoid validation issues..."
            print_warn "Note: The webhook will be automatically recreated by the operator after deployment"
            
            if kubectl delete validatingwebhookconfiguration "$WEBHOOK_NAME" &>/dev/null; then
                WEBHOOK_DISABLED=true
                print_info "✓ Validation webhook temporarily disabled"
                sleep 3  # Wait for webhook to be fully removed from API server
                
                # Verify webhook is gone
                if kubectl get validatingwebhookconfiguration "$WEBHOOK_NAME" &>/dev/null; then
                    print_warn "Webhook still exists, waiting a bit more..."
                    sleep 3
                fi
            else
                print_error "Failed to disable validation webhook!"
                print_error "You may need cluster admin permissions to disable it"
                print_error "Trying to apply anyway, but it may fail..."
            fi
        else
            print_info "No validation webhook found - proceeding with normal apply"
        fi
        
        # Try applying with server-side apply first (more reliable for complex resources)
        print_info "Attempting server-side apply..."
        if kubectl apply --server-side --force-conflicts -f "${KUSTOMIZE_OUTPUT}" 2>&1 | tee /tmp/kubectl-apply.log; then
            APPLY_EXIT_CODE=0
        else
            APPLY_EXIT_CODE=${PIPESTATUS[0]}
            # If server-side apply fails, try regular apply
            if [ $APPLY_EXIT_CODE -ne 0 ]; then
                print_warn "Server-side apply failed, trying regular apply..."
                kubectl -n ${SPINNAKER_NAMESPACE} apply -f "${KUSTOMIZE_OUTPUT}" 2>&1 | tee -a /tmp/kubectl-apply.log
                APPLY_EXIT_CODE=${PIPESTATUS[0]}
            fi
        fi
        
        # If still failing and webhook was not disabled, try disabling it now
        if [ $APPLY_EXIT_CODE -ne 0 ] && [ "$WEBHOOK_DISABLED" = false ]; then
            if kubectl get validatingwebhookconfiguration "$WEBHOOK_NAME" &>/dev/null; then
                print_warn "Apply failed. Attempting to disable validation webhook and retry..."
                if kubectl delete validatingwebhookconfiguration "$WEBHOOK_NAME" &>/dev/null; then
                    WEBHOOK_DISABLED=true
                    print_info "✓ Validation webhook disabled, retrying apply..."
                    sleep 2
                    if kubectl -n ${SPINNAKER_NAMESPACE} apply -f "${KUSTOMIZE_OUTPUT}" 2>&1 | tee /tmp/kubectl-apply-retry.log; then
                        APPLY_EXIT_CODE=0
                        print_info "✓ Successfully applied after disabling webhook!"
                    else
                        APPLY_EXIT_CODE=${PIPESTATUS[0]}
                    fi
                fi
            fi
        fi
        
        if [ $APPLY_EXIT_CODE -eq 0 ]; then
            print_info "Spinnaker deployment initiated successfully!"
            
            # Re-enable webhook if we disabled it (it will be recreated by operator anyway)
            if [ "$WEBHOOK_DISABLED" = true ]; then
                print_info "Note: Validation webhook will be automatically recreated by the operator"
            fi
            
            rm -f "${KUSTOMIZE_OUTPUT}"
        else
            print_error "Failed to apply manifests. Exit code: $APPLY_EXIT_CODE"
            print_error "Full error output saved to /tmp/kubectl-apply.log"
            print_error "Merged YAML saved to /tmp/spinnaker-merged-output.yaml"
            print_error ""
            
            # Analyze the error
            if grep -q "no service account name configured" /tmp/kubectl-apply.log; then
                print_error "Validation Error: Service account not found for clouddriver"
                print_error ""
                print_error "Checking merged output for service account configuration..."
                SERVICE_ACCOUNT_FOUND=$(grep -A 10 "service-settings:" "${KUSTOMIZE_OUTPUT}" | grep -A 5 "clouddriver:" | grep "serviceAccount:" || echo "")
                if [ -n "$SERVICE_ACCOUNT_FOUND" ]; then
                    print_warn "Service account IS present in merged output:"
                    echo "  $SERVICE_ACCOUNT_FOUND"
                    print_error ""
                    print_error "This may be a validation webhook timing issue."
                    print_error "Trying workaround: Apply base resource first, then patch..."
                    print_error ""
                    
                    # Workaround: Try to bypass validation webhook or apply directly
                    print_error ""
                    print_error "Attempting workaround: Applying with dry-run first to check syntax..."
                    
                    # Check if we can apply with dry-run (validates syntax without webhook)
                    if kubectl apply --dry-run=client -f "${KUSTOMIZE_OUTPUT}" &>/dev/null; then
                        print_info "Dry-run successful - YAML syntax is valid"
                        print_info "The issue is with the validation webhook, not the YAML"
                        print_error ""
                        print_error "Possible solutions:"
                        print_error "1. Temporarily disable validation webhook (if you have cluster admin access):"
                        print_error "   kubectl delete validatingwebhookconfiguration spinnakervalidatingwebhook"
                        print_error "   # Then re-run this script"
                        print_error ""
                        print_error "   Or the script will try to disable it automatically on next run"
                        print_error ""
                        print_error "2. Try applying directly to API server (bypasses webhook):"
                        print_error "   kubectl apply --server-side --force-conflicts -f /tmp/spinnaker-merged-output.yaml"
                        print_error ""
                        print_error "3. Check validation webhook logs for details:"
                        print_error "   kubectl -n ${OPERATOR_NAMESPACE} logs -l app=spinnaker-operator | grep -i validation"
                        print_error ""
                        print_error "4. Try editing the existing SpinnakerService (if it exists):"
                        print_error "   kubectl -n ${SPINNAKER_NAMESPACE} edit spinsvc spinnaker"
                        rm -f "${KUSTOMIZE_OUTPUT}"
                        exit 1
                    else
                        print_error "Dry-run also failed - there may be a YAML syntax issue"
                        print_error "Trying to apply base resource as fallback..."
                        
                        # Workaround: Apply base resource first
                        if [ -f "spinnakerservice.yml" ]; then
                            print_info "Step 1: Applying base SpinnakerService..."
                            if kubectl -n ${SPINNAKER_NAMESPACE} apply -f spinnakerservice.yml 2>&1 | tee /tmp/base-apply.log; then
                                print_info "Base resource applied. Waiting 5 seconds for webhook to process..."
                                sleep 5
                                
                                print_info "Step 2: Applying patches via kustomize..."
                                if kubectl -n ${SPINNAKER_NAMESPACE} apply -f "${KUSTOMIZE_OUTPUT}" 2>&1 | tee /tmp/patched-apply.log; then
                                    print_info "✓ Successfully applied with workaround!"
                                    rm -f "${KUSTOMIZE_OUTPUT}"
                                else
                                    print_error "Failed to apply patches even with workaround"
                                    print_error "You may need to manually edit the SpinnakerService:"
                                    print_error "  kubectl -n ${SPINNAKER_NAMESPACE} edit spinsvc spinnaker"
                                    rm -f "${KUSTOMIZE_OUTPUT}"
                                    exit 1
                                fi
                            else
                                print_error "Failed to apply base configuration"
                                cat /tmp/base-apply.log
                                rm -f "${KUSTOMIZE_OUTPUT}"
                                exit 1
                            fi
                        else
                            print_error "Base spinnakerservice.yml not found for workaround"
                            rm -f "${KUSTOMIZE_OUTPUT}"
                            exit 1
                        fi
                    fi
                else
                    print_error "Service account NOT found in merged output!"
                    print_error "This indicates a configuration issue."
                    rm -f "${KUSTOMIZE_OUTPUT}"
                    exit 1
                fi
            elif grep -q "AccessKeyId is missing" /tmp/kubectl-apply.log; then
                print_error "Validation Error: AccessKeyId is missing"
                print_error ""
                print_error "Checking merged output for accessKeyId..."
                S3_KEY=$(grep -A 5 "persistentStorage:" "${KUSTOMIZE_OUTPUT}" | grep -A 3 "s3:" | grep "accessKeyId:" || echo "")
                AWS_KEY=$(grep -A 10 "providers:" "${KUSTOMIZE_OUTPUT}" | grep -A 8 "aws:" | grep "accessKeyId:" || echo "")
                
                if [ -z "$S3_KEY" ] || [ -z "$AWS_KEY" ]; then
                    print_error "AccessKeyId missing in merged output!"
                    print_error "S3 accessKeyId: ${S3_KEY:-NOT FOUND}"
                    print_error "AWS accessKeyId: ${AWS_KEY:-NOT FOUND}"
                    rm -f "${KUSTOMIZE_OUTPUT}"
                    exit 1
                else
                    print_warn "AccessKeyId IS present in merged output, but validation failed"
                    print_warn "This may be a validation webhook issue"
                    print_error "Please check the validation webhook logs:"
                    print_error "  kubectl -n ${OPERATOR_NAMESPACE} logs -l app=spinnaker-operator | grep -i validation"
                    rm -f "${KUSTOMIZE_OUTPUT}"
                    exit 1
                fi
            else
                print_error "Unknown validation error. Full details in /tmp/kubectl-apply.log"
                print_error "Debugging information:"
                print_error "1. Check if service account exists:"
                print_error "   kubectl -n ${SPINNAKER_NAMESPACE} get serviceaccount spinnaker"
                print_error ""
                print_error "2. Inspect merged output:"
                print_error "   cat /tmp/spinnaker-merged-output.yaml | grep -A 10 'service-settings:'"
                print_error ""
                print_error "3. Check validation webhook:"
                print_error "   kubectl -n ${OPERATOR_NAMESPACE} logs -l app=spinnaker-operator | grep -i validation"
                rm -f "${KUSTOMIZE_OUTPUT}"
                exit 1
            fi
        fi
    else
        print_error "Kustomize build failed!"
        print_error "Build output:"
        cat "${KUSTOMIZE_OUTPUT}"
        rm -f "${KUSTOMIZE_OUTPUT}"
        
        # Fallback to base resource
        print_info "Attempting fallback: Apply base SpinnakerService only..."
        if [ -f "spinnakerservice.yml" ]; then
            kubectl -n ${SPINNAKER_NAMESPACE} apply -f spinnakerservice.yml
            print_warn "Applied base configuration only. Please fix patch files and reapply."
        else
            exit 1
        fi
    fi
fi

# Step 9: Monitor Deployment
print_info "Step 9: Monitoring Spinnaker deployment..."
print_info "You can watch the deployment progress with:"
print_info "  kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -w"
print_info ""
print_info "Or check the pods:"
print_info "  kubectl -n ${SPINNAKER_NAMESPACE} get pods -w"
print_info ""
print_info "To check the status:"
print_info "  kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o yaml"

# Wait a bit and show initial status
sleep 5
print_info ""
print_info "Current SpinnakerService status:"
kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker || print_warn "SpinnakerService not found yet. It may take a moment to appear."

# Step 10: Wait for Spinnaker to be ready and verify configuration
print_info ""
print_info "Step 10: Waiting for Spinnaker deployment to complete..."
print_info "This may take 5-10 minutes. Monitoring progress..."

# Wait for SpinnakerService to be created
TIMEOUT=600  # 10 minutes
ELAPSED=0
while [ $ELAPSED -lt $TIMEOUT ]; do
    if kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker &>/dev/null; then
        break
    fi
    sleep 5
    ELAPSED=$((ELAPSED + 5))
    echo -n "."
done
echo ""

if ! kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker &>/dev/null; then
    print_error "SpinnakerService not created after ${TIMEOUT}s. Please check operator logs."
    exit 1
fi

print_info "SpinnakerService created. Waiting for pods to be ready..."

# Wait for pods to be ready
TIMEOUT=600
ELAPSED=0
while [ $ELAPSED -lt $TIMEOUT ]; do
    READY_PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods --no-headers 2>/dev/null | grep -c "Running\|Completed" || echo "0")
    TOTAL_PODS=$(kubectl -n ${SPINNAKER_NAMESPACE} get pods --no-headers 2>/dev/null | wc -l || echo "0")
    
    if [ "$TOTAL_PODS" -gt 0 ] && [ "$READY_PODS" -eq "$TOTAL_PODS" ]; then
        print_info "All pods are ready!"
        break
    fi
    
    sleep 10
    ELAPSED=$((ELAPSED + 10))
    echo -n "."
done
echo ""

# Step 11: Verify Configuration
print_info ""
print_info "Step 11: Verifying Spinnaker configuration..."

# Verify Kubernetes account
K8S_ACCOUNT=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.accounts[0].name}' 2>/dev/null || echo "")
K8S_PRIMARY=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.primaryAccount}' 2>/dev/null || echo "")

if [ "$K8S_ACCOUNT" == "exotel-refresh" ] && [ "$K8S_PRIMARY" == "exotel-refresh" ]; then
    print_info "✓ Kubernetes account configured correctly: ${K8S_ACCOUNT}"
    print_info "✓ Primary Kubernetes account: ${K8S_PRIMARY}"
else
    print_error "✗ Kubernetes account mismatch!"
    print_error "  Expected: exotel-refresh"
    print_error "  Found account: ${K8S_ACCOUNT}"
    print_error "  Found primary: ${K8S_PRIMARY}"
fi

# Verify AWS account
AWS_ACCOUNT=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.aws.accounts[0].name}' 2>/dev/null || echo "")
AWS_PRIMARY=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.aws.primaryAccount}' 2>/dev/null || echo "")

if [ "$AWS_ACCOUNT" == "${AWS_ACCOUNT_NAME}" ] && [ "$AWS_PRIMARY" == "${AWS_ACCOUNT_NAME}" ]; then
    print_info "✓ AWS account configured correctly: ${AWS_ACCOUNT}"
    print_info "✓ Primary AWS account: ${AWS_PRIMARY}"
else
    print_warn "✗ AWS account mismatch!"
    print_warn "  Expected: ${AWS_ACCOUNT_NAME}"
    print_warn "  Found account: ${AWS_ACCOUNT}"
    print_warn "  Found primary: ${AWS_PRIMARY}"
fi

# Verify S3 configuration
S3_BUCKET_CONFIG=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.persistentStorage.s3.bucket}' 2>/dev/null || echo "")
if [ "$S3_BUCKET_CONFIG" == "${S3_BUCKET}" ]; then
    print_info "✓ S3 bucket configured correctly: ${S3_BUCKET_CONFIG}"
else
    print_warn "✗ S3 bucket mismatch!"
    print_warn "  Expected: ${S3_BUCKET}"
    print_warn "  Found: ${S3_BUCKET_CONFIG}"
fi

# Verify Spinnaker version
SPINNAKER_VERSION_CONFIG=$(kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.version}' 2>/dev/null || echo "")
if [ "$SPINNAKER_VERSION_CONFIG" == "${SPINNAKER_VERSION}" ]; then
    print_info "✓ Spinnaker version configured correctly: ${SPINNAKER_VERSION_CONFIG}"
else
    print_warn "✗ Spinnaker version mismatch!"
    print_warn "  Expected: ${SPINNAKER_VERSION}"
    print_warn "  Found: ${SPINNAKER_VERSION_CONFIG}"
fi

# Step 12: Display deployment status
print_info ""
print_info "Step 12: Deployment Status Summary"
print_info "=========================================="

# Operator status
OPERATOR_READY=$(kubectl -n ${OPERATOR_NAMESPACE} get deployment spinnaker-operator -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
OPERATOR_DESIRED=$(kubectl -n ${OPERATOR_NAMESPACE} get deployment spinnaker-operator -o jsonpath='{.spec.replicas}' 2>/dev/null || echo "0")
if [ "$OPERATOR_READY" -eq "$OPERATOR_DESIRED" ] && [ "$OPERATOR_DESIRED" -gt 0 ]; then
    print_info "✓ Operator: ${OPERATOR_READY}/${OPERATOR_DESIRED} replicas ready"
else
    print_warn "✗ Operator: ${OPERATOR_READY}/${OPERATOR_DESIRED} replicas ready"
fi

# Spinnaker pods status
print_info ""
print_info "Spinnaker Pods:"
kubectl -n ${SPINNAKER_NAMESPACE} get pods --no-headers 2>/dev/null | while read line; do
    POD_NAME=$(echo "$line" | awk '{print $1}')
    POD_STATUS=$(echo "$line" | awk '{print $3}')
    POD_READY=$(echo "$line" | awk '{print $2}')
    if [[ "$POD_STATUS" == "Running" ]] && [[ "$POD_READY" =~ ^[1-9]/[0-9]+$ ]]; then
        print_info "  ✓ ${POD_NAME}: ${POD_STATUS} (${POD_READY})"
    else
        print_warn "  ✗ ${POD_NAME}: ${POD_STATUS} (${POD_READY})"
    fi
done

# Services status
print_info ""
print_info "Spinnaker Services:"
kubectl -n ${SPINNAKER_NAMESPACE} get svc --no-headers 2>/dev/null | while read line; do
    SVC_NAME=$(echo "$line" | awk '{print $1}')
    SVC_TYPE=$(echo "$line" | awk '{print $2}')
    print_info "  - ${SVC_NAME}: ${SVC_TYPE}"
done

# Get LoadBalancer URL
print_info ""
DECK_LB=$(kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-deck -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
if [ -n "$DECK_LB" ]; then
    print_info "✓ Spinnaker UI (Deck) LoadBalancer: http://${DECK_LB}:9000"
else
    print_warn "✗ LoadBalancer not yet assigned. Check with: kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-deck"
fi

GATE_LB=$(kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-gate -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-gate -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
if [ -n "$GATE_LB" ]; then
    print_info "✓ Spinnaker API (Gate) LoadBalancer: http://${GATE_LB}:8084"
else
    print_warn "✗ LoadBalancer not yet assigned. Check with: kubectl -n ${SPINNAKER_NAMESPACE} get svc spin-gate"
fi

print_info ""
print_info "=========================================="
print_info "Deployment Verification Complete!"
print_info "=========================================="
print_info ""
print_info "Key Configuration Verified:"
print_info "  - Kubernetes Account: exotel-refresh (for pipeline account field)"
print_info "  - AWS Account: ${AWS_ACCOUNT_NAME}"
print_info "  - S3 Bucket: ${S3_BUCKET}"
print_info "  - Spinnaker Version: ${SPINNAKER_VERSION}"
print_info ""
print_info "Next Steps:"
print_info "  1. Access Spinnaker UI at the LoadBalancer URL above"
print_info "  2. When creating pipelines, the account field will show 'exotel-refresh'"
print_info "  3. Monitor deployment: kubectl -n ${SPINNAKER_NAMESPACE} get pods -w"
print_info ""
print_info "To verify account configuration:"
print_info "  kubectl -n ${SPINNAKER_NAMESPACE} get spinsvc spinnaker -o jsonpath='{.spec.spinnakerConfig.config.providers.kubernetes.primaryAccount}'"

