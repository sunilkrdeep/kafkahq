# AKHQ Production Deployment Guide

Complete guide for installing, updating, and managing AKHQ in production Kubernetes environment.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Initial Installation](#initial-installation)
3. [Updating Deployment](#updating-deployment)
4. [Starting/Stopping Service](#startingstopping-service)
5. [Configuration Management](#configuration-management)
6. [Access Methods](#access-methods)
7. [Troubleshooting](#troubleshooting)
8. [Production Best Practices](#production-best-practices)

---

## Prerequisites

### Required Tools
- Kubernetes cluster access (kubectl configured)
- Helm 3.0+
- Access to Kafka cluster with SASL_SSL authentication
- SSL truststore file (JKS format) for Kafka connection

### Required Information
- Kafka bootstrap servers
- SASL username and password
- SSL truststore file and password
- Kubernetes namespace (default: `kafka-tool`)

---

## Initial Installation

### Step 1: Create Namespace

```bash
kubectl create namespace kafka-tool
```

### Step 2: Create SSL Secret

Create Kubernetes secret containing the Kafka SSL truststore:

```bash
# Create secret with truststore
kubectl create secret generic akhq-ssl-secret \
  --from-file=qa-kafka-truststore.jks=/path/to/qa-kafka-truststore.jks \
  --namespace=kafka-tool
```

**Note**: 
- Secret name must match `ssl.secretName` in `values.yaml` (default: `akhq-ssl-secret`)
- Truststore filename must match `ssl.truststoreFile` in `values.yaml` (default: `qa-kafka-truststore.jks`)
- Truststore password is configured in `values.yaml` under `ssl.truststore.password` (default: `kafkatruststore`)

### Step 3: Verify Configuration

Review `values.yaml` and ensure:
- ✅ Kafka connection details are correct
- ✅ SSL truststore path and password match
- ✅ Authentication credentials are correct
- ✅ Resource limits are appropriate for your cluster

### Step 4: Install AKHQ

```bash
# Navigate to chart directory
cd /Users/sunil.k/kubernetes/kafkahq

# Install AKHQ
helm install akhq . \
  --namespace kafka-tool \
  -f values.yaml
```

### Step 5: Verify Installation

```bash
# Check pod status
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq

# Check service
kubectl get svc akhq -n kafka-tool

# Check logs
kubectl logs -n kafka-tool deployment/akhq --tail=50

# Verify SSL certificates are mounted
kubectl exec -n kafka-tool deployment/akhq -- ls -la /app/secrets
```

**Expected Output:**
- Pod status: `Running` and `READY: 1/1`
- Service type: `NodePort` (for AWS ALB integration)
- SSL certificates visible in `/app/secrets`

---

## Updating Deployment

### Update Configuration

When you need to update AKHQ configuration:

```bash
# 1. Edit values.yaml with your changes
vi values.yaml

# 2. Upgrade Helm release
helm upgrade akhq . \
  --namespace kafka-tool \
  -f values.yaml

# 3. Restart deployment (if needed)
kubectl rollout restart deployment/akhq -n kafka-tool

# 4. Wait for rollout to complete
kubectl rollout status deployment/akhq -n kafka-tool --timeout=60s
```

### Update SSL Certificates

If SSL certificates need to be updated:

```bash
# 1. Update the secret
kubectl create secret generic akhq-ssl-secret \
  --from-file=qa-kafka-truststore.jks=/path/to/new-truststore.jks \
  --namespace=kafka-tool \
  --dry-run=client -o yaml | kubectl apply -f -

# 2. Restart deployment to pick up new certificates
kubectl rollout restart deployment/akhq -n kafka-tool

# 3. Verify certificates are updated
kubectl exec -n kafka-tool deployment/akhq -- ls -la /app/secrets
```

### Update Passwords

To update user passwords:

```bash
# 1. Generate new password hash
echo -n "newpassword" | sha256sum | awk '{print $1}'

# 2. Update values.yaml with new hash
# Edit values.yaml:
#   basic-auth:
#     - username: "admin"
#       password: "<new-hash>"
#       passwordHash: "SHA256"

# 3. Upgrade deployment
helm upgrade akhq . --namespace kafka-tool -f values.yaml

# 4. Restart deployment
kubectl rollout restart deployment/akhq -n kafka-tool
```

### Update Image Version

To update AKHQ to a different version:

```bash
# 1. Edit values.yaml
# Update: image.tag: "0.26.0" (or desired version)

# 2. Upgrade deployment
helm upgrade akhq . --namespace kafka-tool -f values.yaml

# 3. Restart deployment
kubectl rollout restart deployment/akhq -n kafka-tool
```

---

## Starting/Stopping Service

### Start Service

If pods are stopped or scaled down:

```bash
# Scale up deployment
kubectl scale deployment akhq --replicas=1 -n kafka-tool

# Or restart if already running
kubectl rollout restart deployment/akhq -n kafka-tool

# Wait for pod to be ready
kubectl wait --for=condition=ready pod \
  -l app.kubernetes.io/name=akhq \
  -n kafka-tool \
  --timeout=60s
```

### Stop Service

To temporarily stop AKHQ:

```bash
# Scale down to 0 replicas
kubectl scale deployment akhq --replicas=0 -n kafka-tool

# Verify pods are stopped
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq
```

### Restart Service

To restart AKHQ (applies new configuration):

```bash
# Restart deployment
kubectl rollout restart deployment/akhq -n kafka-tool

# Monitor rollout status
kubectl rollout status deployment/akhq -n kafka-tool --timeout=60s

# Check pod status
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq
```

---

## Configuration Management

### Current Production Configuration

The `values.yaml` is configured for production with:

#### Resource Limits
```yaml
resources:
  limits:
    cpu: 500m
    memory: 768Mi  # Prevents OOMKilled errors
  requests:
    cpu: 200m
    memory: 384Mi
```

#### JVM Settings
```yaml
env:
  - name: JAVA_OPTS
    value: "-Xmx512m -Xms384m"
```

#### Authentication
- **Admin User**: `admin` / `admin123`
- **Reader User**: `reader` / `reader123`
- **Password Hash**: SHA256 (uppercase)
- **Authentication**: Basic Auth with form login

#### Service Configuration
- **Type**: NodePort (for AWS ALB integration)
- **Port**: 80 (service) → 8080 (container)
- **Health Checks**: `/api/me` endpoint

### Generate Password Hash

Use the provided script or manual command:

```bash
# Using script
./scripts/generate-password-hash.sh <password> SHA256

# Manual command
echo -n "password" | sha256sum | awk '{print $1}'
```

### Add New Users

1. Generate password hash:
   ```bash
   echo -n "newuserpassword" | sha256sum | awk '{print $1}'
   ```

2. Update `values.yaml`:
   ```yaml
   basic-auth:
     - username: "newuser"
       password: "<generated-hash>"
       passwordHash: "SHA256"
       groups:
         - "reader"  # or "admin"
   ```

3. Upgrade deployment:
   ```bash
   helm upgrade akhq . --namespace kafka-tool -f values.yaml
   kubectl rollout restart deployment/akhq -n kafka-tool
   ```

### Modify Kafka Connection

To add or modify Kafka connections:

1. Edit `values.yaml` under `configuration.akhq.connections`:
   ```yaml
   connections:
     kafka-lp-qa:
       properties:
         bootstrap.servers: "kafka-broker:9092"
         security.protocol: "SASL_SSL"
         # ... other properties
   ```

2. Upgrade deployment:
   ```bash
   helm upgrade akhq . --namespace kafka-tool -f values.yaml
   kubectl rollout restart deployment/akhq -n kafka-tool
   ```

---

## Access Methods

### Method 1: AWS Load Balancer (Production)

AKHQ is configured with NodePort service for AWS ALB integration:

```bash
# Get NodePort
NODE_PORT=$(kubectl get svc akhq -n kafka-tool -o jsonpath='{.spec.ports[0].nodePort}')
echo "NodePort: $NODE_PORT"

# Access via AWS Internal Load Balancer
# URL: http://internal-kafka-akhq-qa-lb-789620769.us-west-2.elb.amazonaws.com/ui/login
```

**Prerequisites:**
- AWS VPN connection (for internal load balancer)
- Load balancer configured to target NodePort
- Security groups allow traffic

### Method 2: Port Forward (Development/Testing)

For local access without VPN:

```bash
# Port forward service
kubectl port-forward svc/akhq -n kafka-tool 8080:80

# Access in browser
# URL: http://localhost:8080/ui/login
```

### Method 3: Direct Pod Access (Troubleshooting)

```bash
# Port forward directly to pod
POD=$(kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq -o jsonpath='{.items[0].metadata.name}')
kubectl port-forward pod/$POD -n kafka-tool 8080:8080
```

### Login Credentials

- **Admin**: `admin` / `admin123`
- **Reader**: `reader` / `reader123`

---

## Troubleshooting

### Pod Not Starting

```bash
# Check pod status
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq

# Check pod events
kubectl describe pod -n kafka-tool -l app.kubernetes.io/name=akhq

# Check logs
kubectl logs -n kafka-tool deployment/akhq --tail=100
```

**Common Issues:**
- **Pending**: Resource constraints - check node resources
- **CrashLoopBackOff**: Check logs for errors
- **OOMKilled**: Increase memory limits in `values.yaml`

### 502 Bad Gateway

```bash
# Check pod status
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq

# Check service endpoints
kubectl get endpoints akhq -n kafka-tool

# Check pod logs for OOMKilled
kubectl describe pod -n kafka-tool -l app.kubernetes.io/name=akhq | grep -i "oomkilled"

# If OOMKilled, increase memory in values.yaml and upgrade
```

### Authentication Issues

```bash
# Verify ConfigMap has correct configuration
kubectl get configmap akhq-config -n kafka-tool -o yaml | grep -A 10 "basic-auth"

# Check password hash format (should be uppercase SHA256)
kubectl get configmap akhq-config -n kafka-tool -o jsonpath='{.data.application\.yml}' | grep passwordHash

# Verify intercept-url-map allows login endpoints
kubectl get configmap akhq-config -n kafka-tool -o jsonpath='{.data.application\.yml}' | grep -A 5 "intercept-url-map"
```

### SSL Certificate Issues

```bash
# Verify certificates are mounted
kubectl exec -n kafka-tool deployment/akhq -- ls -la /app/secrets

# Check secret exists
kubectl get secret akhq-ssl-secret -n kafka-tool

# Verify truststore file name matches
kubectl get secret akhq-ssl-secret -n kafka-tool -o jsonpath='{.data}' | jq 'keys'
```

### Kafka Connection Issues

```bash
# Test connectivity from pod
kubectl exec -n kafka-tool deployment/akhq -- ping -c 3 kafka-lp-1.internal.us3.qaexotel.in

# Check DNS resolution
kubectl exec -n kafka-tool deployment/akhq -- nslookup kafka-lp-1.internal.us3.qaexotel.in

# Check logs for connection errors
kubectl logs -n kafka-tool deployment/akhq | grep -i "kafka\|connection\|ssl\|sasl"
```

### Health Check Failures

```bash
# Test health endpoint directly
kubectl exec -n kafka-tool deployment/akhq -- curl -s http://localhost:8080/api/me

# Check health check configuration
kubectl get deployment akhq -n kafka-tool -o yaml | grep -A 10 "livenessProbe\|readinessProbe"
```

---

## Production Best Practices

### Resource Management

**Current Configuration:**
- Memory limit: 768Mi (prevents OOMKilled)
- CPU limit: 500m
- JVM heap: 512m (leaves ~256Mi for overhead)

**For Larger Environments:**
- Increase memory limit to 1Gi or more
- Increase JVM heap proportionally
- Monitor memory usage and adjust

### Security

1. **Change Default Passwords**: Update admin and reader passwords in production
2. **Use Strong Passwords**: Generate complex passwords and hash them
3. **Rotate Credentials**: Regularly update passwords
4. **Network Policies**: Implement network policies to restrict access
5. **RBAC**: Configure appropriate Kubernetes RBAC

### Monitoring

```bash
# Monitor pod status
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq -w

# Monitor resource usage
kubectl top pod -n kafka-tool -l app.kubernetes.io/name=akhq

# Monitor logs
kubectl logs -n kafka-tool deployment/akhq -f
```

### Backup Configuration

```bash
# Backup values.yaml
cp values.yaml values.yaml.backup

# Backup ConfigMap
kubectl get configmap akhq-config -n kafka-tool -o yaml > akhq-config-backup.yaml

# Backup SSL secret (be careful with secrets)
kubectl get secret akhq-ssl-secret -n kafka-tool -o yaml > akhq-ssl-secret-backup.yaml
```

### High Availability

For production, consider:

1. **Multiple Replicas**: Enable autoscaling or set `replicaCount: 2+`
2. **Pod Disruption Budget**: Configure PDB to ensure availability
3. **Resource Quotas**: Set appropriate resource quotas
4. **Node Affinity**: Configure node affinity for better distribution

---

## Quick Reference Commands

### Installation
```bash
helm install akhq . --namespace kafka-tool -f values.yaml
```

### Update
```bash
helm upgrade akhq . --namespace kafka-tool -f values.yaml
kubectl rollout restart deployment/akhq -n kafka-tool
```

### Status Check
```bash
kubectl get pods -n kafka-tool -l app.kubernetes.io/name=akhq
kubectl get svc akhq -n kafka-tool
kubectl get endpoints akhq -n kafka-tool
```

### Logs
```bash
kubectl logs -n kafka-tool deployment/akhq -f
kubectl logs -n kafka-tool deployment/akhq --tail=100
```

### Restart
```bash
kubectl rollout restart deployment/akhq -n kafka-tool
kubectl rollout status deployment/akhq -n kafka-tool
```

### Access
```bash
# Port forward
kubectl port-forward svc/akhq -n kafka-tool 8080:80

# Direct pod access
kubectl exec -it -n kafka-tool deployment/akhq -- sh
```

### Uninstall
```bash
helm uninstall akhq --namespace kafka-tool
kubectl delete secret akhq-ssl-secret --namespace kafka-tool
```

---

## Configuration Summary

### Current Production Settings

- **Namespace**: `kafka-tool`
- **Image**: `tchiotludo/akhq:latest`
- **Service Type**: `NodePort`
- **Memory**: 768Mi limit, 384Mi request
- **CPU**: 500m limit, 200m request
- **JVM Heap**: 512m max, 384m min
- **Authentication**: Basic Auth (SHA256)
- **Users**: admin, reader
- **SSL**: Enabled with JKS truststore

### Key Files

- **values.yaml**: Main configuration file
- **Chart.yaml**: Helm chart metadata
- **templates/**: Kubernetes manifest templates
- **qa-kafka-truststore.jks**: SSL truststore file

---

## Support and Documentation

- **AKHQ Official Docs**: https://akhq.io/docs/
- **AKHQ GitHub**: https://github.com/tchiotludo/akhq
- **Kafka SSL Docs**: https://kafka.apache.org/documentation/#security_ssl

---

## Version History

- **Chart Version**: 0.1.0
- **AKHQ Version**: latest (0.26.0+)
- **Last Updated**: 2026-01-05
- **Configuration**: Production-ready with authentication, SSL, and optimized resources

---

**Note**: This guide is based on the current production configuration in `values.yaml`. Always review and test changes in a non-production environment before applying to production.

