#!/bin/bash
# Script to verify truststore configuration in AKHQ pod

NAMESPACE="${1:-akhq}"
POD_NAME=$(kubectl get pods -n $NAMESPACE -l app.kubernetes.io/name=akhq -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)

if [ -z "$POD_NAME" ]; then
    echo "Error: AKHQ pod not found in namespace $NAMESPACE"
    exit 1
fi

echo "=== Verifying Truststore Configuration ==="
echo "Pod: $POD_NAME"
echo "Namespace: $NAMESPACE"
echo ""

echo "1. Checking if truststore file exists..."
kubectl exec -n $NAMESPACE $POD_NAME -- test -f /app/secrets/kafka.truststore.jks
if [ $? -eq 0 ]; then
    echo "   ✓ Truststore file exists"
else
    echo "   ✗ Truststore file NOT found!"
    exit 1
fi

echo ""
echo "2. Checking file permissions..."
kubectl exec -n $NAMESPACE $POD_NAME -- ls -la /app/secrets/kafka.truststore.jks

echo ""
echo "3. Checking file size..."
SIZE=$(kubectl exec -n $NAMESPACE $POD_NAME -- stat -c%s /app/secrets/kafka.truststore.jks 2>/dev/null)
if [ -n "$SIZE" ] && [ "$SIZE" -gt 0 ]; then
    echo "   ✓ File size: $SIZE bytes"
else
    echo "   ✗ File is empty or cannot be read!"
    exit 1
fi

echo ""
echo "4. Checking if keytool is available..."
kubectl exec -n $NAMESPACE $POD_NAME -- which keytool >/dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "   ✓ keytool is available"
    echo ""
    echo "5. Listing truststore contents..."
    kubectl exec -n $NAMESPACE $POD_NAME -- keytool -list -keystore /app/secrets/kafka.truststore.jks -storepass kafkatruststore 2>&1 | head -10
else
    echo "   ⚠ keytool not available in container (this is normal for minimal images)"
fi

echo ""
echo "6. Checking AKHQ logs for SSL errors..."
kubectl logs -n $NAMESPACE $POD_NAME --tail=50 | grep -i "ssl\|handshake\|certificate\|truststore" | tail -5

echo ""
echo "=== Verification Complete ==="



