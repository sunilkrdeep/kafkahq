#!/bin/bash
# Script to update the AKHQ SSL secret to include mum-kafka-truststore.jks for the new cluster

set -e

NAMESPACE="${1:-akhq}"
LOCAL_TRUSTSTORE_PATH="${HOME}/kafka/ssl/kafka.truststore.jks"
MUM_TRUSTSTORE_PATH="/Users/sunil.k/terraforms/secure-kafka/kafka-producers/ssl/mum-kafka-truststore.jks"
SECRET_NAME="akhq-ssl-secret"

echo "=== Updating AKHQ SSL Secret with Both Truststores ==="
echo "Namespace: $NAMESPACE"
echo "Local Truststore: $LOCAL_TRUSTSTORE_PATH (for kafka-local cluster)"
echo "MUM Truststore: $MUM_TRUSTSTORE_PATH (for kafka-mum-lp-sec cluster)"
echo ""

# Check if truststore files exist
if [ ! -f "$LOCAL_TRUSTSTORE_PATH" ]; then
    echo "Error: Local truststore file not found at $LOCAL_TRUSTSTORE_PATH"
    exit 1
fi

if [ ! -f "$MUM_TRUSTSTORE_PATH" ]; then
    echo "Error: MUM truststore file not found at $MUM_TRUSTSTORE_PATH"
    exit 1
fi

echo "1. Deleting existing secret..."
kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE" 2>/dev/null || echo "   Secret doesn't exist, will create new one"

echo ""
echo "2. Creating new secret with both truststores..."
kubectl create secret generic "$SECRET_NAME" \
  --from-file=local-kafka.truststore.jks="$LOCAL_TRUSTSTORE_PATH" \
  --from-file=mum-kafka-truststore.jks="$MUM_TRUSTSTORE_PATH" \
  --namespace="$NAMESPACE"

echo ""
echo "3. Verifying secret..."
kubectl describe secret "$SECRET_NAME" -n "$NAMESPACE" | grep -E "Name:|Type:|local-kafka|mum-kafka"

echo ""
echo "4. Restarting deployment..."
if kubectl get deployment akhq -n "$NAMESPACE" >/dev/null 2>&1; then
    kubectl rollout restart deployment/akhq -n "$NAMESPACE"
    echo "   Waiting for rollout to complete..."
    kubectl rollout status deployment/akhq -n "$NAMESPACE" --timeout=60s
else
    echo "   Deployment not found. You may need to install AKHQ first."
fi

echo ""
echo "=== Secret Update Complete ==="
echo ""
echo "Secret now contains:"
echo "  - local-kafka.truststore.jks (for kafka-local cluster)"
echo "  - mum-kafka-truststore.jks (for kafka-mum-lp-sec cluster)"
echo ""
echo "To verify the certificates are mounted:"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- ls -la /app/secrets/"
echo ""
echo "To check logs:"
echo "  kubectl logs -n $NAMESPACE deployment/akhq -f | grep -i kafka"

