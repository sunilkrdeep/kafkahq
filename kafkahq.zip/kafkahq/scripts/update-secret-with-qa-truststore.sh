#!/bin/bash
# Script to update the AKHQ SSL secret with qa-kafka-truststore.jks

set -e

NAMESPACE="${1:-kafka-tool}"
QA_TRUSTSTORE_PATH="/Users/sunil.k/kubernetes/kafkahq/qa-kafka-truststore.jks"
SECRET_NAME="akhq-ssl-secret"

echo "=== Updating AKHQ SSL Secret with QA Truststore ==="
echo "Namespace: $NAMESPACE"
echo "Source Truststore: $QA_TRUSTSTORE_PATH"
echo "Secret Key Name: qa-kafka-truststore.jks"
echo ""

# Check if truststore file exists
if [ ! -f "$QA_TRUSTSTORE_PATH" ]; then
    echo "Error: QA truststore file not found at $QA_TRUSTSTORE_PATH"
    exit 1
fi

echo "1. Checking if namespace exists..."
if ! kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
    echo "   Creating namespace $NAMESPACE..."
    kubectl create namespace "$NAMESPACE"
fi

echo ""
echo "2. Deleting existing secret (if exists)..."
kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE" 2>/dev/null || echo "   Secret doesn't exist, will create new one"

echo ""
echo "3. Creating new secret with QA truststore..."
kubectl create secret generic "$SECRET_NAME" \
  --from-file=qa-kafka-truststore.jks="$QA_TRUSTSTORE_PATH" \
  --namespace="$NAMESPACE"

echo ""
echo "4. Verifying secret..."
kubectl describe secret "$SECRET_NAME" -n "$NAMESPACE" | grep -E "Name:|Type:|qa-kafka-truststore"

echo ""
echo "5. Restarting deployment..."
if kubectl get deployment akhq -n "$NAMESPACE" >/dev/null 2>&1; then
    kubectl rollout restart deployment/akhq -n "$NAMESPACE"
    echo "   Waiting for rollout to complete..."
    kubectl rollout status deployment/akhq -n "$NAMESPACE" --timeout=60s
else
    echo "   Deployment not found. You may need to install AKHQ first."
fi

echo ""
echo "=== Secret Update Complete ==="
echo ""
echo "Configuration:"
echo "  - Bootstrap server: kafka-lp-1.internal.us3.qaexotel.in:9092"
echo "  - Security protocol: SASL_SSL"
echo "  - Truststore: qa-kafka-truststore.jks (JKS format)"
echo "  - Truststore password: kafkatruststore"
echo ""
echo "To verify the truststore is mounted:"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- ls -la /app/secrets/"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- ls -la /app/secrets/qa-kafka-truststore.jks"
echo ""
echo "To check logs:"
echo "  kubectl logs -n $NAMESPACE deployment/akhq -f | grep -i ssl"

