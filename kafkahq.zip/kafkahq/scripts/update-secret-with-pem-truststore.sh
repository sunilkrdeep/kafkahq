#!/bin/bash
# Script to update the AKHQ SSL secret with PEM truststore for Kafka QA

set -e

NAMESPACE="${1:-kafka-tool}"
TRUSTSTORE_PATH="/Users/sunil.k/kubernetes/kafkahq/truststore.pem"
SECRET_NAME="akhq-ssl-secret"

echo "=== Updating AKHQ SSL Secret with PEM Truststore ==="
echo "Namespace: $NAMESPACE"
echo "Truststore: $TRUSTSTORE_PATH"
echo ""

# Check if truststore file exists
if [ ! -f "$TRUSTSTORE_PATH" ]; then
    echo "Error: Truststore file not found at $TRUSTSTORE_PATH"
    exit 1
fi

echo "1. Checking if namespace exists..."
if ! kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
    echo "   Creating namespace $NAMESPACE..."
    kubectl create namespace "$NAMESPACE"
fi

echo ""
echo "2. Deleting existing secret (if exists)..."
kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE" 2>/dev/null || echo "   Secret doesn't exist, will create new one"

echo ""
echo "3. Creating new secret with PEM truststore..."
kubectl create secret generic "$SECRET_NAME" \
  --from-file=truststore.pem="$TRUSTSTORE_PATH" \
  --namespace="$NAMESPACE"

echo ""
echo "4. Verifying secret..."
kubectl describe secret "$SECRET_NAME" -n "$NAMESPACE" | grep -E "Name:|Type:|truststore.pem"

echo ""
echo "5. Restarting deployment..."
if kubectl get deployment akhq -n "$NAMESPACE" >/dev/null 2>&1; then
    kubectl rollout restart deployment/akhq -n "$NAMESPACE"
    echo "   Waiting for rollout to complete..."
    kubectl rollout status deployment/akhq -n "$NAMESPACE" --timeout=60s
else
    echo "   Deployment not found. You may need to install AKHQ first."
fi

echo ""
echo "=== Secret Update Complete ==="
echo ""
echo "Configuration:"
echo "  - Bootstrap server: kafka-lp-1.internal.us3.qaexotel.in:9092"
echo "  - Security protocol: SASL_SSL"
echo "  - Truststore: truststore.pem (PEM format)"
echo ""
echo "To verify the truststore is mounted:"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- ls -la /app/secrets/"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- cat /app/secrets/truststore.pem | head -5"
echo ""
echo "To check logs:"
echo "  kubectl logs -n $NAMESPACE deployment/akhq -f | grep -i ssl"






