#!/bin/bash
# Script to update the AKHQ SSL secret with the correct truststore

set -e

NAMESPACE="${1:-akhq}"
TRUSTSTORE_PATH="/Users/sunil.k/terraforms/secure-kafka/kafka-producers/ssl/mum-kafka-truststore.jks"
SECRET_NAME="akhq-ssl-secret"

echo "=== Updating AKHQ SSL Secret ==="
echo "Namespace: $NAMESPACE"
echo "Truststore: $TRUSTSTORE_PATH"
echo ""

# Check if truststore file exists
if [ ! -f "$TRUSTSTORE_PATH" ]; then
    echo "Error: Truststore file not found at $TRUSTSTORE_PATH"
    exit 1
fi

echo "1. Checking if namespace exists..."
if ! kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
    echo "   Creating namespace $NAMESPACE..."
    kubectl create namespace "$NAMESPACE"
fi

echo ""
echo "2. Deleting existing secret (if exists)..."
kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE" 2>/dev/null || echo "   Secret doesn't exist, will create new one"

echo ""
echo "3. Creating new secret with correct truststore..."
kubectl create secret generic "$SECRET_NAME" \
  --from-file=mum-kafka-truststore.jks="$TRUSTSTORE_PATH" \
  --namespace="$NAMESPACE"

echo ""
echo "4. Verifying secret..."
kubectl describe secret "$SECRET_NAME" -n "$NAMESPACE" | grep -E "Name:|Type:|mum-kafka-truststore"

echo ""
echo "5. Restarting deployment..."
if kubectl get deployment akhq -n "$NAMESPACE" >/dev/null 2>&1; then
    kubectl rollout restart deployment/akhq -n "$NAMESPACE"
    echo "   Waiting for rollout to complete..."
    kubectl rollout status deployment/akhq -n "$NAMESPACE" --timeout=60s
else
    echo "   Deployment not found. You may need to install AKHQ first."
fi

echo ""
echo "=== Secret Update Complete ==="
echo ""
echo "To verify the truststore is mounted:"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- ls -la /app/secrets/"
echo ""
echo "To check logs:"
echo "  kubectl logs -n $NAMESPACE deployment/akhq -f | grep -i ssl"



