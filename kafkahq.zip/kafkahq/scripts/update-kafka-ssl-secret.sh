#!/bin/bash
# Script to update the AKHQ SSL secret with Kafka SSL certificates from ~/kafka/ssl

set -e

NAMESPACE="${1:-akhq}"
TRUSTSTORE_PATH="${HOME}/kafka/ssl/kafka.truststore.jks"
KEYSTORE_PATH="${HOME}/kafka/ssl/kafka.keystore.jks"
# Secret will store files as local-kafka.*.jks
TRUSTSTORE_SECRET_NAME="local-kafka.truststore.jks"
KEYSTORE_SECRET_NAME="local-kafka.keystore.jks"
SECRET_NAME="akhq-ssl-secret"

echo "=== Updating AKHQ SSL Secret with Kafka SSL Certificates ==="
echo "Namespace: $NAMESPACE"
echo "Truststore: $TRUSTSTORE_PATH"
echo "Keystore: $KEYSTORE_PATH"
echo ""

# Check if truststore file exists
if [ ! -f "$TRUSTSTORE_PATH" ]; then
    echo "Error: Truststore file not found at $TRUSTSTORE_PATH"
    exit 1
fi

# Check if keystore file exists (optional)
KEYSTORE_OPTION=""
if [ -f "$KEYSTORE_PATH" ]; then
    KEYSTORE_OPTION="--from-file=$KEYSTORE_SECRET_NAME=$KEYSTORE_PATH"
    echo "✓ Keystore found, will be included in secret as $KEYSTORE_SECRET_NAME"
else
    echo "⚠ Keystore not found (optional, continuing without it)"
fi

echo ""
echo "1. Checking if namespace exists..."
if ! kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
    echo "   Creating namespace $NAMESPACE..."
    kubectl create namespace "$NAMESPACE"
fi

echo ""
echo "2. Deleting existing secret (if exists)..."
kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE" 2>/dev/null || echo "   Secret doesn't exist, will create new one"

echo ""
echo "3. Creating new secret with Kafka SSL certificates (renamed to local-kafka.*.jks)..."
if [ -n "$KEYSTORE_OPTION" ]; then
    kubectl create secret generic "$SECRET_NAME" \
      --from-file="$TRUSTSTORE_SECRET_NAME=$TRUSTSTORE_PATH" \
      $KEYSTORE_OPTION \
      --namespace="$NAMESPACE"
else
    kubectl create secret generic "$SECRET_NAME" \
      --from-file="$TRUSTSTORE_SECRET_NAME=$TRUSTSTORE_PATH" \
      --namespace="$NAMESPACE"
fi

echo ""
echo "4. Verifying secret..."
kubectl describe secret "$SECRET_NAME" -n "$NAMESPACE" | grep -E "Name:|Type:|kafka"

echo ""
echo "5. Restarting deployment..."
if kubectl get deployment akhq -n "$NAMESPACE" >/dev/null 2>&1; then
    kubectl rollout restart deployment/akhq -n "$NAMESPACE"
    echo "   Waiting for rollout to complete..."
    kubectl rollout status deployment/akhq -n "$NAMESPACE" --timeout=60s
else
    echo "   Deployment not found. You may need to install AKHQ first."
fi

echo ""
echo "=== Secret Update Complete ==="
echo ""
echo "Configuration:"
echo "  - Bootstrap server: 192.168.64.1:9092"
echo "  - Security protocol: SSL"
echo "  - Truststore: local-kafka.truststore.jks (from ~/kafka/ssl/kafka.truststore.jks)"
if [ -n "$KEYSTORE_OPTION" ]; then
    echo "  - Keystore: local-kafka.keystore.jks (from ~/kafka/ssl/kafka.keystore.jks)"
fi
echo ""
echo "To verify the certificates are mounted:"
echo "  kubectl exec -n $NAMESPACE deployment/akhq -- ls -la /app/secrets/"
echo ""
echo "To check logs:"
echo "  kubectl logs -n $NAMESPACE deployment/akhq -f | grep -i ssl"

