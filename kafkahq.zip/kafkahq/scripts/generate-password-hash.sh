#!/bin/bash
# Script to generate password hashes for AKHQ Basic Auth

if [ -z "$1" ]; then
    echo "Usage: $0 <password> [algorithm]"
    echo "  password: The password to hash"
    echo "  algorithm: SHA256 (default) or BCRYPT"
    echo ""
    echo "Example:"
    echo "  $0 mypassword SHA256"
    echo "  $0 mypassword BCRYPT"
    exit 1
fi

PASSWORD="$1"
ALGORITHM="${2:-SHA256}"

if [ "$ALGORITHM" = "SHA256" ]; then
    echo "Generating SHA256 hash for password: $PASSWORD"
    HASH=$(echo -n "$PASSWORD" | sha256sum | awk '{print $1}')
    echo "SHA256 Hash: $HASH"
    echo ""
    echo "Add to values.yaml:"
    echo "  password: \"$HASH\""
    echo "  passwordHash: \"SHA256\""
elif [ "$ALGORITHM" = "BCRYPT" ]; then
    echo "Generating BCRYPT hash for password: $PASSWORD"
    echo ""
    echo "BCRYPT requires a tool like 'htpasswd' or Python 'bcrypt' library."
    echo "Using Python bcrypt (if available)..."
    
    if command -v python3 >/dev/null 2>&1; then
        HASH=$(python3 -c "import bcrypt; print(bcrypt.hashpw('$PASSWORD'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8'))" 2>/dev/null)
        if [ -n "$HASH" ]; then
            echo "BCRYPT Hash: $HASH"
            echo ""
            echo "Add to values.yaml:"
            echo "  password: \"$HASH\""
            echo "  passwordHash: \"BCRYPT\""
        else
            echo "Error: Python bcrypt module not available."
            echo "Install it with: pip3 install bcrypt"
            echo ""
            echo "Or use online BCRYPT generator: https://bcrypt-generator.com/"
        fi
    else
        echo "Python3 not found. Please use an online BCRYPT generator:"
        echo "https://bcrypt-generator.com/"
        echo ""
        echo "Or install Python and bcrypt: pip3 install bcrypt"
    fi
else
    echo "Error: Unknown algorithm. Use SHA256 or BCRYPT"
    exit 1
fi

